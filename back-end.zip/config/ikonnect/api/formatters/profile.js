module.exports = ( data ) => {
	return {
		systemID              : data.ID,
		personalInfo          : {
			name                 : `${data.FIRSTNAME} ${data.SECONDNAME} ${data.LASTNAME}`,
			gender               : data.GENDER,
			nationalID           : data.IDENTIFICATIONID,
			birthday             : data.DATEOFBIRTH,
			phone                : data.PHONENUMBER,
			email                : data.EMAILADDRESS,
			language             : data.LANG,
			created              : data.CREATEDON			
		},
		deviceInfo            : {
			imsi                 : data.IMSI,
			imei                 : data.IMEI,
		},
		accountInfo           : {
			security :{
				pin       : data.PIN,
				pintTrials: data.TRIALS
			},
			wallet   : {
				accountNumber: data.MWALLETACCOUNT,
			},
			core     : {
				accountName      : data.ACCOUNTNAME,
				accounts         : ( () => {
					return data.linkedAccounts.split ( '|' )
							.filter ( entry => entry && entry )
							.map    ( account => {
			
								let info           = account.split ( '~' )	
								return {
									currency          : info [0],
									accountNumber     : info [ 1 ],
									accountType       : info [ 2 ]
								}
			
							})
	
				})()
			}
		},
		loanInfo              : {
			hasLoan              : !!data.LOANSTATUS,
			loanAmount           : data.customerLoan,
			products             : data.loanProducts
		},
		permissions           : {	
			isMpesaAgent         : !!data.MPESA_AGENT,
			isActive             : !!data.ACTIVE,
			isClosed             : !!data.CLOSED,
			isNewDevice          : !!data.deviceChanged,
			isPartiallyRegistered: !!data.PARTIAL_REGISTRATION,			
			isFirstLogin         : !!data.FIRSTLOGIN,
			isDormant            : data.DORMANT === 'N' ? false: true 
		}
	}
}