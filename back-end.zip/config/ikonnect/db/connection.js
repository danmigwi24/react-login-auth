module.exports    = {
	env              : 'development',
	vendor           : 'ikonnect-mssql',
	[`ikonnect-mssql`]     : {
		"db"            : "CREDITBANK_IB_DEV", 
		"user"          : "ikonnect_sa",
		"pass"          : "1k0nn3ct@2021",
		"host"          : "192.168.19.53",
		"dialect"       : "mssql"
	},
	[`cbkonnect-mssql`]     : {
		"db"            : "CREDITBANK", 
		"user"          : "konnect",
		"pass"          : "Pr0j3ct@2Oi9",
		"host"          : "192.168.19.53",
		"dialect"       : "mssql",
		"statementsFile": "ib-statements.js"
	},
	[`ikonnect-mssql-local`]     : {
		"db"            : "CREDITBANK_IB", 
		"user"          : "sa",
		"pass"          : "Smokes52%!",
		"host"          : "localhost",
		"port"          : 50233,
		"dialect"       : "mssql",
		"statementsFile": "ib-statements.js"
	}
}