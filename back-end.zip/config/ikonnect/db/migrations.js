module.exports = [
    { 
		"table": "tb_Corporate_Roles", 
		"schema":[
			{"field": "Role_Code",   "type": "STRING","length": 5 },
			{"field": "Role_Name",   "type": "STRING","length": 150 },
			{"field": "Created_By",  "type": "STRING","length": 50 },
			{"field": "Updated_By",  "type": "STRING","length": 50 },
			{"field": "Created_Date","type": "DATE",  "length": false },
			{"field": "Updated_Date","type": "DATE",  "length": false }
		]
	},
    { 
		"table": "tb_Corporate_Authorizer_Limits", 
		"schema":[
			{"field": "Account", 	 "type": "STRING", "length": 20 },
			{"field": "Role_Code", 	 "type": "STRING", "length": 5 },
			{"field": "Limit_Code",  "type": "STRING", "length": 5 },
			{"field": "Limit", 		 "type": "DOUBLE", "length": false },
			{"field": "Created_By",  "type": "STRING", "length": 50 },
			{"field": "Updated_By",  "type": "STRING", "length": 50 },
			{"field": "Created_Date","type": "DATE",   "length": false },
			{"field": "Updated_Date","type": "DATE",   "length": false }
		]
	},
    { 
		"table": "tb_Corporate_Reviewer_Levels", 
		"schema":[
			{"field": "Account",     "type": "STRING", "length": 20 },
			{"field": "Role_Code",   "type": "STRING", "length": 5 },
			{"field": "Level_ID",    "type": "STRING", "length": 50 },
			{"field": "Level",       "type": "STRING", "length": 150 },
			{"field": "Created_By",  "type": "STRING", "length": 50 },
			{"field": "Updated_By",  "type": "STRING", "length": 50 },
			{"field": "Created_Date","type": "DATE",   "length": false },
			{"field": "Updated_Date","type": "DATE",   "length": false }
		]
	},
    { 
		"table": "tb_Corporate_Staging", 
		"schema":[
			{"field":"Transaction_ID",	 "type": "STRING",  "length": false },
			{"field":"Payload",			 "type": "STRING",  "length": 4000 },
			{"field":"Account_Number",	 "type": "STRING",  "length": 20 },
			{"field":"Stage",			 "type": "STRING",  "length": 50 },
			{"field":"Transaction_Type", "type": "STRING",  "length": 50 },
			{"field":"Amount",			 "type": "DOUBLE",  "length": false },
			{"field":"Account_To",		 "type": "STRING",  "length": 20 },
			{"field":"Date_Initiated",	 "type": "DATE",    "length": false },
			{"field":"Date_Approved",	 "type": "DATE",    "length": false },
			{"field":"Is_Fully_Reviewed","type": "BOOLEAN", "length": false }

		]
	},
    { 
		"table": "tb_Corporate_Audit_Trail", 
		"schema":[
			{"field": "Transaction_ID",	"type": "STRING", "length": 50 },
			{"field": "Stage",			"type": "STRING", "length": 50 },
			{"field": "Name",			"type": "STRING", "length": 100 },
			{"field": "Date_Changed",	"type": "DATE",   "length": false },
			{"field": "Comments",		"type": "STRING", "length": 4000 },
			{"field": "Status",			"type": "BOOLEAN","length": false },
			{"field": "Customer_ID",    "type": "STRING", "length": 50 }
		]
	},
	{ 
		"table" :"tb_Corporate_Mandatees", 
		"schema":[
			{"field": "First_Name",			"type": "STRING", 	"length": 100 },
			{"field": "Surname",			"type": "STRING", 	"length": 100 },
			{"field": "Other_Names",		"type": "STRING", 	"length": 100 },
			{"field": "Mobile_Number",		"type": "STRING", 	"length": 50 },
			{"field": "Email_Address",		"type": "STRING", 	"length": 150 },
			{"field": "Gender",				"type": "STRING", 	"length": 10 },
			{"field": "National_ID",		"type": "STRING", 	"length": 50 },
			{"field": "DOB",				"type": "DATE", 	"length": false },
			{"field": "Account_Number",		"type": "STRING", 	"length": 20 },
			{"field": "Mandate_Role_Code",	"type": "STRING", 	"length": 5 },
			{"field": "Limit_Code",			"type": "STRING", 	"length": 5 },
			{"field": "Mandatory_Signatory","type": "BOOLEAN",  "length": false },
			{"field": "Created_On",			"type": "DATE",     "length": false },
			{"field": "Created_By",			"type": "STRING",   "length": 50 },
			{"field": "Approved",			"type": "BOOLEAN",  "length": false },
			{"field": "Approved_By",		"type": "STRING",   "length": 50 },
			{"field": "Approved_On",		"type": "DATE",     "length": false },
			{"field": "Approved_Remarks",	"type": "STRING",   "length": 4000 },
			{"field": "Expires",			"type": "BOOLEAN",  "length": false },
			{"field": "Expiry_Date",		"type": "DATE",     "length": false }
		]
	},
	{ 
		"table" :"tb_Corporate_Profile", 
		"schema":[
			{"field": "Company_Name",		"type": "STRING", "length": 150 },
			{"field": "Registration_Number","type": "STRING", "length": 50 },
			{"field": "Mobile_Number",		"type": "STRING", "length": 50 },
			{"field": "Account_Number",		"type": "STRING", "length": 20 },
			{"field": "Signatory_Count",	"type": "INTEGER", "length": false },
			{"field": "Company_Limit",		"type": "DOUBLE", "length": false },
			{"field": "Account_Status",		"type": "STRING", "length": 50 },
			{"field": "Currency",			"type": "STRING", "length": 5 },
			{"field": "Account_Type",		"type": "STRING", "length": 50 },
			{"field": "Email_Address",		"type": "STRING", "length": 150 },
			{"field": "Customer_ID",		"type": "STRING", "length": 50 },
			{"field": "Created_On",			"type": "DATE",   "length": false },
			{"field": "Created_By",			"type": "STRING",  "length": 50 },
			{"field": "Approved",			"type": "BOOLEAN","length": false },
			{"field": "Approved_By",		"type": "STRING", "length": 50 },
			{"field": "Approved_On",		"type": "DATE",   "length": false },
			{"field": "Approve_Remarks",	"type": "STRING", "length": 4000 }
		]
	}
]