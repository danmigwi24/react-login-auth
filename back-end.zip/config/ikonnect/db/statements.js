//API-DB scripts
module.exports = {

	// Register
	'register' 					    : `
		EXEC A_SP_REGISTRATION 
			@FirstName                = '__firstname__',
			@SecondName               = '__secondname__',
			@LastName                 = '__lastname__',
			@PhoneNumber              = '__phonenumber__',
			@IdentificationType       = '__idtype__',
			@IdentificationID         = '__id__',
			@EmailAddress             = '__email__', 
			@DateofBirth              = '__dob__',
			@Gender                   = '__gender__',			
			@PARTIAL_REGISTRATION     = 0,
			@KRA_PIN                  = '__krapin__',
			@CREATEDBY                = 'SELF',
			@AccountNumber            = '__accountnumber__',
			@Account_Name             = '__t24AccountName__',
			@AccountType              = '__accounttype__',
			@AccountDescription       = '__accountdescription__',			
			@AccountStatus            = 'OK',
			@CustomerID               = '__t24id__',
			@Currency                 = '__t24currency__',
			--- @TxnLimitAmount           = '__customerlimit__',
			@Channel                  = '__channel__',
			@BranchCode               = '__branchcode__',
			@Password_Hash            = '__password__',
			@Sector                   = '__sector__',
			@Industry                 = '__industry__',
			@DailyLimit               = '__dailyLimit__',
			@TxnLimitAmount           = '__transactionLimit__',
			@Category                 = '__category__'
	`,
	'failed.registration'           : `
		INSERT INTO tb_Failed_Registration (
			Phone_Number,
			First_Name,
			Second_Name,
			Last_Name,
			Email_Address,
			Identification_Type,
			Identification_ID,
			Created_On,
			Request_Type,
			Failure_Reason
		)

		VALUES (
			'__phone__',
			'__fname__',
			'__othername__',
			'__surname__',
			'__email__',
			'__idType__',
			'__idNumber__',
			'__createdOn__',
			'__type__',
			'__reason__'
		)
	`,
	'add.foreign.citizen'           : `
		EXEC A_SP_NON_CITIZEN_ACC_OPENING_INSERT 
		@First_Name 		= '__firstname__',
		@Second_Name 		= '__othername__',
		@Last_Name 			= '__surname__',
		@Phone_Number 		= '__phone__',
		@Email_Address 		= '__email__',
		@DOB  				= '__dob__',
		@Gender 			= '__gender__',
		@ID_Type 			= '__idType__',
		@ID_Number 			= '__idNumber__',
		@Product_Code 		= '__product__'
	`,
	'all-account-open-attempts'	: `
		EXEC A_SP_ACCOUNT_OPENING 
		@Account_No 		= '__account__',
		@Product_Code 		= '__productCode__',
		@Customer_ID 		= '__customerId__',
		@Currency 			= '__currency__',
		@Mobile_Number 		= '__phone__',
		@Email_Address 		= '__email__',
		@Gender 			= '__gender__',
		@Status_Code 		= '__code__',
		@Branch_Code 		= '__branchCode__',
		@Status_Message 	= '__message__'
	`,
	'account.opening.attempt'       : `
		insert into tb_Account_Opening (
			Product_Code,
			Customer_ID,
			Account_No,
			Currency,
			Mobile_Number,
			Email_Address,
			Gender,
			Status_Code,
			Created_By,
			Created_On,
			Branch_Code,
			Status_Message
		)
		
		values (
			'__productCode__',
			'__customerId__',
			'__account__',
			'__currency__',
			'__phone__',
			'__email__',
			'__gender__',
			'__statusCode__',
			'__createdBy__',
			'__created__',
			'__branchCode__',
			'__statusMessage__'
		)	
	`,
	'registration.documents.add'    :`
		EXEC A_SP_ADD_REGISTRATION_DOCUMENTS 
			@userName = '__username__',
			@docType  = '__doctype__',
			@docPath  = '__docpath__'	
	`,
	'customer-audit-trail'	: `
		EXEC A_SP_IB_AUDIT_TRAIL_INSERT 
		@User_Name 			= '__username__',
		@Module 			= '__module__',
		@Module_Id 			= '__moduleId__',
		@Active_Page 		= '__page__',
		@Activity 			= '__activity__',
		@Customer_Account 	= '__account__',
		@Customer_ID 		= '__customerId__',
		@Log_Date 			= '__date__',
		@Log_Time			= '__time__',
		@Date_Time 			= '__dateTime__',
		@Channel 			= 'IB',
		@IP_Address 		= '__ip__',
		@Workstation  		= '__device__'
	`,

	// Security Questions
	'security.questions'			: `SELECT Reference, Question FROM [tb_Security_Question] `,
	'security.answers'  			: `SELECT Security_Question_Answers, Reset_Questions, Questions_Blocked, Password_History FROM [tb_Customer_Validation] WHERE User_Name = '__username__' `,
	'set.answers'       			: `UPDATE [tb_Customer_Validation] SET Security_Question_Answers = '__securityanswers__' WHERE User_Name = '__username__' `,
	'block.questions'       	    : `UPDATE [tb_Customer_Validation] SET Questions_Blocked = 1, Questions_Blocked_By = '__blockedby__', Questions_Blocked_On = '__blockedon__' WHERE User_Name = '__username__' `,
	'update.password.history'       : `

		UPDATE [tb_Customer_Validation] SET Password_History = '__passwordHashes__', Last_Password_Change = '__lastpasswordchange__', Previous_Login_Date = Last_Login_Date, Last_Login_Date = '__lastpasswordchange__' WHERE User_Name = '__username__' 
	`,
	'update.failed.login'           : `
		EXEC A_SP_LOGIN_ATTEMPT
			@User_Name      = '__username__',
			@Failure_Reason = '__failurereason__',
			@IP_Address     = '__ip__',
			@Status_Code    = '__code__'
		
	`,
	'update.successful.login'       : `
		UPDATE [tb_Customer_Validation] SET Previous_Login_Date = Last_Login_Date, Last_Login_Date = '__currentdate__' WHERE User_Name = '__username__' 
		
	`,

	//chat service
	'open.ticket': `
		EXEC A_SP_TICKET_OPEN
			@Ticket_Number = '__ticket__',
			@User_Name     = '__username__',
			@TicketType    = '__type__',
			@Title         = '__title__'
	`,
	'assign.ticket': `
		EXEC A_SP_TICKET_ASSIGN
			@Ticket_Number = '__ticket__',
			@Assigned_To   = '__assignedTo__'
	`,
	'close.ticket': `
		EXEC A_SP_TICKET_CLOSE 
			@Ticket_Number = '__ticket__'
	`,
	'forex.ticket': `
		EXEC A_SP_NEW_FX_TICKET 
			@Ticket_No = '__ticket__',
			@User_Name = '__username__',
			@Account_From = '__creditAccount__',
			@Account_To = '__debitAccount__',
			@Dr_Currency = '__drCurrency__',
			@Cr_Currency = '__crCurrency__',
			@Txn_Type = '__txnType__',
			@Amount = '__amount__',
			@Negotiated_Rate = '__rate__'
	`,

	// Auth
	'update.otp'         			: ` UPDATE [tb_Customer_Validation]	 SET OTP = '__otp__', OTP_Used = '0', OTPTime = '__otptime__' WHERE User_Name = '__username__' `,
	'expire.otp'         			: ` UPDATE [tb_Customer_Validation]	 SET OTP_Used = '1' WHERE User_Name = '__username__' `,
	'get.otp'						: `SELECT OTP, OTP_Used, OTPTime, Profile_Session_Id from tb_Customer_Validation where User_Name = '__username__'`,
	'update.trials'      			: ` EXEC A_SP_UPDATE_PIN_TRIALS @username = '__username__' `,
	'reset.trials'       			: ` UPDATE  [tb_Customer_Validation] SET Trials = 0 WHERE  User_Name = '__username__' `,
	'password.reset'     			: ` UPDATE [tb_Customer_Validation] SET Password_Hash = '__hash__' WHERE User_Name = '__username__' `,
	'first.login'        			: ` UPDATE [tb_Customer_Validation] SET First_Login = 0, Password_Hash = '__hash__', Security_Question_Answers = '__securityanswers__' WHERE User_Name = '__username__' `,
	'questions.reset'        	    : ` UPDATE [tb_Customer_Validation] SET Security_Question_Answers = '__securityanswers__', Reset_Questions = 0 WHERE User_Name = '__username__' `,
	'password-policy'        	    : ` SELECT * from [tb_password_policy]`,
	'password-blacklist'        	: ` SELECT * from [tb_Password_Black_List]`,

	// Checks
	'user.exists'        			: ` SELECT * from [tb_Customer_validation] where User_Name = '__username__' `,
	'get.account.status' 			: ` SELECT Description FROM [tb_Status_Code] WHERE Status_Code =  ( 
		Select Account_Status from [tb_Customer_validation] where User_Name = '__username__' and Related_Table = 'tb_Customer_Validation'
	) `,

	// Profile
	'profile' 						: `EXEC A_SP_CUSTOMER_PROFILE @User_Name = '__username__' `,
	'get.deposit.accounts'          : `SELECT * FROM tb_FD_Call_Deposit_Accounts where EMail_Address = '__email__'`,
	// Mandates
	'get.mandate.details'   		: `EXEC A_SP_FETCH_MANDATE_DETAILS @userId = '__userid__', @AccountNo = '__accountNumber__'`,
	'get.txn.audit.trail'           : `
		EXEC A_SP_USER_CAN_VIEW_CORPORATE_TXN 
			@txId       = '__txId__' ,
			@stage      = '__stage__',
			@level      = '__level__',
			@userId     = '__userId__',
			@account    = '__account__'
	`,
	'get.txn.audit.trail.approvers' : `

			--HANDLE ANY UNCLOSED CURSORS
			IF CURSOR_STATUS('global','CLOSE_CORP')>=-1
			BEGIN
				DEALLOCATE CLOSE_CORP
			END;
			
			-- create a temporary table to hold our authorizers
			drop table if exists #authorizers
			create table #authorizers ( mandateeClass nvarchar (20 ) )
			
			-- declare our variables including our cursor
			declare @email   nvarchar(100),
					@account nvarchar(100),
					@auditDetails   CURSOR,
					@txId    nvarchar(100) = '__txId__', 
					@stage   nvarchar(100) = '__stage__';
			
			-- get email and account number for each entry in the audit trail (filtered by the transaction id)
			set @auditDetails = cursor for
				select Name, ( select Account_Number from tb_Corporate_Staging where transaction_ID = @txId ) as Account
				from tb_Corporate_Audit_Trail where Transaction_ID = @txId and Stage = @stage and Status = 1;
			
			open @auditDetails
				fetch next from @auditDetails into @email, @account
			
				while @@FETCH_STATUS = 0
					begin
						-- loop through each result and insert into the temporary table
						insert into #authorizers 
						select Mandate_Class from tb_Corporate_Mandatees 
						where Email_Address = @email and Account_Number = @account
			
						fetch next from @auditDetails into @email, @account
					end
			
			close @auditDetails
			deallocate @auditDetails
			
			-- select the reult from the table then delete it
			select * from #authorizers
			drop table #authorizers
	`,
	'approve.transaction'           : ``,

	// Update mandate transactions
	'get.review.status'             : `
		EXEC A_SP_FETCH_REVIEW_STATUS 
			@transactionId = '__transactionId__',
			@account	   = '__account__',
			@reviewerLevel = '__reviewerLevel__',
			@userId		   = '__userId__'
	`,
	'update.review.status'          : `
		EXEC A_SP_UPDATE_REVIEW_STATUS 
			@transactionId = '__transactionId__',
			@roleCode      = '__roleCode__',
			@userId        = '__userId__',
			@stage         = '__nextLevel__',
			@reviewerLevel = '__reviewerLevel__'
	`,
	'reject.transaction'            : ` 
		EXEC A_SP_REJECT_TRANSACTION 
			@transactionId = '__transactionId__',
			@stage         = '__stage__',
			@userId        = '__userId__', 
			@remarks       = '__remarks__',
			@mandateeClass = '__mandateeClass__',
			@reviewerLevel = '__reviewerLevel__'
	`,
	'add.reviewer.level'            : `
		EXEC A_INSERT_REVIEWER_LEVEL
			@AccountNumber     = '__account__',
			@Role_Code         = '__roleCode__',
			@Reviewer_Count    = '__reviewerCount__',
			@Level_Description = '__narration__',
			@Created_By        = '__creatorId__'
	`,
	'add.mandatee'                  : `
		EXEC A_SP_CORPORATE_MANDATEE_REGISTRATION
			@CreatedBy              = '__creatorId__',
			@AccountNumber          = '__account__', --Company/Cust Core account, enable account linking
			@Email_Address          = '__email__', ---This is the user_name
			@First_Name             = '__firstname__',
			@Surname                = '__surname__',
			@Other_Names            = '__othername__',
			@Mobile_Number          = '__phone__',
			@Gender                 = '__gender__',
			@ID_Type                = '__idType__',
			@National_ID            = '__idnumber__',
			@KRA_PIN                = '__kraPin__',
			@DOB                    = '__dob__',
			@Mandate_Role_Code      = '__roleCode__',
			@Limit_Amount           = '__limit__',
			@Mandatory_Signatory    = '__isMandatorySignatory__',
			@Approved_Remarks       = '__narration__',
			@Approved_By			= '__userId__',
			@Expires                = 0,
			@Expiry_Date            = '2030-01-01 12:01:03',
			@Reviewer_Level         = '__reviewerLevel__',
			@Channel                = 'IB'
	`,
	'update.mandatee'               : `
		update tb_Corporate_Mandatees
		set
			Mandate_Role_Code = '__roleCode__',
			Mandate_Class     = '__mandateeClass__',
			Reviewer_Level    = '__reviewerLevel__',
			Expires           = '__expires__',
			Expiry_Date       = '__expiryDate__'
		where
			Email_Address     = '__userId__'
	`,
	
	// Sms
	'cbkonnect.sms' 				: ` 
		EXEC A_SP_INSERT_SMS
			@MobileNumber = '__phonenumber__' ,
			@AccountNo    = '__username__',
			@Message      = '__message__',
			@Channel      = 'IB',
			@TXN_TYPE     = 'IB_OTP',
			@FIELD100     = 'IB_OTP'
	`,

	// Bulk Uploads
	'insert.bulk.transaction'     	: `
		insert into tb_Bulk_Transactions
			(
				Batch_Number,
				Reference_Number,
				Sender_Account,
				Sender_Name,
				Recipient_Mobile_No,
				Recipient_Account_Number,
				Recipient_Account_Name,
				Transaction_Type,
				Amount,
				Narration,
				Created_By,
				Bank_Code,
				Recipient_Bank_Name,
				Sort_Code,
				Swift_Code,
				Branch_Code,
				Currency, 
				Payload,
				Processed,
				Error_Message,
				Network_Provider,
				IPSL_Destination
			)

			values (
				'__batchNumber__',
				'__TransactionId__',
				'__debitAccount__',
				'__debitAccountName__',
				'__MobileNumber__',
				'__AccountNumber__',
				'__AccountName__',
				'__type__',
				'__Amount__',
				'__Narration__',
				'__initiator__',
				'__BankCode__',
				'__BankName__',
				'__SortCode__',
				'__SwiftCode__',
				'__Branch_Code__',
				'__Currency__',
				'__Payload__',
				0,
				'',
				'__NetworkProvider__',
				'__Destination__'
			)
	`,
	'update-bulk-staging-charges': `UPDATE tb_Corporate_Staging set Total_Charge = '__totalcharge__', Total_excise_Duty = '__totaltax__' WHERE Transaction_ID = '__txnId__' AND Transaction_Type = '__txType__'`,
	'insert.corporate.staging'    	: `
		insert into tb_Corporate_Staging
			(
				Transaction_ID,
				Transaction_Count,
				Account_Number,
				Stage,
				Transaction_Type,
				Amount,
				Account_To,
				Date_Initiated,
				Is_Fully_Reviewed,
				Initiated_By,
				Is_Bulk_Transaction,
				Processed,
				Inputter_Approved,
				Network_Provider,
				Currency,
				Per_Txn_Limit,
				Daily_Txn_Limit,
				Name102,
				Phone_Number,
				Cr_Currency
			)

			values (			
				'__batchNumber__',
				'__txcount__',
				'__debitAccount__',
				'INPUTTER',
				'__type__',
				'__total__',
				'__Account_To__',
				'__txDate__',
				'__Is_Fully_Reviewed__'	,
				'__Initiated_By__',
				'__Is_Bulk_Transaction__',
				0,
				0,
				'__NetworkProvider__',
				'__Currency__',
				'__perTransactionLimit__',
				'__dailyTransactionLimit__',
				'__name__',
				'__phoneNumber__',
				'__CrCurrency__'
			)
	`, 
	'reject.corporate.staging'    	: `
	update tb_Corporate_Staging set Processed = 1, Reject_Reason = '__comments__' where Transaction_ID = '__transactionId__'
	`, 
	'insert.corporate.audit.trail'	: `
		--- update the corporate audit trail table

		insert into tb_Corporate_Audit_Trail
			(
				Transaction_ID,
				Stage,
				Name,
				Date_Changed,
				Comments,
				Status,
				Customer_ID
			)
			values (
				'__batchNumber__',
				'INPUTTER',
				'__initiator__',
				'__txDate__',
				'Initial Input',
				1,
				'__initiator__'
			)
	`,
	'stage.corporate.transaction'   :`
			insert into tb_Corporate_Staging (
				Transaction_ID,
				Transaction_Count,
				Payload,
				Account_Number,
				Stage,
				Transaction_Type,
				Name102,
				Amount,
				Account_To,
				Date_Initiated,
				Is_Fully_Reviewed,
				Is_Bulk_Transaction,
				Inputter_Approved,
				Reviewer_Level,
				Initiated_By
			)			
			values (			
				'__transactionId__',
				1,
				'__payload__',
				'__debitAccount__',
				'__roleCode__',
				'__transactionType__',
				'__username__',
				'__amount__',
				'__account__',
				'__transactionDate__',
				0,
				0,
				0,
				'__level__',
				'__userId__'
			);			
			
			EXEC A_SP_UPDATE_REVIEW_STATUS
				@transactionId = '__transactionId__',
				@roleCode      = '__roleCode__',
				@userId        = '__userId__',
				@stage         = '__roleCode__',
				@reviewerLevel = '__level__'	
	`,
	'get.bulk.uploads'              :` SELECT * From tb_Corporate_Staging where Initiated_By = '__email__' and Processed = 0 and Is_Bulk_Transaction = 1 and Inputter_Approved = 0`,
	'get.approved.bulk.uploads'     :` SELECT * From tb_Corporate_Staging where Initiated_By = '__email__' and Processed = 1`,
	'get.batch.bulk.uploads'     :` SELECT * From tb_Bulk_Transactions where Batch_Number = '__batchNumber__'`,
	'fetch.account.mandatees' 	: `EXEC A_SP_FETCH_MANDATE_DETAILS @userId = '__username__', @AccountNo = '__accountNumber__'`,
	'bulk.uploads.report' 	    : `EXEC A_RPT_Bulk_Txns @AccountNo = '__username__', @DateFrom = '__dateFrom__', @DateTo = '__dateTo__'`,
	'account.manadatees.report'  : `EXEC A_RPT_Corporate_Users @AccountNo = '__username__'`,
	'itax.txn.report'			: `EXEC A_SP_ITAX_TXNS @Channel = 'IB', @Account_No = '__debitAccount__'`,
	'account.login.report'  : `EXEC A_RPT_LOGIN_ATTEMPTS @UserName = '__username__'`,
	'all.transactions.report' 	    : `EXEC A_RPT_All_Txns @AccountNo = '__username__', @DateFrom = '__dateFrom__', @DateTo = '__dateTo__'`,
	'get.account.mandatees'     :` SELECT * From tb_Corporate_Mandatees where Account_Number = '__accountNumber__'`,
	'fetch.unprocessed.bulk.transactions' : `
		SELECT Payload from tb_Bulk_Transactions where Processed = 0 AND  ISNULL(Error_Message,'') = '' and Batch_Number = (
			select Transaction_ID from tb_Corporate_Staging where Is_Fully_Reviewed = 1 and Is_Bulk_Transaction = 1 and Processed = 0
		)	
	`,
	'delete.bulk.upload'            : `
		delete from tb_Corporate_Staging where Transaction_ID = '__batchNumber__';
		delete from tb_Bulk_transactions where Batch_Number   = '__batchNumber__';
	
	`,
	'fully.approve' : `
		update tb_Corporate_Staging set Is_Fully_Reviewed = 1, Processed = 1, Date_Approved = '__txDate__' where Transaction_ID = '__transactionId__';
		insert into tb_Corporate_Audit_Trail
		(
			Transaction_ID,
			Stage,
			Name,
			Date_Changed,
			Comments,
			Status,
			Customer_ID
		)
		values (
			'__transactionId__',
			'__stage__',
			'__userId__',
			'__txDate__',
			'Full Approval',
			1,
			'__userId__'
		)
	`,
	'partially.approve' : `
		insert into tb_Corporate_Audit_Trail
		(
			Transaction_ID,
			Stage,
			Name,
			Date_Changed,
			Comments,
			Status,
			Customer_ID
		)
		values (
			'__transactionId__',
			'__stage__',
			'__userId__',
			'__txDate__',
			'Approval',
			1,
			'__userId__'
		)
	`,
	'mandates.bulk.stage' : `
		insert into tb_Corporate_Audit_Trail
		(
			Transaction_ID,
			Stage,
			Name,
			Date_Changed,
			Comments,
			Status,
			Customer_ID,
			Reviewer_Level,
			Mandatee_Class
		)
		values (
			'__batchNumber__',
			'__roleCode__',
			'__email__',
			'__txDate__',
			'__comments__',
			1,
			'__userId__',
			0,
    		'__mandateClass__'
		)

		update tb_Corporate_Staging set Inputter_Approved = 1 where Transaction_ID = '__batchNumber__'
	`,
	
	// Soft Token API
	'soft.token.profile'            : `EXEC A_SP_GET_SOFT_TOKEN_PROFILE @email = '__email__'`,
	'soft.token.activate'           : `update tb_Customer_Token_Validation set First_Login = 0, Password_Hash = '__hashed__', IMEI = '__imei__' where User_Name = '__email__'`,
	'soft.token.change.pin'         : `update tb_Customer_Token_Validation set Password_Hash = '__newPin__' where User_Name = '__email__'`,
	'soft.token.update.imei2'       : `update tb_Customer_Token_Validation set IMEI2 = '__imei__' where User_Name = '__email__'`,
	'soft.token.update.trials'      : `EXEC A_SP_UPDATE_SOFT_TOKEN_PIN_TRIALS @email = '__email__'`,
	'soft.token.reset.trials'       : `
		update tb_Customer_Token_Validation set Trials = 3 where User_Name = '__email__'; 
		select Trials as trialsRemaining from tb_Customer_Token_Validation where User_Name = '__email__';
	`,
	'soft.token.update.otp'         : `UPDATE tb_Customer_Validation SET OTP = '__hashed__', OTP_Used = '0',  OTPTime = '__otptime__' WHERE User_Name = '__email__'`,
	'update-user-token'         : `UPDATE tb_Customer_Validation SET Profile_Activation_Token = '__token__' WHERE User_Name = '__email__'`,
	'update-sesion-id'         : `UPDATE tb_Customer_Validation SET Profile_Session_Id = '__sessionId__' WHERE User_Name = '__email__'`,
	'fetch-activation-token'  	: `SELECT Profile_Activation_Token FROM [tb_Customer_Validation] WHERE User_Name = '__username__' `,
	'fetch-user-session-token'  : `SELECT Profile_Session_Id FROM [tb_Customer_Validation] WHERE User_Name = '__username__' `,
	'fetch-pesalink-banks': `SELECT * FROM tb_Pesalink_Bank_List`,
	'fetch-banks': `SELECT * FROM tb_Bank`,
	'fetch-branches': `SELECT * FROM tb_Bank_Branch WHERE BankCode = '__bankCode__'`,
	'update.limit'                  : `
			EXEC A_SP_UPDATE_ACCOUNT_LIMITS
				@Account_No = '__account__',
				@PerTxnLimit = '__txnLimit__',
				@Daily_Limit = '__dailyLimit__',
				@Txn_Reference = '__ref__'
	`,
	'link.account'                  : `
		EXEC A_SP_ACCOUNT_LINKING
			@EmailAddress     = '__email__',
			@AccountNumber    = '__accountNumber__',
			@PhoneNumber      = '__phone__',	
			@IdentificationID = '__idNumber__',
			@Currency         = '__currency__',
			@Account_Name     = '__accountName__',
			@AccountStatus    = '__accountCondition__',	
			@TxnLimitAmount   = '__perTxnLimit__',
			@DailyLimit       = '__dailyTxnLimit__',
			@Sector           = '__sector__', 
			@Industry         = '__industry__',	
			@BranchCode       = '__branch__',
			@CustomerID       = '__customerNumber__',
			@Category         = '__category__',
			@Channel          = 'IB',
			@CREATEDBY        = 'SELF'	
	
	`,
	
	// Beneficiaries
	'get-beneficiaries'  :`SELECT *  FROM tb_Beneficiary where User_Name = '__username__'`,
	'get.bulk.beneficiaries'  :`SELECT *  FROM tb_Bulk_Beneficiary where User_Name = '__username__'`,
	'insert.beneficiary' : `
		EXEC A_SP_BENEFICIARY_INSERT
			@email       = '__email__',
			@txnType     = '__txnType__',
			@accountName = '__accountName__',
			@account     = '__account__'	
	`,
	'insert.bulk.beneficiary' : `
		insert into tb_Bulk_Beneficiary (
			Reference,
			User_Name,
			Beneficiary_Name,
			Account_Number,
			Txn_Count,
			Total_Value,
			Account_Currency,
			Per_Transaction_Limit,
			Daily_Transaction_Limit,
			Transaction_Type,
			Bulk_Transactions,
			Created_On,
			Created_By
		)
		values (
			'__reference__',
			'__username__',
			'__beneficiaryName__',
			'__accountNumber__',
			'__txnCount__',
			'__totalValue__',
			'__accountCurrency__',
			'__perTransactionLimit__',
			'__dailyTransactionLimit__',
			'__txnType__',
			'__data__',
			'__created__',
			'__username__'
		)
	`,
	'create.beneficiary' : `
		insert into tb_Beneficiary (
			User_Name,
			Txn_Type,
			Beneficiary_Name,
			Beneficiary_Account,
			Account_Type,
			Bank_Name,
			Branch_Name,
			Created_On,
			Swift_Code,
			Physical_Address,
			Beneficiary_Address,
			Intermediary_Bank_Name,
			Intermediary_Bank_SwiftCode,
			Credit_Currency
		)
		values (
			'__email__',
			'__txnType__',
			'__accountName__',
			'__account__',
			'__txnType__',
			'__bank__',
			'__branch__',
			'__created__',
			'__swiftCode__',
			'__physicalAddress__',
			'__beneficiaryAddress__',
			'__intermediaryBankName__',
			'__intermediaryBankSwiftCode__',
			'__creditCurrency__'
		)
	`,
	'update.single.beneficiary': `UPDATE tb_Beneficiary SET 
		Txn_Type = '__txnType__',
		Beneficiary_Name = '__accountName__',
		Account_Type = '__txnType__',
		Bank_Name = '__bank__',
		Branch_Name = '__branch__',
		Swift_Code = '__swiftCode__',
		Physical_Address = '__physicalAddress__',
		Beneficiary_Address = '__beneficiaryAddress__',
		Intermediary_Bank_Name = '__intermediaryBankName__',
		Intermediary_Bank_SwiftCode = '__intermediaryBankSwiftCode__',
		Credit_Currency = '__creditCurrency__'
		WHERE User_Name = '__email__' and Beneficiary_Account = '__account__'
		`,
	'delete.beneficiary'  : `DELETE FROM tb_Beneficiary where User_Name = '__username__' and Beneficiary_Account = '__account__'`,
	'delete.mandatee'  : `DELETE FROM tb_Corporate_Mandatees where Email_Address = '__email__' and Account_Number = '__accountNumber__'`,

	'fetch.locksavings.profile' : `EXEC A_SP_Get_LockSavingDetails @MobileNo = '__phone__'`,
	'loan.leads' : `
		insert into tb_Loan_Leads (
			Full_Name,
			Email,
			Mobile_Number,
			Subject,
			Loan_Type,
			Message,
			Amount,
			Created_On,
			Processed,
			Processed_By,
			Processed_On,
			Remarks
		)
		values (
			'__name__',
			'__email__',
			'__phone__',
			'__subject__',
			'__loanType__',
			'__message__',
			'__amount__',
			'__created__',
			0,
			'',
			'',
			''
		)
	`,
	'contactus.leads' : `

		insert into tb_Contact_Us (
			First_Name,
			Last_Name,
			Email_Address,
			Phone_Number,
			Tittle_Subject,
			Customer_Message,
			Country,
			IP_Address,
			Created_On
		)
		values (
			'__fname__',
			'__lname__',
			'__email__',
			'__phone__',
			'__subject__',
			'__message__',
			'kenya',
			'',
			'__created__'
		)
	`,
	//forex
	'fetch-forex-transactions': ` SELECT Reference, Currency_Bought, Currency_Sold, Exchange_Rate, Dr_Account, Cr_Account, Txn_Amount, Txn_Type, Trade_Date, Status_Code, Status_Desc from tb_FX_Txn_Staging where User_Name = '__username__'`,
	'fetch-order-alerts': `SELECT * from tb_FX_Limit_Order_Alert where Username = '__username__'`
}