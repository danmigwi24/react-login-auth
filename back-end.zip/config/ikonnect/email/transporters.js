module.exports = {
	ikonnectTransporter : {
		host : '192.168.5.165',
		port : 25,
		tls: { 
			rejectUnauthorized: false 
		}
	}
}	