const fs          = require('fs')
const path        = require('path')
const { mdToPdf } = require('md-to-pdf')

class ApiDoc {
	constructor () {
		this.apiName           = 'iKonnect API'
		this.servicesPath      = path.resolve ( `./services` )
		this.pathCount         = 0
		this.microserviceCount = 0
		this.port              = 0 
		this.ip                = '<server-ip>' 
		this.protocol          = 'http'
		this.routes
		this.parentPaths       = []	
	}
	async docFileExistsCheck(){

		// // console.log ( `API Documentation check ...` )

		//----------------------------------------------------------------

		let readmePath = path.resolve ( `./readme.md` )
		let isFile     = false

		
		try {
			isFile = fs.lstatSync( readmePath ).isFile()
		}
		catch ( e ) {}

		if (!isFile ){
			this.generate()
		}
		else {			
			// // console.log ( `API Doc exists`)
		}
	}
	async generate () {

		// // console.log ( `Generating API documentation ...`)
		console.time ( 'generated doc in ')

		//----------------------------------------------------------------

		this.paths = await this.getPaths ( this.servicesPath )
		
		// analyze api settings
		this.paths.map ( path => {

			let cfg          = require ( path )

			if ( cfg.name === 'api' ) {
				this.port   = cfg.settings.port
				this.routes = cfg.settings.routes

				this.routes.map ( route => {

					let entry = {
						path: route.path,
						globalAccess: false
					}
					if ( route.mappingPolicy === 'all' ){
						entry.globalAccess= true
					}

					this.parentPaths.push ( entry )
				})
				
			}

		})

		this.paths = this.paths.map ( path => {

			this.microserviceCount ++

			let cfg          = require      (  path    )
			let actions      = cfg.actions  || {}
			let methods      = Object.keys  (  cfg.methods  || {})
			let actionKeys   = Object.keys  (  actions )
			let actionConfig = []


			for ( let key of actionKeys ){

				let actCfg = {}
				let action = actions [ key ]

				actCfg.name = key

				if ( action.rest ){
					actCfg.path = this.parentPaths.filter ( p =>p.globalAccess && p ). map ( p => {
						return `${this.protocol}://${this.ip}:${this.port}${p.path}/${cfg.name}${action.rest}`
					})
					this.pathCount ++
				}
				if ( action.params ){
					actCfg.params= action.params

				}

				actionConfig.push( actCfg )
			}

			let mapped = {}
			mapped['micro-service'] = cfg.name

			if ( actionConfig.length > 0 ) {
				mapped.actions = actionConfig
			}

			if ( methods.length > 0 ) {
				mapped.methods = methods
			}

			return mapped	

		})

		// create a markdown file
		let md =  `# ${this.apiName}\n##### contains ${this.microserviceCount} independent services\n\n`

		this.paths.map ( ( path, index ) => {
			md += `### ${index+1}. ${path ['micro-service']} Service\n\n #### info\n \`\`\`javascript \n${JSON.stringify ( path, null, 4 )}\n\`\`\`\n\n`
		})

		// write markdown file
		fs.writeFileSync ( 'readme.md', md, 'utf8' )

		// generate document
		// await mdToPdf(
		// 	{ content: md }, 
		// 	{ 
		// 		dest           : 'readme.html',
		// 		highlight_style: `monokai`,
		// 		stylesheet     : ` https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/2.10.0/github-markdown.min.css`,
		// 		body_class     : `markdown-body`,
		// 		css            : `
		// 			.page-break               { page-break-after: always; }
		// 			.markdown-body            { font-size: 14px;font-family:nunito }
		// 			.markdown-body pre > code { white-space: pre-wrap; }
		// 		`,
		// 		pdf_options    : {
		// 			format         : 'A4',
		// 			margin         : '30mm 20mm',
		// 			printBackground: true
		// 		}, 
		// 		as_html        :true
		// 	}
		// ).catch ( console.error )

		//----------------------------------------------------------------
		
		console.timeEnd ( 'generated doc in ')

	}
	async getPaths ( path )  {
		return new Promise ( ( resolve, reject ) => {   
			let recursive = require("recursive-readdir");
	
			recursive ( path, ( err, files ) => {
				if ( err ) reject ( err )
				resolve ( files )
			})
	
		})
	}
}

new ApiDoc().generate()