# iKonnect API
##### contains 22 independent services

### 1. api Service

 #### info
 ```javascript 
{
    "micro-service": "api",
    "methods": [
        "authenticate",
        "authorize"
    ]
}
```

### 2. performance-analytics Service

 #### info
 ```javascript 
{
    "micro-service": "performance-analytics",
    "actions": [
        {
            "name": "audit",
            "path": [
                "http://<server-ip>:2020/api/performance-analytics/audit",
                "http://<server-ip>:2020/mock/performance-analytics/audit"
            ]
        },
        {
            "name": "trends",
            "path": [
                "http://<server-ip>:2020/api/performance-analytics/trends",
                "http://<server-ip>:2020/mock/performance-analytics/trends"
            ],
            "params": {
                "start": "string",
                "end": "string"
            }
        },
        {
            "name": "userTransactions",
            "path": [
                "http://<server-ip>:2020/api/performance-analytics/user-transactions",
                "http://<server-ip>:2020/mock/performance-analytics/user-transactions"
            ],
            "params": {
                "start": "string",
                "end": "string"
            }
        }
    ]
}
```

### 3. performance-monitor Service

 #### info
 ```javascript 
{
    "micro-service": "performance-monitor",
    "actions": [
        {
            "name": "run",
            "path": [
                "http://<server-ip>:2020/api/performance-monitor/run",
                "http://<server-ip>:2020/mock/performance-monitor/run"
            ]
        }
    ]
}
```

### 4. accounts-fixed-deposit Service

 #### info
 ```javascript 
{
    "micro-service": "accounts-fixed-deposit",
    "actions": [
        {
            "name": "new",
            "path": [
                "http://<server-ip>:2020/api/accounts-fixed-deposit/new",
                "http://<server-ip>:2020/mock/accounts-fixed-deposit/new"
            ],
            "params": {
                "amount": "number",
                "interest": "number"
            }
        }
    ]
}
```

### 5. auth-jwt Service

 #### info
 ```javascript 
{
    "micro-service": "auth-jwt",
    "actions": [
        {
            "name": "token",
            "path": [
                "http://<server-ip>:2020/api/auth-jwt/get-token",
                "http://<server-ip>:2020/mock/auth-jwt/get-token"
            ],
            "params": {
                "username": "string",
                "password": "string"
            }
        },
        {
            "name": "verify",
            "path": [
                "http://<server-ip>:2020/api/auth-jwt/verify-token",
                "http://<server-ip>:2020/mock/auth-jwt/verify-token"
            ],
            "params": {
                "token": "string"
            }
        }
    ]
}
```

### 6. auth-login Service

 #### info
 ```javascript 
{
    "micro-service": "auth-login",
    "actions": [
        {
            "name": "firstlogin",
            "path": [
                "http://<server-ip>:2020/api/auth-login/first-login",
                "http://<server-ip>:2020/mock/auth-login/first-login"
            ],
            "params": {
                "username": "string",
                "password": "string",
                "securityAnswers": "object"
            }
        },
        {
            "name": "login",
            "path": [
                "http://<server-ip>:2020/api/auth-login/login",
                "http://<server-ip>:2020/mock/auth-login/login"
            ],
            "params": {
                "username": "string",
                "password": "string"
            }
        },
        {
            "name": "getQuestions",
            "path": [
                "http://<server-ip>:2020/api/auth-login/get-questions",
                "http://<server-ip>:2020/mock/auth-login/get-questions"
            ]
        },
        {
            "name": "getAnswers",
            "path": [
                "http://<server-ip>:2020/api/auth-login/get-answers",
                "http://<server-ip>:2020/mock/auth-login/get-answers"
            ],
            "params": {
                "username": "string"
            }
        },
        {
            "name": "setAnswers",
            "path": [
                "http://<server-ip>:2020/api/auth-login/set-answers",
                "http://<server-ip>:2020/mock/auth-login/set-answers"
            ],
            "params": {
                "username": "string",
                "securityAnswers": "object"
            }
        },
        {
            "name": "verifyAnswer",
            "path": [
                "http://<server-ip>:2020/api/auth-login/verify-answer",
                "http://<server-ip>:2020/mock/auth-login/verify-answer"
            ],
            "params": {
                "username": "string",
                "securityAnswers": "object"
            }
        },
        {
            "name": "changePasswordVerifyAccount",
            "path": [
                "http://<server-ip>:2020/api/auth-login/change-password-verify-account",
                "http://<server-ip>:2020/mock/auth-login/change-password-verify-account"
            ],
            "params": {
                "username": "string",
                "securityAnswers": "object"
            }
        },
        {
            "name": "changePassword",
            "path": [
                "http://<server-ip>:2020/api/auth-login/change-password",
                "http://<server-ip>:2020/mock/auth-login/change-password"
            ],
            "params": {
                "username": "string",
                "password": "string",
                "otp": "string"
            }
        }
    ]
}
```

### 7. accounts-mandates Service

 #### info
 ```javascript 
{
    "micro-service": "accounts-mandates",
    "actions": [
        {
            "name": "fetchProfile",
            "path": [
                "http://<server-ip>:2020/api/accounts-mandates/fetch-profile",
                "http://<server-ip>:2020/mock/accounts-mandates/fetch-profile"
            ],
            "params": {
                "userId": "email"
            }
        },
        {
            "name": "updateRejectedTransaction",
            "path": [
                "http://<server-ip>:2020/api/accounts-mandates/update-rejected-transaction",
                "http://<server-ip>:2020/mock/accounts-mandates/update-rejected-transaction"
            ],
            "params": {
                "transactionId": "string",
                "userid": "email",
                "roleCode": "string",
                "transactions": "array"
            }
        },
        {
            "name": "updateTransaction",
            "path": [
                "http://<server-ip>:2020/api/accounts-mandates/update-transaction",
                "http://<server-ip>:2020/mock/accounts-mandates/update-transaction"
            ],
            "params": {
                "transactionId": "string",
                "account": "string",
                "amount": "number|optional",
                "userId": "email",
                "roleCode": "string",
                "authRules": "object|optional",
                "mandateType": "string|optional",
                "reviewerLevel": "number|optional"
            }
        },
        {
            "name": "rejectTransaction",
            "path": [
                "http://<server-ip>:2020/api/accounts-mandates/reject-transaction",
                "http://<server-ip>:2020/mock/accounts-mandates/reject-transaction"
            ],
            "params": {
                "transactionId": "string",
                "stage": "string",
                "userId": "email",
                "remarks": "string",
                "mandateeClass": "string",
                "reviewerLevel": "number"
            }
        },
        {
            "name": "addReviewerLevel",
            "path": [
                "http://<server-ip>:2020/api/accounts-mandates/add-reviewer-level",
                "http://<server-ip>:2020/mock/accounts-mandates/add-reviewer-level"
            ],
            "params": {
                "account": "string",
                "roleCode": "string",
                "reviewerCount": "number",
                "narration": "string",
                "creatorId": "email"
            }
        },
        {
            "name": "addMandatee",
            "path": [
                "http://<server-ip>:2020/api/accounts-mandates/add-mandatee",
                "http://<server-ip>:2020/mock/accounts-mandates/add-mandatee"
            ],
            "params": {
                "creatorId": "email",
                "account": "string",
                "userId": "email",
                "firstname": "string",
                "surname": "string",
                "othername": "string",
                "phone": "string",
                "gender": "string",
                "idType": "string",
                "idnumber": "string",
                "kraPin": "string",
                "dob": "string",
                "roleCode": "string",
                "mandateeClass": "string",
                "limit": "number",
                "isMandatorySignatory": "number",
                "narration": "string",
                "reviewerLevel": "number"
            }
        },
        {
            "name": "updateMandatee",
            "path": [
                "http://<server-ip>:2020/api/accounts-mandates/update-mandatee",
                "http://<server-ip>:2020/mock/accounts-mandates/update-mandatee"
            ],
            "params": {
                "roleCode": "string",
                "mandateeClass": "string",
                "reviewerLevel": "number",
                "expires": "number",
                "expiryDate": "string",
                "userId": "email"
            }
        }
    ],
    "methods": [
        "accountMapper",
        "pendingTxnMapper",
        "formatProfile"
    ]
}
```

### 8. auth-otp Service

 #### info
 ```javascript 
{
    "micro-service": "auth-otp",
    "actions": [
        {
            "name": "generate",
            "path": [
                "http://<server-ip>:2020/api/auth-otp/generate",
                "http://<server-ip>:2020/mock/auth-otp/generate"
            ],
            "params": {
                "username": "string"
            }
        },
        {
            "name": "validate",
            "path": [
                "http://<server-ip>:2020/api/auth-otp/validate",
                "http://<server-ip>:2020/mock/auth-otp/validate"
            ],
            "params": {
                "username": "string",
                "otp": {
                    "type": "string",
                    "length": 6
                }
            }
        }
    ]
}
```

### 9. bulk Service

 #### info
 ```javascript 
{
    "micro-service": "bulk",
    "actions": [
        {
            "name": "post",
            "path": [
                "http://<server-ip>:2020/api/bulk/post",
                "http://<server-ip>:2020/mock/bulk/post"
            ],
            "params": {
                "batchNumber": "string",
                "type": "string",
                "initiator": "string",
                "debitAccount": "string",
                "debitAccountName": "string",
                "total": "number",
                "txDate": "string",
                "txcount": "number",
                "transactions": "array"
            }
        }
    ]
}
```

### 10. info Service

 #### info
 ```javascript 
{
    "micro-service": "info",
    "actions": [
        {
            "name": "info",
            "path": [
                "http://<server-ip>:2020/api/info/info",
                "http://<server-ip>:2020/mock/info/info"
            ]
        }
    ]
}
```

### 11. registration Service

 #### info
 ```javascript 
{
    "micro-service": "registration",
    "actions": [
        {
            "name": "lookup",
            "path": [
                "http://<server-ip>:2020/api/registration/core-account-lookup",
                "http://<server-ip>:2020/mock/registration/core-account-lookup"
            ],
            "params": {
                "accountNumber": "string",
                "phoneNumber": "string"
            }
        },
        {
            "name": "new",
            "path": [
                "http://<server-ip>:2020/api/registration/new",
                "http://<server-ip>:2020/mock/registration/new"
            ],
            "params": {
                "firstname": "string",
                "secondname": "string",
                "lastname": "string",
                "phonenumber": {
                    "type": "string",
                    "length": 12
                },
                "idtype": "string",
                "id": "string",
                "email": "email",
                "dob": "string",
                "gender": "string",
                "krapin": "string",
                "branchcode": "string",
                "sector": "string",
                "industry": "string",
                "createdby": "string",
                "accountnumber": "string",
                "accounttype": "string",
                "accountdescription": "string",
                "t24AccountName": "string",
                "t24id": "string",
                "t24currency": "string",
                "customerlimit": "number",
                "channel": "string",
                "password": "string",
                "hasCoreAccount": "boolean",
                "kraPinChanged": "boolean"
            }
        },
        {
            "name": "sendActivationEmail",
            "path": [
                "http://<server-ip>:2020/api/registration/send-activation-email",
                "http://<server-ip>:2020/mock/registration/send-activation-email"
            ],
            "params": {
                "email": "email",
                "firstname": "string"
            }
        }
    ]
}
```

### 12. transactions Service

 #### info
 ```javascript 
{
    "micro-service": "transactions",
    "actions": [
        {
            "name": "request",
            "path": [
                "http://<server-ip>:2020/api/transactions/request",
                "http://<server-ip>:2020/mock/transactions/request"
            ],
            "params": {
                "action": "string",
                "payload": {
                    "type": "object"
                }
            }
        }
    ],
    "methods": [
        "generateRequest",
        "addParameters",
        "addTemplate",
        "applyPreHooks",
        "applyFormating",
        "applyEncoding",
        "applyHeaders",
        "applyPostHooks",
        "createUrl",
        "fetch",
        "parseResponse",
        "applyDecoding",
        "applyResponseformatting",
        "applyResponseHooks",
        "generateError"
    ]
}
```

### 13. messaging Service

 #### info
 ```javascript 
{
    "micro-service": "messaging",
    "actions": [
        {
            "name": "hello",
            "path": [
                "http://<server-ip>:2020/api/messaging/hello",
                "http://<server-ip>:2020/mock/messaging/hello"
            ],
            "params": {
                "message": "string"
            }
        }
    ],
    "methods": [
        "startChat",
        "updateChat",
        "getChats",
        "closeTicket",
        "socketServer"
    ]
}
```

### 14. users-profile Service

 #### info
 ```javascript 
{
    "micro-service": "users-profile",
    "actions": [
        {
            "name": "fetch",
            "path": [
                "http://<server-ip>:2020/api/users-profile/fetch",
                "http://<server-ip>:2020/mock/users-profile/fetch"
            ],
            "params": {
                "username": "email"
            }
        }
    ]
}
```

### 15. esb Service

 #### info
 ```javascript 
{
    "micro-service": "esb",
    "actions": [
        {
            "name": "coreAccountLookup",
            "path": [
                "http://<server-ip>:2020/api/esb/core-account-lookup",
                "http://<server-ip>:2020/mock/esb/core-account-lookup"
            ],
            "params": {
                "accountNumber": "string",
                "phoneNumber": "string"
            }
        }
    ]
}
```

### 16. core-email Service

 #### info
 ```javascript 
{
    "micro-service": "core-email",
    "actions": [
        {
            "name": "send",
            "path": [
                "http://<server-ip>:2020/api/core-email/send",
                "http://<server-ip>:2020/mock/core-email/send"
            ],
            "params": {
                "recipients": "string",
                "subject": "string",
                "message": "string",
                "template": {
                    "type": "object",
                    "optional": true,
                    "props": {
                        "name": "string",
                        "data": "object|optional"
                    }
                }
            }
        }
    ]
}
```

### 17. core-cache Service

 #### info
 ```javascript 
{
    "micro-service": "core-cache",
    "actions": [
        {
            "name": "hello",
            "path": [
                "http://<server-ip>:2020/api/core-cache/hello",
                "http://<server-ip>:2020/mock/core-cache/hello"
            ]
        }
    ]
}
```

### 18. core-database Service

 #### info
 ```javascript 
{
    "micro-service": "core-database",
    "actions": [
        {
            "name": "query",
            "path": [
                "http://<server-ip>:2020/api/core-database/query",
                "http://<server-ip>:2020/mock/core-database/query"
            ],
            "params": {
                "request-name": "string",
                "payload": "object",
                "setDbConn": "object|optional"
            }
        },
        {
            "name": "bulkQuery",
            "path": [
                "http://<server-ip>:2020/api/core-database/bulk-query",
                "http://<server-ip>:2020/mock/core-database/bulk-query"
            ],
            "params": {
                "requests": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "props": {
                            "request-name": "string",
                            "payload": "object"
                        }
                    }
                },
                "setDbConn": "object|optional"
            }
        }
    ],
    "methods": [
        "migrate"
    ]
}
```

### 19. core-logging Service

 #### info
 ```javascript 
{
    "micro-service": "core-logging"
}
```

### 20. core-queue Service

 #### info
 ```javascript 
{
    "micro-service": "core-queue",
    "actions": [
        {
            "name": "hello",
            "path": [
                "http://<server-ip>:2020/api/core-queue/hello",
                "http://<server-ip>:2020/mock/core-queue/hello"
            ]
        }
    ]
}
```

### 21. core-sms Service

 #### info
 ```javascript 
{
    "micro-service": "core-sms",
    "actions": [
        {
            "name": "cbkonnectSend",
            "path": [
                "http://<server-ip>:2020/api/core-sms/cbkonnect-send",
                "http://<server-ip>:2020/mock/core-sms/cbkonnect-send"
            ],
            "params": {
                "phonenumber": "string",
                "username": "string",
                "message": "string"
            }
        }
    ]
}
```

### 22. core-uploads Service

 #### info
 ```javascript 
{
    "micro-service": "core-uploads",
    "actions": [
        {
            "name": "bulkStream",
            "path": [
                "http://<server-ip>:2020/api/core-uploads/bulk-stream",
                "http://<server-ip>:2020/mock/core-uploads/bulk-stream"
            ]
        },
        {
            "name": "bankDocuments"
        },
        {
            "name": "bulk"
        }
    ],
    "methods": [
        "excelToJSON",
        "processExcel",
        "readBook",
        "formatData"
    ]
}
```

