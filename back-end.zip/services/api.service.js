"use strict"

const ApiGateway 	= require ( "moleculer-web" )
const cookie     	= require ( "cookie" )
const cookieParser 	= require('cookie-parser');
const fs        	= require ( "fs" )
const helmet 	 	= require('helmet');
const DeviceDetector = require('node-device-detector');
const detector 		= new DeviceDetector();
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw result.error }

module.exports = {
	name                 : "api",
	mixins               : [ ApiGateway ],
	settings             : {
		port			 : process.env.PORT || 3096,
		use				 : [
            cookieParser(),
			helmet(),
			helmet.contentSecurityPolicy({
				directives: {
				  defaultSrc: ["'self'"],
				  frameAncestors: ["'none'"]
				},
				//browserSniff: false
			  })
		],// Global Express middlewares
		httpServerTimeout: 180000,
		// https: {
		// 	key : fs.readFileSync ( './ssl/private.key'),
		// 	cert: fs.readFileSync ( './ssl/public.pem' ),
		// 	secureOptions: require('constants').SSL_OP_NO_TLSv1
		// },
		// Global CORS settings
        cors: {
            origin: "https://ikonnecttestapp.creditbank.co.ke:3000",
            methods: ["GET", "POST"],
            //allowedHeaders: "*",
            //exposedHeaders: "*",
            credentials: true,
            maxAge: null
        },
		rateLimit		 : {
            window: 10 * 1000,
            limit: 100,
            headers: true,
            key: (req) => {
                return req.headers["x-forwarded-for"] ||
                    req.connection.remoteAddress ||
                    req.socket.remoteAddress ||
                    req.connection.socket.remoteAddress;
            },
            //StoreFactory: CustomStore
        },
		routes			 : [
			{
				path            : "/api", //ikonnect/ib
				callOptions     : {
					timeout     : 60000,
					retries     : 0
				},
				whitelist		: [ "**" ],
				cors			: { 
					origin: "*",
					methods: ["POST"]
				},				
				use				: [], // Route-level Express middlewares.
				mergeParams		: true,
				authentication	: false,
				authorization	: false,
				autoAliases		: false,
				aliases          : {
					"POST core-logging/customer-audit-trail" : "core-logging.customerAuditTrail",
					"POST auth-login/get-answers" 	  		 : "auth-login.getAnswers",
					"POST auth-login/get-questions"   		 : "auth-login.getQuestions",
					"POST auth-login/change-password" 	  	 : "auth-login.changePassword",
					"POST registration/new" 				 : "registration.new",
					"POST registration/core-account-lookup"  : "registration.lookup",
					"POST registration/send-activation-email": "registration.sendActivationEmail",
					"POST registration/non-citizen" 		 : "registration.nonCitizen",
					"POST auth-login/first-login" 			 : "auth-login.firstlogin",
					"POST auth-login/question-reset" 		 : "auth-login.questionReset",
					"POST users-profile/fetch" 				 : "users-profile.fetch",
					"POST auth-login/password-can-be-used"   : "auth-login.passwordCanBeUsed",
					"POST users-profile/verify-token" 		 : "users-profile.verifyToken",
					"POST auth-login/block-questions" 		 : "auth-login.blockQuestions",
					"POST auth-login/set-answers" 			 : "auth-login.setAnswers",
					"POST core-iprs/check" 			 	  	 : "core-iprs.send",
					"POST accounts-mandates/fetch-profile"	 : "accounts-mandates.fetchProfile",
					"POST auth-login/user-session"   		 : "auth-login.generateSessionId",
					"POST auth-login/password-policy"   	 : "auth-login.passwordPolicy",
					"POST chat-service"						 : "core-database.query"
				},
				callingOptions	: {},
				bodyParsers     : {
					json         : {
						strict   : false,
						limit    : "1MB"
					},
					urlencoded: {
						extended : true,
						limit    : "1MB"
					}
				},
				mappingPolicy	: "restrict", // Available values: "all", "restrict"
				logging			: false,

				//get users IP
				onBeforeCall(ctx, route, req, res) {
					let clientIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
					let wrapperDevice = req.headers['user-device'] ? JSON.parse(req.headers['user-device']) : {}
					ctx.meta.clientIp = req.headers['user-device'] ? wrapperDevice.clientIp : clientIp
					const userAgent = req.headers['user-agent'];
					
					const auth = req.headers [ "authorization" ]
					if ( auth && auth.startsWith ( "Bearer " ) ) {
						ctx.meta.token = auth.slice ( 7 )
					}
					
					let userDevice = detector.detect(userAgent);
					let { os: { name: osName }, 
							client: { name: clientName, type: clientType}, 
							device: { type: deviceType, brand }} = userDevice;
					ctx.meta.userDevice = req.headers['user-device'] ? wrapperDevice : {osName, clientName, clientType, deviceType, brand, clientIp};
				}
			},
			{
				path            : "/ikonnect/ib",
				whitelist		: [ "accounts-mandates.*", 
									"core-logging.*", 
									"transactions.*", 
									"core-database.requestData",
									"fixed-deposits.*",
									"auth-login.*",
									"auth-otp.*",
									"bulk.*",
									"users-profile.*",
									"trade-finance.forexTicket"
								],
				cors			: { 
					origin: "*",
					methods: ["POST"]
				},				
				use				: [], // Route-level Express middlewares.
				mergeParams		: true,
				authentication	: true,
				authorization	: true,
				autoAliases		: true,
				callingOptions	: {},
				bodyParsers     : {
					json         : {
						strict   : false,
						limit    : "1MB"
					},
					urlencoded: {
						extended : true,
						limit    : "1MB"
					}
				},
				mappingPolicy	: "all", // Available values: "all", "restrict"
				logging			: false,

				//get users IP
				onBeforeCall(ctx, route, req, res) {
					let clientIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
					let wrapperDevice = req.headers['user-device'] ? JSON.parse(req.headers['user-device']) : {}
					ctx.meta.clientIp = req.headers['user-device'] ? wrapperDevice.clientIp : clientIp
					const userAgent = req.headers['user-agent'];
					
					const auth = req.headers [ "authorization" ]
					if ( auth && auth.startsWith ( "Bearer " ) ) {
						ctx.meta.token = auth.slice ( 7 )
					}
					
					let userDevice = detector.detect(userAgent);
					let { os: { name: osName }, 
							client: { name: clientName, type: clientType}, 
							device: { type: deviceType, brand }} = userDevice;
					ctx.meta.userDevice = req.headers['user-device'] ? wrapperDevice : {osName, clientName, clientType, deviceType, brand, clientIp};
				}
			},
			{
				path            : "/ikonnect",
				callOptions     : {
					timeout     : 300000,
					retries     : 0
				},
				whitelist		: [
					"ikonnect-loan.*",
					"trade-finance.*"
				],
				cors			: { 
					origin: "*",
					methods: ["POST"]
				},				
				use				: [], // Route-level Express middlewares.
				mergeParams		: true,
				authentication	: true,
				authorization	: true,
				autoAliases		: true,
				callingOptions	: {},
				bodyParsers     : {
					json         : {
						strict   : false,
						limit    : "1MB"
					},
					urlencoded: {
						extended : true,
						limit    : "1MB"
					}
				},
				aliases       	 : {
					"POST /trade-finance/bid-bond-application": {
						type		: "multipart",
						busboyConfig: {
							limits  : {
								files    : 8,
								fileSize : 10 * 1024 * 1024
							},
							onPartsLimt(busboy, alias, svc) {
								this.logger.info("Busboy parts limit!");
							},
							onFilesLimit(busboy, alias, svc) {
								this.logger.info("Busboy file limit!");
							},
							onFieldsLimit(busboy, alias, svc) {
								this.logger.info("Busboy fields limit!");
							}
						},
						action      : "trade-finance.bidBondApplication"
					},
					"POST /trade-finance/guarantee-application": {
						type		: "multipart",
						busboyConfig: {
							limits  : {
								files    : 7,
								fileSize : 10 * 1024 * 1024
							},
							onPartsLimt(busboy, alias, svc) {
								this.logger.info("Busboy parts limit!");
							},
							onFilesLimit(busboy, alias, svc) {
								this.logger.info("Busboy file limit!");
							},
							onFieldsLimit(busboy, alias, svc) {
								this.logger.info("Busboy fields limit!");
							}
						},
						action      : "trade-finance.guaranteeApplication"
					},
					"POST /trade-finance/letter-of-credit-application": {
						type		: "multipart",
						busboyConfig: {
							limits  : {
								files    : 15,
								fileSize : 10 * 1024 * 1024
							},
							onPartsLimt(busboy, alias, svc) {
								this.logger.info("Busboy parts limit!");
							},
							onFilesLimit(busboy, alias, svc) {
								this.logger.info("Busboy file limit!");
							},
							onFieldsLimit(busboy, alias, svc) {
								this.logger.info("Busboy fields limit!");
							}
						},
						action      : "trade-finance.letterofCreditApplication"
					},
					"POST /ikonnect-loan/loan-application": {
						type		: "multipart",
						busboyConfig: {
							limits  : {
								files    : 15,
								fileSize : 10 * 1024 * 1024
							},
							onPartsLimt(busboy, alias, svc) {
								this.logger.info("Busboy parts limit!");
							},
							onFilesLimit(busboy, alias, svc) {
								this.logger.info("Busboy file limit!");
							},
							onFieldsLimit(busboy, alias, svc) {
								this.logger.info("Busboy fields limit!");
							}
						},
						action      : "ikonnect-loan.loanApplication"
					}
				},
				mappingPolicy	: "all", // Available values: "all", "restrict"
				logging			: false,

				//get users IP
				onBeforeCall(ctx, route, req, res) {
					let clientIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
					let wrapperDevice = req.headers['user-device'] ? JSON.parse(req.headers['user-device']) : {}
					ctx.meta.clientIp = req.headers['user-device'] ? wrapperDevice.clientIp : clientIp
					const userAgent = req.headers['user-agent'];
					
					const auth = req.headers [ "authorization" ]
					if ( auth && auth.startsWith ( "Bearer " ) ) {
						ctx.meta.token = auth.slice ( 7 )
					}
					
					let userDevice = detector.detect(userAgent);
					let { os: { name: osName }, 
							client: { name: clientName, type: clientType}, 
							device: { type: deviceType, brand }} = userDevice;
					ctx.meta.userDevice = req.headers['user-device'] ? wrapperDevice : {osName, clientName, clientType, deviceType, brand, clientIp};
				}
			},
			{
				path            : "/ikonnect/soft-token",
				callOptions     : {
					timeout     : 60000,
					retries     : 0
				},
				whitelist		: [ "**" ],
				cors			: { 
					origin: "*",
					methods: ["POST"]
				},			
				use				: [], // Route-level Express middlewares.
				mergeParams		: true,
				authentication	: false,
				authorization	: false,
				autoAliases		: false,
				aliases          : {
					"POST request" 	   : "soft-token.request",
					"POST profile" 	   : "soft-token.profile",
					"POST activate"    : "soft-token.activate",
					"POST login" 	   : "soft-token.login",
					"POST change-pin"  : "soft-token.changePin",
					"POST get-token"   : "soft-token.getToken"
				},
				callingOptions	: {},
				bodyParsers     : {
					json         : {
						strict   : false,
						limit    : "1MB"
					},
					urlencoded: {
						extended : true,
						limit    : "1MB"
					}
				},
				mappingPolicy	: "restrict", // Available values: "all", "restrict"
				logging			: false,

				//get users IP
				onBeforeCall(ctx, route, req, res) {
					let clientIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
					ctx.meta.clientIp = req.headers['user-device'] ? req.headers['user-device'].clientIp : clientIp
					const userAgent = req.headers['user-agent'];
					
					let userDevice = detector.detect(userAgent);
					let { os: { name: osName }, 
							client: { name: clientName, type: clientType}, 
							device: { type: deviceType, brand }} = userDevice;
					ctx.meta.userDevice = req.headers['user-device'] || {osName, clientName, clientType, deviceType, brand, clientIp};
				}
			},
			{
				path             : "/ikonnect/auth",
				callOptions: {
					timeout: 60000,
					retries: 0
				},
				whitelist        : [ "**" ],
				cors			: { 
					origin: "*",
					methods: ["POST"]
				},	
				use              : [],
				mergeParams      : true,
				authentication   : false,
				authorization    : false,
				autoAliases      : false,
				bodyParsers      : {
					json            : {
						strict         : false,
						limit          : "1MB"
					},
					urlencoded      : {
						extended       : true,
						limit          : "1MB"
					}
				},
				mappingPolicy    : "restrict", // Available values: "all", "restrict"
				aliases          : {
					"POST soft-token" : "auth-jwt.token",
					"POST get-token"  : "auth-jwt.ibToken",
					"GET konnect-token"  : "auth-jwt.iKonnectToken"
				},
				logging          : false,
				
				//get users IP
				onBeforeCall(ctx, route, req, res) {
					let clientIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
					ctx.meta.clientIp = req.headers['user-device'] ? req.headers['user-device'].clientIp : clientIp
					const userAgent = req.headers['user-agent'];
					
					let userDevice = detector.detect(userAgent);
					let { os: { name: osName }, 
							client: { name: clientName, type: clientType}, 
							device: { type: deviceType, brand }} = userDevice;
					ctx.meta.userDevice = req.headers['user-device'] || {osName, clientName, clientType, deviceType, brand, clientIp};
				}
			},
			// {
			// 	path             : "/mock",
			// 	callOptions: {
			// 		timeout: 60000,
			// 		retries: 0
			// 	},
			// 	whitelist        : [ "**" ],
			// 	use              : [],
			// 	mergeParams      : true,
			// 	authentication   : false,
			// 	authorization    : false,
			// 	autoAliases      : true,				
			// 	bodyParsers      : {
			// 		json         : {
			// 			strict      : false,
			// 			limit       : "1MB"
			// 		},
			// 		urlencoded   : {
			// 			extended    : true,
			// 			limit       : "1MB"
			// 		}
			// 	},
			// 	mappingPolicy    : "all",
			// 	logging          : false
			// },
			{
				path          	 : "/uploads",
				callOptions: {
					timeout: 60000,
					retries: 0
				},
				whitelist		 : [ "**" ],
				cors			: { 
					origin: "*",
					methods: ["POST"]
				},
				authorization 	 : false,
				bodyParsers   	 : { 
					json       : false, 
					urlencoded : false 
				},
				aliases       	 : {
					"POST /bank-documents": {
						type		: "multipart",
						busboyConfig: {
							limits  : {
								files    : 3,
								fileSize : 3 * 1024 * 1024
							},
							onPartsLimt(busboy, alias, svc) {
								this.logger.info("Busboy parts limit!");
							},
							onFilesLimit(busboy, alias, svc) {
								this.logger.info("Busboy file limit!");
							},
							onFieldsLimit(busboy, alias, svc) {
								this.logger.info("Busboy fields limit!");
							}
						},
						action      : "core-uploads.bankDocuments"
					},
					"POST /bulk-stream": {
						type		: "multipart",
						authorization: true,
						authentication: true,
						busboyConfig: {
							limits: {
								files    : 1,
								fileSize : 15 * 1024 * 1024
							},
							onPartsLimt(busboy, alias, svc) {
								this.logger.info("Busboy parts limit!");
							},
							onFilesLimit(busboy, alias, svc) {
								this.logger.info("Busboy file limit!");
							},
							onFieldsLimit(busboy, alias, svc) {
								this.logger.info("Busboy fields limit!");
							}
						},
						action      : "core-uploads.bulkStream"
					},
					"POST /supporting-documents": {
						type		: "multipart",
						authorization: true,
						authentication: true,
						busboyConfig: {
							limits  : {
								files    : 5,
								fileSize : 10 * 1024 * 1024
							},
							onPartsLimt(busboy, alias, svc) {
								this.logger.info("Busboy parts limit!");
							},
							onFilesLimit(busboy, alias, svc) {
								this.logger.info("Busboy file limit!");
							},
							onFieldsLimit(busboy, alias, svc) {
								this.logger.info("Busboy fields limit!");
							}
						},
						action      : "core-uploads.sendSupportDocuments"
					}
				},				
				mappingPolicy	 : "restrict",
				
				//get users IP
				onBeforeCall(ctx, route, req, res) {
					let clientIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;
					ctx.meta.clientIp = req.headers['user-device'] ? req.headers['user-device'].clientIp : clientIp
					const userAgent = req.headers['user-agent'];
					
					let userDevice = detector.detect(userAgent);
					let { os: { name: osName }, 
							client: { name: clientName, type: clientType}, 
							device: { type: deviceType, brand }} = userDevice;
					ctx.meta.userDevice = req.headers['user-device'] || {osName, clientName, clientType, deviceType, brand, clientIp};
				}
			}
		],
		//log4XXResponses	 : true,
		//logRequestParams : null,
		//logResponseData	 : null,
		assets			 : {
			folder      : "public",
			options     : {}
		}
	},
	methods             : {
		async authenticate ( ctx, route, req) {

			let token

			//console.log('COKKIES___',req.headers)

			// Get JWT token from cookie
			if ( req.headers.cookies ) {
				const cookies = cookie.parse ( req.headers.cookies )
				token         = cookies [ "jwt_token" ]
			}

			// Get JWT token from Authorization header
			if ( !token ) {
				const auth = req.headers [ "authorization" ]
				if ( auth && auth.startsWith ( "Bearer " ) ) {
					token = auth.slice ( 7 )
				}
			}

			//Token Found
			if ( token ){

				let verified = await ctx.call ( 'auth-jwt.verify',{ token } )

				if ( verified ) {

					// Verify JWT token
					// const user = await ctx.call("v1.accounts.resolveToken", { token })
					const user = verified.data

					if ( user ) { 
						this.logger.info ( "User authenticated via JWT.", { username: user.username } )
						ctx.meta.token = token
						// Reduce user fields (it will be transferred to other nodes)
						return user
					}
					else {
						throw new ApiGateway.Errors.UnAuthorizedError ( ApiGateway.Errors.ERR_INVALID_TOKEN )
					}
				}
				else {
					throw new ApiGateway.Errors.UnAuthorizedError ( ApiGateway.Errors.ERR_INVALID_TOKEN )
				}
			}
			else {
				throw new ApiGateway.Errors.UnAuthorizedError ( ApiGateway.Errors.ERR_NO_TOKEN )
				return null
			}

		},
		async authorize(ctx, route, req) {
			// Get the authenticated user.
			const user = ctx.meta.user;

			// It check the `auth` property in action schema.
			if (req.$action.auth == "required" && !user) {
				throw new ApiGateway.Errors.UnAuthorizedError("NO_RIGHTS");
			}
		}
	}
}