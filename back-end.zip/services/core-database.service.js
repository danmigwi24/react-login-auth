"use strict"

// Environment Config
const path          = require ( 'path' )
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw env.error }
const appName       = process.env.appName

// Global Variables
const connection 	= require ( path.resolve ( `./config/${appName}/db/connection` ))
const statements 	= require ( path.resolve ( `./config/${appName}/db/statements` ))
const migrationCfg  = require ( path.resolve ( `./config/${appName}/db/migrations` ))
const Database   	= require ( path.resolve ( './lib/db.js' ) )
const moment     	= require ( 'moment' )

module.exports = {
	name    : "core-database",
	settings: {
		log      : false,
		analytics: true
	},
	actions : {
		query: {
			rest	: "/query",
			params	: {
				[`request-name`]:'string',
				payload         : 'object',
				setDbConn       : 'object|optional'
			},
			async handler ( ctx ) {

				let { setDbConn } 	= ctx.params
				let queryStart 		= moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')

				//connection here				
				let connectionVendor = connection.vendor
				let alternateVendor  = false
				
				//check if an alternate vendor exists
				if  ( setDbConn && setDbConn.vendor ) {
					try {
						alternateVendor = connection [ setDbConn.vendor ]
					}
					catch  ( e ){
						console.log ( `vendor ${setDbConn.vendor} not found` )
					}
				}

				let conn = alternateVendor ? alternateVendor : connection [ connectionVendor ]

				//run the database query
				let db                       = new Database( conn  )
				let compiled                 = db.compile ( ctx.params.payload, ctx.params['request-name'], statements  )		
				let { resultStatus, result } = await db.query ( compiled )
	
				let queryEnd = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')

				//calculate request latency
				let sent            = moment ( queryStart,'YYYY-MM-DD HH:mm:ss:SSSS'  ),
					received        = moment ( queryEnd,'YYYY-MM-DD HH:mm:ss:SSSS' ),
					latency         = `${received.diff(sent, 'milliseconds')} ms`
	
				this.settings.log && ctx.emit ( "create.log", {
					service       : ctx.service.fullName,
					log           : { 
						"request-name": ctx.params['request-name'], 
						"start"       : queryStart,
						"end"         : queryEnd,
						"latency"     : latency,
						"payload"     : ctx.params.payload, 
						"query"       : compiled
										.replace(/\n/g,'')
										.replace(/\t/g,' ')
										.replace(/\s\s\s\s/g, ' ')
										.replace(/\s\s\s/g, ' ')
										.replace(/\s\s/g, ' '),
						"success"     : resultStatus, 
						"response"    : resultStatus ? result [0] : result
					}
				})
				
				return { resultStatus, result }
			}
		},
		bulkQuery:{			
			rest: "/bulk-query",
			params:{
				requests: { 
					type: "array",
					items: {
						type: "object",
						props:{
							[`request-name`]:'string',
							payload         : 'object',
						}
						
					}
				},				
				setDbConn          : 'object|optional'
			},
			async handler ( ctx ) {

				let { setDbConn, requests } = ctx.params
				let queryStart 				= moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')

				//connection here				
				let connectionVendor = connection.vendor
				let alternateVendor  = false
				
				//check if an alternate vendor exists
				if  ( setDbConn && setDbConn.vendor ) {
					try {
						alternateVendor = connection [ setDbConn.vendor ]
					}
					catch  ( e ){
						console.log ( `vendor ${setDbConn.vendor} not found` )
					}
				}

				let conn = alternateVendor ? alternateVendor : connection [ connectionVendor ]
				
				//run the database query
				let db                       = new Database( conn  )

				//compile multiple
				let compiled = []

				for ( let request of requests ) {
					let reqCompiled = db.compile ( request.payload, request['request-name'], statements )
					console.log ( reqCompiled ) 
					compiled.push ( reqCompiled )
				}

				
				
				// Batch execution
				let { resultStatus, result } = await db.batchQuery ( compiled )

				let queryEnd = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')

				//calculate request latency
				let sent            = moment ( queryStart,'YYYY-MM-DD HH:mm:ss:SSSS'  ),
					received        = moment ( queryEnd,'YYYY-MM-DD HH:mm:ss:SSSS' ),
					latency         = `${received.diff(sent, 'milliseconds')} ms`
	
				this.settings.log && ctx.emit ( "create.log", {
					service       : ctx.service.fullName,
					log           : { 
						"request-name": requests, 
						"start"       : queryStart,
						"end"         : queryEnd,
						"latency"     : latency,
						"query"       : compiled.map ( entry => {
							return entry						
							.replace(/\n/g,'')
							.replace(/\t/g,' ')
							.replace(/\s\s\s\s/g, ' ')
							.replace(/\s\s\s/g, ' ')
							.replace(/\s\s/g, ' ')
						}),
						"success"     : resultStatus
					}
				})
				
				return { resultStatus, result }

			}
		},
		requestData: {
			rest: "/request-data",
			params: {
				payload: "string",
				$$strict: true
			},
			async handler (ctx) {
				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let result = await ctx.call('core-database.query', decrypted)

				return await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(result) });
			}
		}
	},
	methods : {
		async migrate ( ) {

			//connection here				
			let connectionVendor = connection.vendor
			let alternateVendor  = false
			
			//check if an alternate vendor exists
			if  ( setDbConn && setDbConn.vendor ) {
				try {
					alternateVendor = connection [ setDbConn.vendor ]
				}
				catch  ( e ){
					console.log ( `vendor ${setDbConn.vendor} not found` )
				}
			}

			let conn = alternateVendor ? alternateVendor : connection [ connectionVendor ]

			//run the database query
			let db                       = new Database( conn  )

			await db.migrate ( migrationCfg )
			
		}
	},
	
	async created() {},
	async started() {},
	async stopped() {}
}