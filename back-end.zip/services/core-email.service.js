"use strict"

// Environment Config
const path          = require ( 'path' )
const env           = require ( 'dotenv' ).config()				
if ( env.error ) { throw result.error }
let mailTransporter = process.env.mailTransporter
const appName       = process.env.appName

// Global Variables
const transporters 	= require ( path.resolve ( `./config/${appName}/email/transporters.js` ) )
const nodeMailer    = require('nodemailer')


module.exports = {
	name    : "core-email",
	settings: {
		log: true
	},
	actions : {
		send: {
			rest: "/send",
			params : {
				recipients: "string",
				subject   : "string",
				message   : "string",
				template  : {
					type     : "object", 
					optional : true,
					props    : {
						name    : "string",
						data    : "object|optional"
					}
				}
			},
			async handler ( ctx ) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					emailParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				console.log({mailTransporter,conf:transporters [ mailTransporter ]})
		
				//set up transporters			
				const transporter  = nodeMailer.createTransport( transporters [ mailTransporter ] )		

				//use template
				let template    = ctx.params.template || false
				let mailOptions = {}

				// html email
				if ( template ) {
					
					//Get HTML
					let html = require ( 'fs' ).readFileSync (
						require ( 'path' ).resolve ( `./config/${appName}/email/templates/${template.name}.html` ),
						`utf8`
					)

					//replace html placeholders
					let keys = Object.keys ( template.data ) 

					for ( let key of keys ) {
						let placeholder = `__${key}__`
						let value       = template.data [ key ]
						let regex       = new RegExp ( placeholder, 'g' )

						html = html.replace ( regex, value )
					}

					mailOptions  = {
						from: 'ikonnect <ikonnect@creditbank.co.ke>', // sender address
						to     : ctx.params.recipients,
						subject: ctx.params.subject,
						html   : html,
						attachments:template.attachments					
					}					
				}

				// default email
				else {
					mailOptions  = {
						from: 'ikonnect <ikonnect@creditbank.co.ke>', // sender address
						to     : ctx.params.recipients,
						subject: ctx.params.subject,
						html   : ctx.params.message,
						attachments:ctx.params.attachments
					}				
				}
				logData.emailParams = mailOptions
				//logData.emailParams.html = ''
			
				//send the email
				let message = 'No Info', sent = false
			
				try{
					message = await transporter.sendMail(mailOptions )
					sent = true
				}
				catch ( e ) {
					message = `[ ERROR SENDING MAIL ] REASON: ` + e.message
				}

				logData.type = sent ? 'info': 'debug'
				logData.responseData = message
				logData.emailParams.html = ''
				ctx.emit ( 'create.log', logData);

				return {  message, sent }
			}			
		}		
	},
	events  : {},
	methods : {},
	
	async created() {},
	async started() {},
	async stopped() {}
}