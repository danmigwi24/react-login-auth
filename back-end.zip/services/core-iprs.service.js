"use strict"

// Environment Config
const axios = require ( 'axios' )

const path          = require ( 'path' )
const env           = require ( 'dotenv' ).config()				
if ( env.error ) { throw result.error }
let iprsEndpoint = process.env.IPRS


module.exports = {
	name    : "core-iprs",
	settings: {
		log: true
	},
	actions : {
		send: {
			rest: "/check",
			params : {
				id: "string"
			},
			async handler ( ctx ) {

				//console.log( ctx.params )
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};
				

				let response = {
					success: false
				}
				try {
					let httpsAgent = false

					if ( iprsEndpoint.startsWith ('https') ){
						const https = require ('https')
						httpsAgent  = new https.Agent({ rejectUnauthorized: false })
					}
						
					let instance = httpsAgent ? axios.create ({ httpsAgent }) : axios.create()

					let res = await instance.post (
						iprsEndpoint, 
						{ IDNumber : ctx.params.id },
						{
							headers :{
								'Content-Type': 'application/json'
							}
						}
					)
					//console.log({ res })

					if ( res ) {
						response.success = true
						response.data    = res.data

						logData.responseData = 'successful';
						this.settings.log        && ctx.emit ( 'create.log', logData);
					}

				} 
				catch ( e ) {
					response.error = e.message
					
					logData.type = 'debug'
					logData.responseData = e.res.data;
					this.settings.log        && ctx.emit ( 'create.log', logData);
				} 

				return response
			}			
		}		
	},
	events  : {},
	methods : {},
	
	async created() {},
	async started() {},
	async stopped() {}
}