"use strict"
const moment = require('moment');
const winston = require('winston');
require('winston-daily-rotate-file');

module.exports = {
	name        : "core-logging",
	settings    : {},
	dependencies: [],
	actions     : {
		customerAuditTrail: {
			rest: "customer-audit-trail",
			params: {
				payload 	: "string",
				$$strict 	: true
			},

			async handler (ctx){

				let { userDevice } = ctx.meta;
				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let moduleIds = {
					'transaction charges': "3001",
					'stage transaction': "3002",
					'submit transaction': "3003",
					'login': "3004",
					'otp': "3005",
					'password reset': "3006",
					'registration': "3007",
					'acccount linking': "3008",
					'bulk upload': "3009",
					'password change': "3010",
					'calculator': "3011",
					'change account limits': "3012",
					'account mandates authorization': "3013",
					'account beneficiaries': "3014",
					'account mandatees': "3015",
					'customer reports': "3016",
					"view page": "3017",
					"canceled transaction": "3018"
				}
				
				let moduleId = moduleIds[decrypted.module.toLowerCase()] || "3333"

				ctx.call('core-database.query', {
					'request-name': "customer-audit-trail",
					payload: {
						username 	: decrypted.username,
						module 		: decrypted.module,
						moduleId    ,
						page 		: decrypted.page,
						account	 	: decrypted.account,
						activity	: decrypted.activity,
						customerId	: decrypted.customerId,
						date 		: moment().format('YYYY-MM-DD'),
						time		: moment().format('HH:mm:ss'),
						dateTime	: moment().format('YYYY-MM-DD HH:mm:ss'),
						ip			: ctx.meta.clientIp,
						device		: `${userDevice.osName} ${userDevice.deviceType} ${userDevice.brand} ${userDevice.clientType} ${userDevice.clientName}`
					}
				})

				return ''
			}
		}
	},
	events      : {
		"create.log"(payload){
			//log...
			//console.log ( `Logging service`)
			//console.log ( JSON.stringify ( payload, null, 4 ) )
			payload.timestamp = moment().format('DD-MM-YYYY HH:mm:ss')
			let filenameExt = `${payload.service}-${payload.type}`
			

			const transport = new (winston.transports.DailyRotateFile)({
				filename: filenameExt,
				datePattern: 'YYYY-MM-DD',
				extension: '.log',
				zippedArchive: false,
				maxSize: '5m',
				dirname: `/var/log/IB/${moment().format('YYYY-MM-DD')}`,
				//maxFiles: '365d'
			  });
			 
			  const logger = winston.createLogger({
				transports: [
				  transport
				]
			  });
			 
			  logger.info(payload);

		}
	},
	methods     : {},
	created		 () {},
	async started() {},
	async stopped() {}
}