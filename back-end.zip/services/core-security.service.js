"use strict"


// Environment Config
const path          = require ( 'path' )
const CryptoJS   	= require('crypto-js')
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw env.error }
const aes_key    = process.env.AES_KEY
const aes_iv     = process.env.AES_IV
const secretKey  = process.env.sharedKey

module.exports = {
	name		  : "core-security",
	actions		  : {
		fastEncrypt: {
			rest        : "/fast-encrypt",
			params      : {
				payload: "string"
			},
			async handler(ctx) {

				let { payload }       = ctx.params
				let ACTIVATION_SECRET = process.env.ACTIVATION_SECRET
				let encryptor         = require('simple-encryptor')(ACTIVATION_SECRET)
				let encrypted         = encryptor.encrypt ( payload )
				
				return { 
					payload: ctx.params.payload, 
					encrypted,
					encoded: new Buffer.from(encrypted).toString ('base64') 
				}
			}
		},
		fastDecrypt: {
			rest        : "/fast-decrypt",
			params      : {
				payload: "string"
			},
			async handler(ctx) {

				let { payload }       = ctx.params;
				let decrytedBase 	  = Buffer.from(payload, 'base64').toString('utf-8');
				let ACTIVATION_SECRET = process.env.ACTIVATION_SECRET
				let encryptor         = require('simple-encryptor')(ACTIVATION_SECRET)
				let decrypted         = encryptor.decrypt ( decrytedBase )

				return { 
					payload: ctx.params.payload, 
					decrypted
				}
			}
		},
		ibEncrypt: {
			params: {
				payload: "string"
			},
			async handler(ctx) {
				//Encryption/Decryption AES/CBC/PKCS5padding

				let { payload }       = ctx.params;

				let encrypted =   CryptoJS.AES.encrypt(
					payload, 
					CryptoJS.enc.Hex.parse(aes_key), 
					{ 
						iv: CryptoJS.enc.Hex.parse(aes_iv), 
						mode: CryptoJS.mode.CBC, 
						formatter: CryptoJS.enc.Utf8, 
						padding: CryptoJS.pad.Pkcs7 
					}
				).toString()

				return encrypted;
			}
		},
		ibDecrypt: {
			params: {
				payload: "string"
			},
			async handler (ctx) {
				let { payload }       = ctx.params;

				let decrypted  = CryptoJS.AES.decrypt(
					payload.toString(), 
					CryptoJS.enc.Hex.parse(aes_key), 
						{ 
							iv: CryptoJS.enc.Hex.parse(aes_iv), 
							mode: CryptoJS.mode.CBC, 
							formatter: CryptoJS.enc.Utf8, 
							padding: CryptoJS.pad.Pkcs7 
						}
				);
			
				return decrypted.toString(CryptoJS.enc.Utf8);
			}
		},
		encryptMessage: {
			params: {
				payload: "string"
			},
			async handler(ctx) {
				//Encryption/Decryption AES/ECB

				let { payload }       = ctx.params;

				let encrypted =   CryptoJS.AES.encrypt(
					payload, 
					CryptoJS.enc.Utf8.parse(secretKey), 
					{ 
						mode: CryptoJS.mode.ECB, 
						formatter: CryptoJS.enc.Base64
					}
				).toString()

				return encrypted;
			}
		}
	}
}