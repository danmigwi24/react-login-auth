"use strict"

module.exports = {
	name		  : "core-sms",
	settings: {
		log: true
	},
	dependencies  : [],
	actions		  : {
		cbkonnectSend: {
			rest        : "/cbkonnect-send",
			params      : {
				phonenumber: "string",
				username   : "string",
				message    : "string"
			},
			async handler(ctx) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};
				logData.responseData = 'success';
				this.settings.log        && ctx.emit ( 'create.log', logData);

				return await ctx.call ( 'core-database.query', {
					'request-name': 'cbkonnect.sms',
					'payload'     : { ...ctx.params }
				})
			}
		}
	},
	events		  : {},
	methods		  : {},
	created      () {},
	async started() {},
	async stopped() {}
}