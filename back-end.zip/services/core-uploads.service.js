"use strict"

const path              = require ( 'path'     )
const fs                = require ( 'fs'       )
const fse               = require ( 'fs-extra' )
const Excel             = require ( 'exceljs'  )
const { getXlsxStream } = require ( 'xlstream' )

module.exports = {
	name    : "core-uploads",
	actions : {
		bulkStream : {
			rest   :'/bulk-stream',
			async handler( ctx ){

				let self = this

				console.log ({ meta: ctx.meta })
				console.time ('processing')
				
				const { filename } = ctx.meta	

				return new Promise ( ( resolve, reject ) => {

					try {

						// upload file - make sure the filepath exists
						const fileDir  = path.resolve ( `./public/uploads/`)
						const filePath = path.resolve ( fileDir,filename)
						fse.ensureDirSync ( fileDir )

						
						const fileStream = fs.createWriteStream ( filePath )
						
						fileStream.on ( "close", async () => { 
							self.excelToJSON( filePath, resolve, reject ) 
						})

						ctx.params.on ( "error", err => {
							reject({
								userId,
								uploaded: false,
								filename:path.basename ( filePath ),
								location:`File error received -  ERROR: ${err.message}`
							})
							fileStream.destroy ( err )		
							
						})

						fileStream.on( "error", ( err ) => {
							console.log(`File error received -  ERROR: ${err.message}` )
							// Remove the errored file.
							fs.unlinkSync ( filePath )
						})

						ctx.params.pipe ( fileStream )
						
					}
					catch ( e) {
						reject ( `unable to process file` )
					}

				})				
			}
		},
		bankDocuments: {

			handler ( ctx ){

				const { $multipart, fieldname, filename, mimetype } = ctx.meta	
				const { userId } = $multipart
				const allowedTypes = [
					'image/jpeg',
					'image/png',
					'image/webp',
					'application/pdf'
				]
				
				return new Promise ( ( resolve, reject ) => {	

					// THROW ERROR if no userId is present
					if ( !userId ) {
						reject('userId Not Provided')
					}

					// Throw error if a disallowed mimeType is present
					if ( !allowedTypes.includes ( mimetype )){
						reject (`${mimetype} is Not allowed for ${fieldname} - ${filename}`)
					}								
					
					// make sure the filepath exists
					const fileDir  = path.resolve ( `./public/docs/${userId}/`)
					const filePath = path.resolve ( fileDir, fieldname + path.extname(filename))
					fse.ensureDirSync( fileDir )

					// write to the filepath
					const f = fs.createWriteStream ( filePath )
					
					f.on ( "close", async () => {

						//write the data to the database
						let payload = {
							username: userId,
							doctype : fieldname,
							docpath : `http://localhost:2020/docs/${userId}/${fieldname + path.extname(filename)}`
						}

						ctx.call ( 'core-database.query', {
							'request-name' : 'registration.documents.add',
							payload 
						})
						

						resolve({
							userId,
							uploaded: true,
							filename:path.basename ( filePath ),
							url:`http://localhost:2020/docs/${userId}/${fieldname + path.extname(filename)}`,
						})
					})

					ctx.params.on ( "error", err => {
						reject({
							userId,
							uploaded: false,
							filename:path.basename ( filePath ),
							location:`File error received -  ERROR: ${err.message}`
						})
						f.destroy ( err )		
						
					})

					f.on( "error", ( err ) => {
						console.log(`File error received -  ERROR: ${err.message}` )
						// Remove the errored file.
						fs.unlinkSync ( filePath )
					});

					ctx.params.pipe ( f )
								
				})	
			}
		},
		sendSupportDocuments: {
			handler ( ctx ){

				const { $multipart, fieldname, filename, mimetype } = ctx.meta
				const { userId, txnType, accountName } = $multipart
				const allowedTypes = [
					'application/pdf',
					'application/msword',
					'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
					'application/vnd.ms-excel',
					'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
				]
				
				return new Promise ( ( resolve, reject ) => {	
					// Throw error if a disallowed mimeType is present
					if ( !allowedTypes.includes ( mimetype )){
						reject (`${mimetype} is Not allowed for ${fieldname} - ${filename}`)
					}						
					
					// make sure the filepath exists
					const fileDir  = path.resolve ( `./public/docs/supporting-docs/`)
					const filePath = path.resolve ( fileDir, filename)
					fse.ensureDirSync( fileDir )

					// write to the filepath
					const f = fs.createWriteStream ( filePath )
					let attachments = []

					ctx.params.on ( "error", err => {
						reject({
							userId,
							uploaded: false,
							filename:path.basename ( filePath ),
							location:`File error received -  ERROR: ${err.message}`
						})
						f.destroy ( err )		
						
					})

					f.on( "error", ( err ) => {
						console.log(`File error received -  ERROR: ${err.message}` )
						// Remove the errored file.
						fs.unlinkSync ( filePath )
					});
					f.on("finish", async () => {
						attachments.push({
							"filename"   : filename,
							"path"       : path.resolve(`./public/docs/supporting-docs/${filename}`),
							"contentType": mimetype
						})

						resolve({
							userId,
							uploaded: true,
						})
					})
					
					f.on ( "close", async () => {
						ctx.call('core-email.send', {
							recipients      : "customerservice@creditbank.co.ke,treasury@creditbankltd.co.ke",
							subject         : `${txnType} - ${userId} - ${accountName}`,
							message         : '',
							attachments     ,
						})
						
						
					})

					ctx.params.pipe ( f )
								
				})		
			}
		}
	},
	events  : {},
	methods : {
		async excelToJSON( file, resolve, reject ){

			let self = this

			try{

				/**
				 * PARSE FILE
				 */
				
				let data = {
					'internal-transfers'     : [],
					'pesalink'               : [],
					'eft'                    : [],
					'mobile-transfers'       : [],
					'wallet-transfers'       : [],
					'prepaid-card-funding'   : [],					
					'rtgs-kes'               : [],
					'rtgs-fcy'               : [],
					'international-transfers': []
				}
				let processedCount = 0
				let rowCount       = 0
				
				//callbacks
				let onEnd  = () => {

					processedCount += 1

					if ( processedCount === Object.keys ( data ).length ) {
						data.rows = rowCount
						console.log (`finished parsing` )
						console.timeEnd ('processing')
						let processed = self.processExcel (data)
						resolve( { success:true, data: processed })
					}  
				}
				let onData = ( x, key ) => {

					
					rowCount ++
					let filtered = x.raw.arr.filter ( e => e && e )
					if ( filtered.length > 0 ) {
						
						data[key].push ( x.raw.obj )
					}
				}
				
				// streams
				const internal      = await getXlsxStream({ filePath: file, sheet: 0 })
				const pesalink      = await getXlsxStream({ filePath: file, sheet: 1 })
				const eft           = await getXlsxStream({ filePath: file, sheet: 2 })
				const mobile        = await getXlsxStream({ filePath: file, sheet: 3 })	
				const wallet        = await getXlsxStream({ filePath: file, sheet: 4 })	
				const prepaid_card_funding = await getXlsxStream({ filePath: file, sheet: 5 })				
				const rtgs_kes      = await getXlsxStream({ filePath: file, sheet: 6 })
				const rtgs_fcy      = await getXlsxStream({ filePath: file, sheet: 7 })
				const international = await getXlsxStream({ filePath: file, sheet: 8 })

				// data events
				internal	  .on ( 'data', x =>  onData ( x, 'internal-transfers'      ) )
				pesalink	  .on ( 'data', x =>  onData ( x, 'pesalink'                ) )
				eft			  .on ( 'data', x =>  onData ( x, 'eft'                     ) )
				mobile		  .on ( 'data', x =>  onData ( x, 'mobile-transfers'        ) )
				wallet		  .on ( 'data', x =>  onData ( x, 'wallet-transfers'        ) )
				prepaid_card_funding.on ( 'data', x =>  onData ( x, 'prepaid-card-funding'))
				rtgs_kes	  .on ( 'data', x =>  onData ( x, 'rtgs-kes'                ) )
				rtgs_fcy	  .on ( 'data', x =>  onData ( x, 'rtgs-fcy'                ) )
				international .on ( 'data', x =>  onData ( x, 'international-transfers' ) )

				// end events
				internal     .on( 'end', onEnd )					
				pesalink     .on( 'end', onEnd )
				eft          .on( 'end', onEnd )
				mobile       .on( 'end', onEnd )
				wallet       .on( 'end', onEnd )
				prepaid_card_funding.on( 'end', onEnd )
				international.on( 'end', onEnd )
				rtgs_kes     .on( 'end', onEnd )
				rtgs_fcy     .on( 'end', onEnd )
			}
			catch ( e ) {
				console.log ( e )
				reject ( e.message )
			}
		},
		processExcel ( workbook ) {

			//console.log ( JSON.stringify ( workbook, null, 4 ))

			try {
				let sheetNames = Object.keys ( workbook )    
				let processed  = {}
				
				for ( let sheetName of sheetNames ) {
			
			
					let sheet = workbook [ sheetName ]
			
					if ( sheet instanceof Array) {
						
						// remove the meta data
						let metaData    = sheet.slice ( 0, 5 ) 
						sheet.splice ( 0, 5) // remove the meta data from the sheet 
						
						// get the columns
						let columns = sheet.slice(0,1)[0]
						sheet.splice(0,1) // remove the column data from the sheet
			
						let parsed = {
							errorCount: 0,
							columns:  Object.values(columns),
							errors    : [],
							data      : [],
							orderingData : {
			
							}
						}
				
						sheet = sheet.map ( ( row, index ) => {
			
							let mapped     = {}
							let columnKeys = Object.keys ( columns )
			
							for ( let key of columnKeys ) {
			
								let columnName = columns [key ]
			
								if (! row [ key ] ) {
									parsed.errors.push ({
										key  : columnName,
										error: 'isBlank',
										row  : index + 1
									})
			
									parsed.errorCount = parsed.errorCount + 1						
			
								}
			
								mapped[columnName] = row [ key ] ? row [ key ] : ''
							}
			
							return mapped
			
						})
							
						parsed.data = sheet.map( row => Object.values(row))
			
						// work with the ordering data
						// console.log({ metaData })
						parsed.orderingData = {
							columns:[
								"accountName",
								"accountNumber",
								"txCount",
								"total"                    
							],
							values:[
								metaData[1].B ? metaData[1].B : false,
								metaData[2].B ? metaData[2].B : false,
								metaData[3].B ? metaData[3].B : false,
								metaData[4].B ? metaData[4].B : false
							]
						} 
						
						processed [ sheetName ] = parsed
					}			
				}
			
				processed['internal-transfers'].columns 		= [
					"beneficiary",
					"account",
					"currency",
					"amount",
					"narration"
				]
				processed['pesalink'].columns 					= [
					"beneficiary",
					"account",
					"amount",
					"narration",
					"bank",
					"bankCode",
					"pesalinkCode"
				]
				processed['eft'].columns 						= [
					"beneficiary",
					"account",
					"amount",
					"narration",
					"bank",
					"bankCode",
					"branch",
					"sortCode"
				]
				processed['eft'].data 		= processed['eft'].data.map ( row => {
					row.splice ( 2, 1 )
					return row
				})
				processed['eft'].data 		= processed['eft'].data.map ( row => {
					row = row.map(e => {
						if(e) e.trim()
						return e
					}); 
					return row
				})
				processed['mobile-transfers'].columns 			= [
					"provider",
					"beneficiary",
					"mobile",
					"amount",
					"narration"
				]
				processed['wallet-transfers'].columns 			= [
					"beneficiary",
					"account",
					"amount",
					"narration"
				]
				processed['prepaid-card-funding'].columns 		= [
					"beneficiary",
					"account",
					"currency",
					"amount",
					"narration"
				]
				processed['international-transfers'].columns 	= [
					"beneficiary",
					"account",
					"currency",
					"amount",
					"narration",
					"bank",
					"swiftCode"
				]
				processed['international-transfers'].data 		= processed['international-transfers'].data.map ( row => {
					row = row.slice ( 0, 7 )
					return row
				})
				processed['rtgs-kes'].columns 					= [
					"beneficiary",
					"account",
					"amount",
					"narration",
					"bank",
					"bankCode",
					"swiftCode"
				]
				processed['rtgs-fcy'].columns 					= [
					"beneficiary",
					"account",
					"currency",
					"amount",
					"narration",
					"bank",
					"bankCode",
					"swiftCode"
				]
			
				return processed
			} catch (error) {
				console.log(error)
			}
		}
	},
	created       () {},
	async started () {},
	async stopped () {}
}