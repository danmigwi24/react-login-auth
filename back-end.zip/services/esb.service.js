"use strict"

module.exports = {
	name    : "esb",
	settings: {},
	actions : {
		coreAccountLookup: {
			rest  : "/core-account-lookup",
			params: {
				accountNumber: "string", 
				phoneNumber  : "string"
			},
			async handler(ctx) {


				return {
					"field39"         : "00",
					"gender"          : "MALE",
					"accountName"     : "TIMOTHY WACHIURI WANJOHI",
					"industry"        : "1000",
					"idNumber"        : "23197511",
					"branch"          : "KE0010016",
					"kraPIN"          : "",
					"currency"        : "KES",
					"sector"          : "1000",
					"email"           : "TIMOTHY.WACHIURI@GMAIL.COM",
					"accountCondition": "OK",
					"customerNumber"  : "1000089490",
					"customerName"    : "TIMOTHY WANJOHI WACHIURI",
					"phoneNumber"     : "254720291881|",
					"dob"             : ""					
				}
			}
		},
		balance: {
			rest  : "/balance",
			params: {
				field2: "string", 
				field102  : "string"
			},
			async handler(ctx) {
				console.log ( ctx.params )
				return {
					"field39": "00",
					"actual" : this.getRandomInt(1000, 1000000)		
				}
			}
		},
		mini: {
			rest  : "/mini",
			params: {
				field2: "string", 
				field102  : "string"
			},
			async handler(ctx) {
				console.log ( ctx.params )
				return {
					"field39": "00",
					"mini" : []		
				}
			}
		},
		charges : {
			rest : '/charges',
			async handler() {
				return {
					field39     : '00',
					field48 : 'Account is not registered',
					chargeAmount: '0.00',
					exciseDutyAmount:'0.00'
				}
			}
		}
	},
	events  : {},
	methods : {
		getRandomInt(min, max) {
			min = Math.ceil(min);
			max = Math.floor(max);
			return Math.floor(Math.random() * (max - min + 1)) + min;
		}
	},

	created      () {},
	async started() {},
	async stopped() {}
}