"use strict"

module.exports = {
	name    : "fixed-deposit",
	settings: {},
	actions : {
		new: {
			rest  : "/new",
			params: {
				amount  : "number",
				interest:"number"
			},
			async handler(ctx) {
				return `hello from the fixed deposits service`
			}
		},
		leads: {
			rest: "email-lead",
			params: {
				payload: "string",
				$$strict: true
			},

			async handler(ctx){
				let { payload } = ctx.params

				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: decrypted,
					emailParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { subject, callMeBack, name, email, phone, message } = decrypted

				ctx.call (  'core-email.send', {
					recipients       : 'customerservice@creditbank.co.ke',
					subject         : callMeBack,
					message         : '',
					template        : {
						name        : `call-to-action`,
						data        : { callMeBack, name, email, phone, message, subject }
					}
				})

				ctx.emit ( 'create.log', logData);

				return {
					success: true
				}

			}
		}
	}
}