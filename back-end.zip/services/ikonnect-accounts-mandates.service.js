"use strict"

const moment = require ( 'moment' )
const path   = require ( 'path' )

// Environment Config
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw result.error }
const appName       = process.env.appName
const apiTypes      = require ( path.resolve ( `./config/${appName}/api/api-types` ))

module.exports = {
	name    : "accounts-mandates",
	settings: {
		log: true
	},
	actions : {	
		lockSavingsProfile : {
			rest : 'lock-savings-profile',
			params : {
				phone : "string"
			},
			async handler ( ctx ) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: '',
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { resultStatus : success, result: data } =  await ctx.call ( 'core-database.query', {
					'request-name': 'fetch.locksavings.profile',
					'payload'     : { ...ctx.params },
					'setDbConn'   : { vendor: "cbkonnect-mssql"}
				})

				if ( success && data[0] && data[0][0] && data[0][0].Resp_Code === '00' ) {
					data = data [0][0]

					logData.resposeCode = 200
					logData.responseData = data
					this.settings.log        && ctx.emit ( 'create.log', logData)

					return {
						success: true,
						data
					}
				}
				else if ( success && data[0] && data[0][0] && data[0][0].Resp_Code === '02' ) {
					logData.type = 'debug'
					logData.resposeCode = 201
					logData.responseData = data[0][0].Narration
					this.settings.log        && ctx.emit ( 'create.log', logData)

					return {
						success: false,
						message: data[0][0].Narration
					}
				}
				else {
					logData.type = 'debug'
					logData.resposeCode = 201
					logData.responseData = `Unable to fetch lock savings data for ${ctx.params.phone}`
					this.settings.log        && ctx.emit ( 'create.log', logData)

					return {
						success: false,
						message: `Unable to fetch lock savings data for ${ctx.params.phone}`
					}
				}

			}
		},
		fetchProfile              : {
			rest  : "/fetch-profile",
			params: {
				payload : "string",
				$$strict: true
			},
			async handler ( ctx ) {
				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let { userId, requestId } = decrypted

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					dbParams: decrypted,
					resposeCode: '',
					responseData: '',
					userDevice: ctx.meta.userDevice
				};


				/**
				 *  ------------------------
				 * 
				 * 		PROCEDURE
				 * 
				 *  ------------------------
				 * 
				 * 	1. Get user Profile
				 *  2. Loop through each account and get the account mandate details ( authorization rules )
				 *  3. check the corporate staging table to get any transactions by each account
				 *  4. determine the stage of each transaction and compare to the users role 
				 *  5. display pending transactions if any
				 */

				// 1. Get user Profile
				let getProfile = await ctx.call ( 'users-profile.fetch', { username: userId })
				let hasProfile = false
				let profile    = {}

				if ( getProfile.success ) {
					hasProfile = true
					profile    = getProfile.data
				}

				// 2. Loop through each account and get the account mandate details ( authorization rules )
				if ( hasProfile ) {

					// Get Linked Accounts Information					
					let linkedAccounts   = profile.Linked_Accounts
					try { 
						linkedAccounts = JSON.parse ( linkedAccounts ).LinkedAccounts 
					} 
					catch (e){}

					console.log({UNFormatProfile: profile})
					// process linked account details
					profile.Linked_Accounts = await Promise.all ( linkedAccounts.map ( ( linked ) => this.accountMapper (linked, userId) ) )
			
					logData.resposeCode = 200
					
					//logData.responseProfile = profile
					this.settings.log        && ctx.emit ( 'create.log', logData)

					let response = {
						success: true,
						requestId,
						data   : await this.formatProfile ( profile )
					}
					console.log({FormatProfile: response.data})
					logData.responseData = 'successful'
					this.settings.log        && ctx.emit ( 'create.log', logData)

					return await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(response) });
					
				}

				// cant get users profile
				if ( !hasProfile ) {
					logData.type = 'debug'
					logData.resposeCode = 201
					

					let response = {
						success: false,
						requestId,
						message: `Unable to fetch profile for user ${userId}`
					}
					logData.responseData = response
					this.settings.log        && ctx.emit ( 'create.log', logData)

					return await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(response) });
				}
			}
		}, // -- Done	
		fetchAccounts             : {
			rest: '/fetch-accounts',
			params : {
				type : 'string',
				email: 'email'
			},
			async handler ( ctx ) {

				const { type, email } = ctx.params

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: '',
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				if ( type === 'deposit' ) {
					let { resultStatus:success, result: data } =  await ctx.call ( 'core-database.query', {
						'request-name': 'get.deposit.accounts',
						'payload'     : { ...ctx.params }
					})
					if ( success && data[0] instanceof Array && data[0].length > 0 ){
						logData.resposeCode = 200
						logData.responseData = 'successful' 
						this.settings.log        && ctx.emit ( 'create.log', logData)

						return {
							success,
							data:data[0]
						}
					}
					else {
						logData.type = 'debug'
						logData.resposeCode = 201
						logData.responseData = `Couldnt fetch Deposit accounts for user ${email}`
						this.settings.log        && ctx.emit ( 'create.log', logData)

						return {
							success: false,
							error:`Couldnt fetch Deposit accounts for user ${email}`
						}
					}
				}
			} 
		}, // -- Done
		updateRejectedTransaction : {
			/**
			 * To update a transaction:
			 *  1. Authorizers
			 * 	  - check mandate type
			 *    - check if all authorizers willhave signed after the authorizer signs
			 *    - if so, mark in staging tableas fully reviewed
			 *    - add to the audit trail either way
			 *  2. Reviewers
			 * 	  - if all reviewers have signed, change the status to authorization level
			 *    - add to the audit trail
			 */
			rest  : "/update-rejected-transaction",
			params: {
				transactionId : "string",
				userid        : "email",
				roleCode      : "string",
				transactions  : "array"
			},
			async handler ( ctx ) {
				/**
				 * 	INPUTTER - updates rejected transactions
				 */
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: '',
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { resultStatus: success } = await ctx.call ( 'core-database.query', {
					'request-name' : 'update.rejected.transaction',
					payload : {
						transactionId, // updates the staging table
						roleCode : 'M0001' // -- updates the staging table
					}
				})

				logData.responseData = success? 'Transaction updated successfully' : 'Transaction update failed'
				this.settings.log        && ctx.emit ( 'create.log', logData)

				return {
					success,
					message : success? 'Transaction updated successfully' : 'Transaction update failed'
				}
			}
		}, // -- Done 
		updateTransaction         : {
			/**
			 * To update a transaction:
			 *  1. Authorizers
			 * 	  - check mandate type
			 *    - check if all authorizers willhave signed after the authorizer signs
			 *    - if so, mark in staging tableas fully reviewed
			 *    - add to the audit trail either way
			 *  2. Reviewers
			 * 	  - if all reviewers have signed, change the status to authorization level
			 *    - add to the audit trail
			 */
			rest  : "/update-transaction",
			params: {
				payload       : "string",
				$$strict  	  : true
			},
			async handler ( ctx ) {
				let encrptedPayload = ctx.params.payload
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload: encrptedPayload });
				decrypted = JSON.parse(decrypted)

				// // console.log('updating transaction')
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					dbParams: decrypted,
					resposeCode: decrypted,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { transactionId, userId, roleCode, account, authRules, mandateType, reviewerLevel, mandateeClass, payload, amount, sessionToken, perTransactionLimit, dailyTransactionLimit } = decrypted
				//let perTransactionLimit = 0, dailyTransactionLimit = 0

				// // console.log(JSON.stringify(ctx.params,null, 4))

				/**
				 * 	REVIEWER
				 *  	- check if the current stage is at M0003 in the staging table
				 * 		- if all other reviewers have signed pending this reviewer, then
				 *        update level to next reviewer level, if there is no next reviewer level
				 *        change the level to  authorizer
				 *      - if all reviewers have signed and reviewer level is complete, do nothing
				 */
				if ( roleCode === 'M0003'){

					let status = await ctx.call ( 'core-database.query', {
						'request-name' : 'get.review.status',
						payload : { transactionId, account, reviewerLevel, userId }
					})

					let hasData  = status.resultStatus && status.result instanceof Array && status.result[0] instanceof Array && status.result[0].length > 0 

					if ( hasData && status.result[0][0].success && !status.result[0][0].hasSigned ){
						let data = false
						try {
							data = JSON.parse ( status.result[0][0].reviewerStatus )
						}
						catch ( e ){}

						if ( data ) {
							
							let levelStatus        = data.find ( e => parseInt( reviewerLevel) === parseInt ( reviewerLevel) )
							let remainingReviewers = parseInt(levelStatus.mandatoryCount) - parseInt(levelStatus.reviewedCount)

							if (  remainingReviewers > 0 ) {
								
								let status = await ctx.call ( 'core-database.query', {
									'request-name' : 'update.review.status',
									payload : {
										transactionId,
										account,
										roleCode,
										userId,								
										nextLevel: 'M0003',
										reviewerLevel
									}
								})
								logData.responseData = `review status updated successfully`
								this.settings.log        && ctx.emit ( 'create.log', logData)


								return {
									success : status.resultStatus,
									message :`review status updated successfully`
								}
							}
							if (  remainingReviewers === 0 ) {
								logData.type = 'debug'
								logData.responseData = `The tranaction has already been reviewed by the mandatory reveiewers at this level`
								this.settings.log        && ctx.emit ( 'create.log', logData)
								return {
									success:false,
									message: `The tranaction has already been reviewed by the mandatory reveiewers at this level`
								}
							}
						}
						else {
							logData.type = 'debug'
							logData.responseData = `Invalid review status recieved from the DB`
							this.settings.log        && ctx.emit ( 'create.log', logData)
								
							return {
								success:false,
								message: `Invalid review status recieved`
							}	
						}
					}
					if ( hasData && !status.result[0][0].success ) {
						logData.type = 'debug'
						logData.responseData = `You cannot Authorize as the currenct transaction level is ${status.result[0][0].currentStage}`
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success:false,
							message: `You cannot Authorize as the currenct transaction level is ${status.result[0][0].currentStage}`
						}
					}
					if ( hasData && status.result[0][0].hasSigned ) {
						logData.type = 'debug'
						logData.responseData = `You have already reviewed the transaction`
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success:false,
							message: `You have already reviewed the transaction`
						}
					}
					if ( !hasData ) {
						logData.type = 'debug'
						logData.responseData = `Update transaction failed`
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success:false,
							message: `Update transaction failed`
						}
					}
				}

				/**
				 * 	AUTHORIZER
				 * 		- check auth rules and mandate type
				 * 		- based on the mandate type, determine if this authorizer can sign
				 *      - if can sign, determine if they are the last signatory
				 *      - if they are the last signatory, change fully reviewed to true then begin processing fully reviewed
				 *       transactions
				 * 
				 */
				if ( roleCode === 'M0002'){

					let 
					processedSignatures = 0, 
					canApprove          = false, 
					isFinalApprover     = false
					

					// Mandate By Limit
					if ( mandateType === 'MT001' ) {

						// // console.log ( `Update-Transaction - Processing mandates by limit...` )

						//get current rules from the limit
						let rulesApplied           = authRules.find ( e => {

							let minimum = e.minimum
							let maximum = e.maximum
							
							if ( amount >= minimum && amount <= maximum ) {
								return e
							} 
						})

						// By Limit: {"minimum":10,"maximum":500000,"soleSignatories":["A"],"jointSignatories":{"minNumber":3,"mandatory":['B','C']},"accountNumber":"0021006001722","customerID":"1000092921"}
						// By Limit: {"minimum":501000,"maximum":1000000,"soleSignatories":["B"],"jointSignatories":{"minNumber":3,"mandatory":['C','D']},

						if ( rulesApplied ) {

							//perTransactionLimit   = rulesApplied.txnLimit? rulesApplied.txnLimit : '0' ,
							//dailyTransactionLimit = rulesApplied.companyLimit? rulesApplied.companyLimit : '0' 

							let soleSignatories           = rulesApplied.soleSignatories
							let mandatoryjointSignatories = rulesApplied.jointSignatories.mandatory
							let minJointSignatories       = rulesApplied.jointSignatories.minNumber

							//get the users who have approved the transaction
							let approvedBy =  await this.broker.call ( 'core-database.query', {
								'request-name' : 'get.txn.audit.trail.approvers',
								payload        : { 
									txId : transactionId,
									stage: 'M0002'
								}
							})
							
							// Has an initial approver
							if ( 
								approvedBy.resultStatus &&
								approvedBy.result instanceof Array &&
								approvedBy.result[0] instanceof Array &&
								approvedBy.result[0].length > 0
							){

								let authorizedBy             = approvedBy.result[0].map ( e => e.mandateeClass )
								let mandatorySignatoryCount  = 0

								/**
								 * user can sign if:
								 * 	1. no sole signatory has signed
								 */
								if ( soleSignatories.includes ( mandateeClass )  ) {
									for ( let authorizer of authorizedBy ) {
										if ( !soleSignatories.includes ( authorizer ) ) {
											canApprove = true
											isFinalApprover = true
										}
									}									
								}

								/**
								 * user can sgn if:
								 *  2. if he is a mandatory joint signatory
								 */
								else if ( mandatoryjointSignatories.includes ( mandateeClass ) ){
									for ( let authorizer of authorizedBy ) {
										if ( mandatoryjointSignatories.includes ( authorizer ) ) {
											mandatorySignatoryCount = mandatorySignatoryCount + 1
										}
									}	
									
									if ( ( parseInt ( minJointSignatories ) - mandatorySignatoryCount  ) > 0  ){
										canApprove = true
									}

									if ( ( parseInt ( minJointSignatories ) - mandatorySignatoryCount ) === 1 ) {
										isFinalApprover = true
									}
								}

								 /**
								 * user can view if:
								 *  3. if he is a non mandatory joint signatory 
								 */
								else if ( !mandatoryjointSignatories.includes ( mandateeClass ) ){
									let soleAuthorizerCount = 0		
									for ( let authorizer of authorizedBy ) {
										if ( soleSignatories.includes ( authorizer ) ) {
											soleAuthorizerCount  = soleAuthorizerCount + 1 
										}
									}

									for ( let authorizer of authorizedBy ) {
										if ( mandatoryJointSignatories.includes ( authorizer ) ) {
											mandatorySignatoryCount  = mandatorySignatoryCount + 1 
										}
									}
									
									
									
									if ( soleAuthorizerCount === 0 && ( minJointSignatories - mandatoryjointSignatories.length  ) > 0  ) {
										canApprove = true
										if ( ( minJointSignatories - mandatoryjointSignatories.length  ) === 1 && mandatoryjointSignatories.length === mandatorySignatoryCount ){
											isFinalApprover = true
										}
									}
								}														
							}

							if ( 
								approvedBy.resultStatus &&
								approvedBy.result instanceof Array &&
								approvedBy.result[0] instanceof Array &&
								approvedBy.result[0].length === 0
							){

								// mandatory signatory
								if ( mandatoryjointSignatories.includes ( mandateeClass ) ){
									canApprove = true
								}

								// 1 - 1
								if ( minJointSignatories === 1 ){
									isFinalApprover = true
								}

								if ( soleSignatories.includes ( mandateeClass ) ) {
									canApprove      = true
									isFinalApprover =  true
								}

								if ( ( minJointSignatories - mandatoryjointSignatories.length ) > 0 ){
									canApprove = true
								}


							}
						}

					}

					// Mandate By Class
					if ( mandateType === 'MT002' ) {

						// // console.log ( `Update-Transaction - Processing mandates by Class...` )

						//get initiated by
						let approvedBy =  await this.broker.call ( 'core-database.query', {
							'request-name' : 'get.txn.audit.trail.approvers',
							payload        : { 
								txId:transactionId,
								stage: 'M0002'
							}
						})

						// {"A":{"maximum":"200000","jointSignatories":{"signatories":[],"minNumber":0}},"maximum":"200000","accountNumber":"0021006000991","customerID":"1000052488","txnLimit":"200000.00","companyLimit":"200000.00"}

						// // console.log ( JSON.stringify ( { approvedBy }, null, 4 ) )

						// Has an initial approver
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length > 0
						){
							
							//check if from rules of initiated by, the class is allowed
							let authorizedBy           = approvedBy.result[0].map ( e => e.mandateeClass )
							let initialAuthorizerClass = authorizedBy[0]
							let rules                  = authRules.find ( rule => typeof ( rule[ initialAuthorizerClass ] ) !== 'undefined' )
							let rulesApplied           = rules[ initialAuthorizerClass ]
							let amountIsJointlySigned  = false

							//perTransactionLimit   = rules.txnLimit,
							//dailyTransactionLimit = rules.companyLimit



							if ( parseInt(rulesApplied.isAnyAmount) ) {
								amountIsJointlySigned = true
							}
							else {
								amountIsJointlySigned  = rulesApplied.maximum < amount
							}

							if ( amountIsJointlySigned && rulesApplied ){

								// we are supposed to allow anyone who is joint to sign and perform and or based on the minimumJoint signatories
								let jointSignatories        = rulesApplied.jointSignatories.signatories
								let minimumJointSignatories = parseInt ( rulesApplied.jointSignatories.minNumber ) // cater for initial authorizer

								//check if everyone required to sign has signed
								let jointSignatoriesWhoHaveSigned = 0

								for ( let jointSignatory of jointSignatories ) {
									if ( authorizedBy.includes ( jointSignatory ) ) {
										jointSignatoriesWhoHaveSigned = jointSignatoriesWhoHaveSigned + 1
									}
								}

								if ( 
									( minimumJointSignatories - jointSignatoriesWhoHaveSigned) > 0  &&
									!authorizedBy.includes ( mandateeClass ) &&
									jointSignatories.includes ( mandateeClass )
								){
									canApprove = true
									if ( (minimumJointSignatories - jointSignatoriesWhoHaveSigned) === 1 ){
										isFinalApprover = true
									}
								}
							}
							else if ( !amountIsJointlySigned && rulesApplied ) {
								canApprove      = true
								isFinalApprover = true
							}
													
						}

						// Doesnt have an Initial approver 
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length === 0
						){
							// check if the user is the final approver
							let initialAuthorizerClass = mandateeClass
							let rules                  = authRules.find ( rule => typeof ( rule[ initialAuthorizerClass ] ) !== 'undefined' )
							let rulesApplied           = rules[ initialAuthorizerClass ]
							let amountIsJointlySigned  = false

							if ( parseInt(rulesApplied.isAnyAmount) ) {
								amountIsJointlySigned = true
							}
							else {
								amountIsJointlySigned  = rulesApplied.maximum < amount
							}

							if ( amountIsJointlySigned && rulesApplied ) {
								canApprove =  true
							}
							else if ( !amountIsJointlySigned && rulesApplied ){
								canApprove      = true
								isFinalApprover = true
							}
							
						}
						
					}

					// Mandate With No Limit
					if ( mandateType === 'MT003' ) {

						// // console.log ( `Update-Transaction - Processing mandates with no Limits...` )
						authRules = authRules.filter ( e => e && e.mandatorySignatories )

							/*
								"authorizedBy": [
									"A"
								],
								"mandateeClass": "B",
								"rules": {
									"mandatorySignatories": [
										"A"
									],
									"minNumber": "2",
									"accountNumber": "0021006001721",
									"customerID": "1000092924",
									"txnLimit": "5000000.00",
									"companyLimit": "5000000.00"
								},
							*/
						

						//get initial authorizer
						//get initiated by
						let approvedBy =  await this.broker.call ( 'core-database.query', {
							'request-name' : 'get.txn.audit.trail.approvers',
							payload        : { 
								txId:transactionId,
								stage: 'M0002'
							}
						})
						
						// Has an initial approver
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length > 0
						){

							//check if from rules of initiated by, the class is allowed
							let authorizers       = approvedBy.result[0].map ( e => e.mandateeClass ).filter ( e => e && e )
							let rules             = authRules.find ( rule => rule.mandatorySignatories.includes( authorizers[0] ) )

							if( rules instanceof Array ) {
								rules = rules[0]
							}
							if( rules ){

								//perTransactionLimit      = rules.txnLimit,
								//dailyTransactionLimit    = rules.companyLimit
								let rulesApplied         = rules					
								let mandatorySignatories = rulesApplied.mandatorySignatories
								let minimumSignatories   = parseInt ( rulesApplied.minNumber, 10 )
								let processedSignatures  = authorizers.length	
	
								// User is a mandatory signatory
								if ( 
									mandatorySignatories.includes ( mandateeClass ) && 
									!authorizers.includes( mandateeClass) && 
									( minimumSignatories - processedSignatures) > 0 
								){
									canApprove = true
									if ( ( minimumSignatories - processedSignatures ) === 1 ) {
										isFinalApprover = true
									}
								}
	
								// user is not a mandatory signatory
								if ( mandatorySignatories.length < minimumSignatories && !mandatorySignatories.includes ( mandateeClass )  ) {
									let nonMandatoryCount = 0
									authorizers.map ( e => {
										if ( !mandatorySignatories.includes ( e ) ) {
											nonMandatoryCount = nonMandatoryCount + 1
										}
									})
	
	
									let mandatoryCount = 0
									authorizers.map ( e => {
										if ( mandatorySignatories.includes ( e ) ) {
											mandatoryCount = mandatoryCount + 1
										}
									})
	
									// 4 - 2 - 1
									let remainingSlots  = minimumSignatories - mandatorySignatories.length - nonMandatoryCount
									
									if ( remainingSlots > 0  ){
	
										canApprove = true
	
										if ( remainingSlots === 1 && mandatoryCount === mandatorySignatories.length  ) {
											isFinalApprover = true
										}
									}
	
									
									
								}
							}

						}

						// Doesnt have an Initial approver 
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length === 0
						){

							//check if from rules of initiated by, the class is allowed
							let rulesApplied         = authRules[0]						
							let mandatorySignatories = rulesApplied.mandatorySignatories
							let minimumSignatories   = parseInt(rulesApplied.minNumber)	

							// Mandatory Signatory - single slot
							if ( 
								mandatorySignatories.length === minimumSignatories && 
								minimumSignatories === 1 && 
								mandatorySignatories.includes ( mandateeClass )  
							) {
								canApprove      = true
								isFinalApprover =  true
							}
							
							if ( mandatorySignatories.includes ( mandateeClass ) ) {
								canApprove = true
							}
							if ( !mandatorySignatories.includes ( mandateeClass ) &&  ( minimumSignatories - mandatorySignatories ) > 0  ) {
								canApprove = true
							}
						}


					}

					// // console.log({ canApprove, isFinalApprover })

					// Perform transactions
					if (  canApprove && isFinalApprover  ) {
						// update tb corporate audit trail
						// update tb corporate staging to fully approved

						let action = payload.action
						let newAction = ''
						let keys = Object.keys ( apiTypes['ib-api'] )

						

						for ( let key of keys ) {
							let replaced = key.replace ( /'/g,'').replace ( /;/g,'')

							if ( replaced === action ) {
								newAction = key
							}
						}



						payload = {
							...payload,
							action:newAction,
							perTransactionLimit,
							dailyTransactionLimit,
							sessionToken
						}

						let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(payload) });

						logData['ESB-params'] = { payload, decrypted }
						ctx.emit ( 'create.log', logData)
						let response = await ctx.call ( 'transactions.request', { payload: encryptedPayload } )
						response = await ctx.call('core-security.ibDecrypt', { payload: response });
						response = JSON.parse(response)

						if ( response.success ) {
							let { resultStatus: success } = await ctx.call ( 'core-database.query', {
								'request-name': 'fully.approve',
								payload : {
									transactionId,
									userId,		
									txDate: moment ().format('YYYY-MM-DD HH:mm:ss'),					
									stage: 'M0002'
								}
							})

							logData.responseData = success ? 'Transaction approved successfully' : 'Unable to approve the transaction at this time, please try again later'
							this.settings.log        && ctx.emit ( 'create.log', logData)

							return {
								success,
								message : success ? 'Transaction approved successfully' : 'Unable to approve the transaction at this time, please try again later'
							}
						}
							
						logData.responseData = response.message  ? response.message : 'Unable to approve the transaction at this time, please try again later'
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success: false,
							message: response.message  ? response.message : 'Unable to approve the transaction at this time, please try again later'
						}
					}
					if (  canApprove && !isFinalApprover ) {
						// update tb corporate audit trail only
						let { resultStatus: success } = await ctx.call ( 'core-database.query', {
							'request-name': 'partially.approve',
							payload : {
								transactionId,
								userId,								
								txDate: moment ().format('YYYY-MM-DD HH:mm:ss'),					
								stage: 'M0002'
							}
						})		
						
						logData.responseData = success ? 'Partial Approval. Transaction approved successfully' : 'Partial Approval. Unable to approve the transaction at this time, please try again later'
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success,
							message : success ? 'Transaction approved successfully' : 'Unable to approve the transaction at this time, please try again later'
						}
					}

				}
				logData.responseData = 'Unable to approve the transaction at this time, please try again later'
				this.settings.log        && ctx.emit ( 'create.log', logData)
				return {
					success : false,
					message : 'Unable to approve the transaction at this time, please try again later'
				}
			}
		}, // -- Done
		updateBulkTransaction         : {
			/**
			 * To update a transaction:
			 *  1. Authorizers
			 * 	  - check mandate type
			 *    - check if all authorizers willhave signed after the authorizer signs
			 *    - if so, mark in staging tableas fully reviewed
			 *    - add to the audit trail either way
			 *  2. Reviewers
			 * 	  - if all reviewers have signed, change the status to authorization level
			 *    - add to the audit trail
			 */
			rest  : "/update-bulk-transaction",
			params: {
				payload       : "string",
				$$strict  	  : true
			},
			async handler ( ctx ) {
				let encrptedPayload = ctx.params.payload
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload: encrptedPayload });
				decrypted = JSON.parse(decrypted)

				 //console.log('updating transaction')
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					action: 'update-bulk-transaction',
					requestParams: ctx.params,
					dbParams: decrypted,
					resposeCode: decrypted,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { batchNumber, name, tax, charge, transactionId, userId, roleCode, account, authRules, mandateType, reviewerLevel, mandateeClass, amount, sessionToken, perTransactionLimit, dailyTransactionLimit } = decrypted
				//let perTransactionLimit = 0, dailyTransactionLimit = 0

				 //console.log(JSON.stringify(decrypted,null, 4))

				/**
				 * 	REVIEWER
				 *  	- check if the current stage is at M0003 in the staging table
				 * 		- if all other reviewers have signed pending this reviewer, then
				 *        update level to next reviewer level, if there is no next reviewer level
				 *        change the level to  authorizer
				 *      - if all reviewers have signed and reviewer level is complete, do nothing
				 */
				if ( roleCode === 'M0003'){

					let status = await ctx.call ( 'core-database.query', {
						'request-name' : 'get.review.status',
						payload : { transactionId, account, reviewerLevel, userId }
					})

					let hasData  = status.resultStatus && status.result instanceof Array && status.result[0] instanceof Array && status.result[0].length > 0 

					if ( hasData && status.result[0][0].success && !status.result[0][0].hasSigned ){
						let data = false
						try {
							data = JSON.parse ( status.result[0][0].reviewerStatus )
						}
						catch ( e ){}

						if ( data ) {
							
							let levelStatus        = data.find ( e => parseInt( reviewerLevel) === parseInt ( reviewerLevel) )
							let remainingReviewers = parseInt(levelStatus.mandatoryCount) - parseInt(levelStatus.reviewedCount)

							if (  remainingReviewers > 0 ) {
								
								let status = await ctx.call ( 'core-database.query', {
									'request-name' : 'update.review.status',
									payload : {
										transactionId,
										account,
										roleCode,
										userId,								
										nextLevel: 'M0003',
										reviewerLevel
									}
								})
								logData.responseData = `review status updated successfully`
								this.settings.log        && ctx.emit ( 'create.log', logData)


								return {
									success : status.resultStatus,
									message :`review status updated successfully`
								}
							}
							if (  remainingReviewers === 0 ) {
								logData.type = 'debug'
								logData.responseData = `The tranaction has already been reviewed by the mandatory reveiewers at this level`
								this.settings.log        && ctx.emit ( 'create.log', logData)
								return {
									success:false,
									message: `The tranaction has already been reviewed by the mandatory reveiewers at this level`
								}
							}
						}
						else {
							logData.type = 'debug'
							logData.responseData = `Invalid review status recieved from the DB`
							this.settings.log        && ctx.emit ( 'create.log', logData)
								
							return {
								success:false,
								message: `Invalid review status recieved`
							}	
						}
					}
					if ( hasData && !status.result[0][0].success ) {
						logData.type = 'debug'
						logData.responseData = `You cannot Authorize as the currenct transaction level is ${status.result[0][0].currentStage}`
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success:false,
							message: `You cannot Authorize as the currenct transaction level is ${status.result[0][0].currentStage}`
						}
					}
					if ( hasData && status.result[0][0].hasSigned ) {
						logData.type = 'debug'
						logData.responseData = `You have already reviewed the transaction`
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success:false,
							message: `You have already reviewed the transaction`
						}
					}
					if ( !hasData ) {
						logData.type = 'debug'
						logData.responseData = `Update transaction failed`
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success:false,
							message: `Update transaction failed`
						}
					}
				}

				/**
				 * 	AUTHORIZER
				 * 		- check auth rules and mandate type
				 * 		- based on the mandate type, determine if this authorizer can sign
				 *      - if can sign, determine if they are the last signatory
				 *      - if they are the last signatory, change fully reviewed to true then begin processing fully reviewed
				 *       transactions
				 * 
				 */
				if ( roleCode === 'M0002'){

					let 
					processedSignatures = 0, 
					canApprove          = false, 
					isFinalApprover     = false
					

					// Mandate By Limit
					if ( mandateType === 'MT001' ) {

						// // console.log ( `Update-Transaction - Processing mandates by limit...` )

						//get current rules from the limit
						let rulesApplied           = authRules.find ( e => {

							let minimum = e.minimum
							let maximum = e.maximum
							
							if ( amount >= minimum && amount <= maximum ) {
								return e
							} 
						})

						// By Limit: {"minimum":10,"maximum":500000,"soleSignatories":["A"],"jointSignatories":{"minNumber":3,"mandatory":['B','C']},"accountNumber":"0021006001722","customerID":"1000092921"}
						// By Limit: {"minimum":501000,"maximum":1000000,"soleSignatories":["B"],"jointSignatories":{"minNumber":3,"mandatory":['C','D']},

						if ( rulesApplied ) {

							//perTransactionLimit   = rulesApplied.txnLimit? rulesApplied.txnLimit : '0' ,
							//dailyTransactionLimit = rulesApplied.companyLimit? rulesApplied.companyLimit : '0' 

							let soleSignatories           = rulesApplied.soleSignatories
							let mandatoryjointSignatories = rulesApplied.jointSignatories.mandatory
							let minJointSignatories       = rulesApplied.jointSignatories.minNumber

							//get the users who have approved the transaction
							let approvedBy =  await this.broker.call ( 'core-database.query', {
								'request-name' : 'get.txn.audit.trail.approvers',
								payload        : { 
									txId : transactionId,
									stage: 'M0002'
								}
							})
							
							// Has an initial approver
							if ( 
								approvedBy.resultStatus &&
								approvedBy.result instanceof Array &&
								approvedBy.result[0] instanceof Array &&
								approvedBy.result[0].length > 0
							){

								let authorizedBy             = approvedBy.result[0].map ( e => e.mandateeClass )
								let mandatorySignatoryCount  = 0

								/**
								 * user can sign if:
								 * 	1. no sole signatory has signed
								 */
								if ( soleSignatories.includes ( mandateeClass )  ) {
									for ( let authorizer of authorizedBy ) {
										if ( !soleSignatories.includes ( authorizer ) ) {
											canApprove = true
											isFinalApprover = true
										}
									}									
								}

								/**
								 * user can sgn if:
								 *  2. if he is a mandatory joint signatory
								 */
								else if ( mandatoryjointSignatories.includes ( mandateeClass ) ){
									for ( let authorizer of authorizedBy ) {
										if ( mandatoryjointSignatories.includes ( authorizer ) ) {
											mandatorySignatoryCount = mandatorySignatoryCount + 1
										}
									}	
									
									if ( ( parseInt ( minJointSignatories ) - mandatorySignatoryCount  ) > 0  ){
										canApprove = true
									}

									if ( ( parseInt ( minJointSignatories ) - mandatorySignatoryCount ) === 1 ) {
										isFinalApprover = true
									}
								}

								 /**
								 * user can view if:
								 *  3. if he is a non mandatory joint signatory 
								 */
								else if ( !mandatoryjointSignatories.includes ( mandateeClass ) ){
									let soleAuthorizerCount = 0		
									for ( let authorizer of authorizedBy ) {
										if ( soleSignatories.includes ( authorizer ) ) {
											soleAuthorizerCount  = soleAuthorizerCount + 1 
										}
									}

									for ( let authorizer of authorizedBy ) {
										if ( mandatoryJointSignatories.includes ( authorizer ) ) {
											mandatorySignatoryCount  = mandatorySignatoryCount + 1 
										}
									}
									
									
									
									if ( soleAuthorizerCount === 0 && ( minJointSignatories - mandatoryjointSignatories.length  ) > 0  ) {
										canApprove = true
										if ( ( minJointSignatories - mandatoryjointSignatories.length  ) === 1 && mandatoryjointSignatories.length === mandatorySignatoryCount ){
											isFinalApprover = true
										}
									}
								}														
							}

							if ( 
								approvedBy.resultStatus &&
								approvedBy.result instanceof Array &&
								approvedBy.result[0] instanceof Array &&
								approvedBy.result[0].length === 0
							){

								// mandatory signatory
								if ( mandatoryjointSignatories.includes ( mandateeClass ) ){
									canApprove = true
								}

								// 1 - 1
								if ( minJointSignatories === 1 ){
									isFinalApprover = true
								}

								if ( soleSignatories.includes ( mandateeClass ) ) {
									canApprove      = true
									isFinalApprover =  true
								}

								if ( ( minJointSignatories - mandatoryjointSignatories.length ) > 0 ){
									canApprove = true
								}


							}
						}

					}

					// Mandate By Class
					if ( mandateType === 'MT002' ) {

						// // console.log ( `Update-Transaction - Processing mandates by Class...` )

						//get initiated by
						let approvedBy =  await this.broker.call ( 'core-database.query', {
							'request-name' : 'get.txn.audit.trail.approvers',
							payload        : { 
								txId:transactionId,
								stage: 'M0002'
							}
						})

						// {"A":{"maximum":"200000","jointSignatories":{"signatories":[],"minNumber":0}},"maximum":"200000","accountNumber":"0021006000991","customerID":"1000052488","txnLimit":"200000.00","companyLimit":"200000.00"}

						// // console.log ( JSON.stringify ( { approvedBy }, null, 4 ) )

						// Has an initial approver
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length > 0
						){
							
							//check if from rules of initiated by, the class is allowed
							let authorizedBy           = approvedBy.result[0].map ( e => e.mandateeClass )
							let initialAuthorizerClass = authorizedBy[0]
							let rules                  = authRules.find ( rule => typeof ( rule[ initialAuthorizerClass ] ) !== 'undefined' )
							let rulesApplied           = rules[ initialAuthorizerClass ]
							let amountIsJointlySigned  = false

							//perTransactionLimit   = rules.txnLimit,
							//dailyTransactionLimit = rules.companyLimit



							if ( parseInt(rulesApplied.isAnyAmount) ) {
								amountIsJointlySigned = true
							}
							else {
								amountIsJointlySigned  = rulesApplied.maximum < amount
							}

							if ( amountIsJointlySigned && rulesApplied ){

								// we are supposed to allow anyone who is joint to sign and perform and or based on the minimumJoint signatories
								let jointSignatories        = rulesApplied.jointSignatories.signatories
								let minimumJointSignatories = parseInt ( rulesApplied.jointSignatories.minNumber ) // cater for initial authorizer

								//check if everyone required to sign has signed
								let jointSignatoriesWhoHaveSigned = 0

								for ( let jointSignatory of jointSignatories ) {
									if ( authorizedBy.includes ( jointSignatory ) ) {
										jointSignatoriesWhoHaveSigned = jointSignatoriesWhoHaveSigned + 1
									}
								}

								if ( 
									( minimumJointSignatories - jointSignatoriesWhoHaveSigned) > 0  &&
									!authorizedBy.includes ( mandateeClass ) &&
									jointSignatories.includes ( mandateeClass )
								){
									canApprove = true
									if ( (minimumJointSignatories - jointSignatoriesWhoHaveSigned) === 1 ){
										isFinalApprover = true
									}
								}
							}
							else if ( !amountIsJointlySigned && rulesApplied ) {
								canApprove      = true
								isFinalApprover = true
							}
													
						}

						// Doesnt have an Initial approver 
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length === 0
						){
							// check if the user is the final approver
							let initialAuthorizerClass = mandateeClass
							let rules                  = authRules.find ( rule => typeof ( rule[ initialAuthorizerClass ] ) !== 'undefined' )
							let rulesApplied           = rules[ initialAuthorizerClass ]
							let amountIsJointlySigned  = false

							if ( parseInt(rulesApplied.isAnyAmount) ) {
								amountIsJointlySigned = true
							}
							else {
								amountIsJointlySigned  = rulesApplied.maximum < amount
							}

							if ( amountIsJointlySigned && rulesApplied ) {
								canApprove =  true
							}
							else if ( !amountIsJointlySigned && rulesApplied ){
								canApprove      = true
								isFinalApprover = true
							}
							
						}
						
					}

					// Mandate With No Limit
					if ( mandateType === 'MT003' ) {

						// // console.log ( `Update-Transaction - Processing mandates with no Limits...` )
						authRules = authRules.filter ( e => e && e.mandatorySignatories )

							/*
								"authorizedBy": [
									"A"
								],
								"mandateeClass": "B",
								"rules": {
									"mandatorySignatories": [
										"A"
									],
									"minNumber": "2",
									"accountNumber": "0021006001721",
									"customerID": "1000092924",
									"txnLimit": "5000000.00",
									"companyLimit": "5000000.00"
								},
							*/
						

						//get initial authorizer
						//get initiated by
						let approvedBy =  await this.broker.call ( 'core-database.query', {
							'request-name' : 'get.txn.audit.trail.approvers',
							payload        : { 
								txId:transactionId,
								stage: 'M0002'
							}
						})
						
						// Has an initial approver
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length > 0
						){

							//check if from rules of initiated by, the class is allowed
							let authorizers       = approvedBy.result[0].map ( e => e.mandateeClass ).filter ( e => e && e )
							let rules             = authRules.find ( rule => rule.mandatorySignatories.includes( authorizers[0] ) )

							if( rules instanceof Array ) {
								rules = rules[0]
							}
							if( rules ){

								//perTransactionLimit      = rules.txnLimit,
								//dailyTransactionLimit    = rules.companyLimit
								let rulesApplied         = rules					
								let mandatorySignatories = rulesApplied.mandatorySignatories
								let minimumSignatories   = parseInt ( rulesApplied.minNumber, 10 )
								let processedSignatures  = authorizers.length	
	
								// User is a mandatory signatory
								if ( 
									mandatorySignatories.includes ( mandateeClass ) && 
									!authorizers.includes( mandateeClass) && 
									( minimumSignatories - processedSignatures) > 0 
								){
									canApprove = true
									if ( ( minimumSignatories - processedSignatures ) === 1 ) {
										isFinalApprover = true
									}
								}
	
								// user is not a mandatory signatory
								if ( mandatorySignatories.length < minimumSignatories && !mandatorySignatories.includes ( mandateeClass )  ) {
									let nonMandatoryCount = 0
									authorizers.map ( e => {
										if ( !mandatorySignatories.includes ( e ) ) {
											nonMandatoryCount = nonMandatoryCount + 1
										}
									})
	
	
									let mandatoryCount = 0
									authorizers.map ( e => {
										if ( mandatorySignatories.includes ( e ) ) {
											mandatoryCount = mandatoryCount + 1
										}
									})
	
									// 4 - 2 - 1
									let remainingSlots  = minimumSignatories - mandatorySignatories.length - nonMandatoryCount
									
									if ( remainingSlots > 0  ){
	
										canApprove = true
	
										if ( remainingSlots === 1 && mandatoryCount === mandatorySignatories.length  ) {
											isFinalApprover = true
										}
									}
	
									
									
								}
							}

						}

						// Doesnt have an Initial approver 
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length === 0
						){

							//check if from rules of initiated by, the class is allowed
							let rulesApplied         = authRules[0]						
							let mandatorySignatories = rulesApplied.mandatorySignatories
							let minimumSignatories   = parseInt(rulesApplied.minNumber)	

							// Mandatory Signatory - single slot
							if ( 
								mandatorySignatories.length === minimumSignatories && 
								minimumSignatories === 1 && 
								mandatorySignatories.includes ( mandateeClass )  
							) {
								canApprove      = true
								isFinalApprover =  true
							}
							
							if ( mandatorySignatories.includes ( mandateeClass ) ) {
								canApprove = true
							}
							if ( !mandatorySignatories.includes ( mandateeClass ) &&  ( minimumSignatories - mandatorySignatories ) > 0  ) {
								canApprove = true
							}
						}


					}

					// // console.log({ canApprove, isFinalApprover })

					// Perform transactions
					if (  canApprove && isFinalApprover  ) {
						// update tb corporate audit trail
						// update tb corporate staging to fully approved

						let payload = {
							action    : "bulk-upload",
							payload   : {
								batchNumber          : batchNumber,
								perTransactionLimit  ,
								dailyTransactionLimit,
								firstname            : name,
								tax                  : tax ? tax.toString(): "0",
								charge               : charge ? charge.toString(): "0"
		
							},
							sessionToken
						}

						let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(payload) });

						logData['ESB-params'] = { payload, decrypted }
						ctx.emit ( 'create.log', logData)
						let response = await ctx.call ( 'transactions.request', { payload: encryptedPayload } )
						response = await ctx.call('core-security.ibDecrypt', { payload: response });
						response = JSON.parse(response)

						if ( response.success ) {
							let { resultStatus: success } = await ctx.call ( 'core-database.query', {
								'request-name': 'fully.approve',
								payload : {
									transactionId,
									userId,		
									txDate: moment ().format('YYYY-MM-DD HH:mm:ss'),					
									stage: 'M0002'
								}
							})

							logData.responseData = success ? 'Transaction approved successfully' : 'Unable to approve the transaction at this time, please try again later'
							this.settings.log        && ctx.emit ( 'create.log', logData)

							return {
								success,
								message : success ? 'Transaction approved successfully' : 'Unable to approve the transaction at this time, please try again later'
							}
						}
							
						logData.responseData = response.message  ? response.message : 'Unable to approve the transaction at this time, please try again later'
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success: false,
							message: response.message  ? response.message : 'Unable to approve the transaction at this time, please try again later'
						}
					}
					if (  canApprove && !isFinalApprover ) {
						// update tb corporate audit trail only
						let { resultStatus: success } = await ctx.call ( 'core-database.query', {
							'request-name': 'partially.approve',
							payload : {
								transactionId,
								userId,								
								txDate: moment ().format('YYYY-MM-DD HH:mm:ss'),					
								stage: 'M0002'
							}
						})		
						
						logData.responseData = success ? 'Partial Approval. Transaction approved successfully' : 'Partial Approval. Unable to approve the transaction at this time, please try again later'
						this.settings.log        && ctx.emit ( 'create.log', logData)
						return {
							success,
							message : success ? 'Transaction approved successfully' : 'Unable to approve the transaction at this time, please try again later'
						}
					}

				}
				logData.responseData = 'Unable to approve the transaction at this time, please try again later'
				this.settings.log        && ctx.emit ( 'create.log', logData)
				return {
					success : false,
					message : 'Unable to approve the transaction at this time, please try again later'
				}
			}
		}, // -- Done
		rejectTransaction         : {
			rest  : "/reject-transaction",
			params: {
				payload: "string",
				$$strict: true
			},
			async handler(ctx) {
				/**
				 * To reject a transaction:
				 *  1. Authorizers and Reviewers
				 *   	- set the transaction stage to inputter and add the reject reason in corporate staging
				 *   	- add an audit trail entry
				 */

				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: decrypted,
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let rejectTransaction = await ctx.call ( 'core-database.query', {
					'request-name' : 'reject.transaction',
					payload : {
						...decrypted				
					}
				})

				logData.responseData = rejectTransaction.resultStatus ? `The transaction was rejected`: `The Reject operation failed`
				this.settings.log        && ctx.emit ( 'create.log', logData)
				return {
					status : rejectTransaction.resultStatus,
					message: rejectTransaction.resultStatus ? `The transaction was rejected`: `The Reject operation failed`,
				}
			}
		}, // -- Done		
		addReviewerLevel          : {
			rest  : "/add-reviewer-level",
			params: {
				account      : "string",
				roleCode     : "string",
				reviewerCount: "number",
				narration    : "string",
				creatorId    : "email"
			},
			async handler(ctx) {
				/**
				 * To add a reviewer level:
				 * 	- add reviewercount to the account
				 *  - reviewer levelwill be updated automatically
				 *  - fetch the entered records for feedback
				 */
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let addReviewerLevel = await ctx.call ( 'core-database.query', {
					'request-name': 'add.reviewer.level',
					payload       : {...ctx.params }
				})

				logData.responseData = addReviewerLevel.result
				this.settings.log        && ctx.emit ( 'create.log', logData)
				return {
					status : addReviewerLevel.resultStatus,
					message: addReviewerLevel.resultStatus ? `The reviewer level was added successfully`: `The add reviewer level operation failed`,
					data   : addReviewerLevel.result
				}
			}
		}, // -- Done
		fetchAccMandatee : {
			rest : '/fetch-account-mandatee',
			params: {
				accountNumber: "string"
			},
			async handler ( ctx ) {

				let { params } = ctx
				//Userid
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let fetchAccMandate = await ctx.call ( 'core-database.query', {
					'request-name':'get.account.mandatees',
					payload       : {
						accountNumber: params.accountNumber
					}
				})

				//console.log(fetchAccMandate)

				this.settings.log        && ctx.emit ( 'create.log', logData)

				if(fetchAccMandate){
					return { success: true, fetchAccMandate }
				}else{
					logData.type = 'successful'
					logData.responseData = fetchAccMandate
					ctx.emit ( 'create.log', logData)

					return { success: false }
				}

			}
		},
		deleteMandatee : {
			rest : '/remove-account-mandatee',
			async handler ( ctx ) {

				let { params } = ctx
				//Userid
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let removeMandtee = await ctx.call ( 'core-database.query', {
					'request-name':'delete.mandatee',
					payload       : {
						email		  : params.email,
						accountNumber : params.accountNumber
					}
				})

				logData.responseData = removeMandtee
				this.settings.log        && ctx.emit ( 'create.log', logData)

				if(removeMandtee){
					return { success: true, removeMandtee }
				}else{
					return { success: false }
				}

			}
		},
		addMandatee               : {
			rest  : "/add-mandatee",
			params: {
				payload: "string",
				$$strict: true
			},
			async handler(ctx) {
				/**
				 * To add a mandatee:
				 * 	- run the add mandatee sp
				 *  - send an email
				 */
				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: decrypted,
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let addMandatee = await ctx.call ( 'core-database.query', {
					'request-name': 'add.mandatee',
					payload       : { ...decrypted, dob: moment(decrypted.dob).format('YYYY-MM-DD HH:mm:ss') }
				})

				// send email
				if ( addMandatee.resultStatus ) {
					ctx.call ( 'registration.sendActivationEmail', {
						email    : decrypted.userId,
						firstname: decrypted.firstname
					})
				}

				logData.responseData = addMandatee.result
				this.settings.log        && ctx.emit ( 'create.log', logData)
				// return status
				return {
					status : addMandatee.resultStatus,
					message: addMandatee.resultStatus ? `The Mandatee was added successfully`: `The Add Mandatee operation failed`,
					data   : addMandatee.result
				}
			}
		}, // -- Done -> SP has a bug
		updateMandatee            : {
			rest  : "/update-mandatee",
			params: {
				roleCode     : "string",
				mandateeClass: "string",
				reviewerLevel: "number",
				expires      : "number",
				expiryDate   : "string",
				userId       : "email"
			},
			async handler(ctx) {
				/**
				 * To update a mandatee:
				 * 	- tun an update statement against the data provided
				 */
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { resultStatus:success } = ctx.call ( 'core-database.query', {
					'request-name' : 'update.mandatee',
					payload : { ...ctx.params }
				})

				logData.responseData = success ? `The Mandatee was updated successfully`: `The update Mandatee operation failed`
				this.settings.log        && ctx.emit ( 'create.log', logData)
				// return status
				return {
					success,
					message: success ? `The Mandatee was updated successfully`: `The update Mandatee operation failed`
				}
			}
		} //  -- Done
	},
	methods : {
		// process linked account details
		async accountMapper    ( linked, userId      ) {

			let type =  linked.Account.AccountType

			// Corporate Accounts
			if ( type === 'C' ) {

				let getDetails =  await this.broker.call ( 'core-database.query', {
					'request-name' : 'get.mandate.details',
					payload        : { 
						userId,
						accountNumber: linked.Account.AccountNo

					}
				})

				// Process if details are obtained
				let detailsFound = getDetails.resultStatus && getDetails.result instanceof Array && getDetails.result[0] instanceof Array && getDetails.result[0].length === 1
				
				if (  detailsFound ){

					let details            = getDetails.result[0][0]
					linked.Account.details = {}
					console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>',linked.Account.AccountNo, details)

					//add the details systematically
					linked.Account.details.mandateeClass      = details.class
					linked.Account.details.role               = details.roleName
					linked.Account.details.roleCode           = details.roleCode
					linked.Account.details.limit              = details.limit
					linked.Account.details.level              = details.reviewerLevel
					linked.Account.details.mandateType        = details.mandateType
					linked.Account.details.mandateDescription = details.mandateDescription
					linked.Account.details.pending            =  ( ( txn ) => {
							if ( txn ) {
								try {
									txn = JSON.parse(txn)
								}
								catch (e) {}

								return txn
							}
							else {
								return false
							}
					})( details.pendingTxns)
					linked.Account.details.authRules          =  ( ( rules ) => {
						if ( rules ) {
							try {
								rules = JSON.parse(rules)
							}
							catch (e) {}

							return rules
						}
						else {
							return false
						}
					})( details.mandateRules).map (entry => {
						let newEntry = entry
						try {
							newEntry = JSON.parse ( entry.mandate )
							newEntry.type = entry.mandateType
						}
						catch(e){}

						return newEntry
					})

					


					// process if we can view pending transactions
					/**
					 *  get the users role and level if any
					 *  check the above against the transactions role and level
					 *  if user can view, add can view flag as true in pending
					 *  filter pending by can view
					 */
					if ( linked.Account.details.pending ) {
						linked.Account.details.pending = await Promise.all ( 
							linked.Account.details.pending .map ( 
								txn => this.pendingTxnMapper ( txn, linked, userId ) 
							)						
						)

						// filter transactions
						linked.Account.details.pending = linked.Account.details.pending.filter ( txn => txn.canView && delete txn.canView && txn )
					}

				}

				return linked
			}

			// Individual Accounts
			if ( type !== 'C' ) {
				return linked
			}
			
		},
		async pendingTxnMapper ( txn, linked, userId ) {

			/*
				MT001	Mandate By Limit
				MT002	Mandate By Class
				MT003	Mandate With No Limit
				--------------------------------
				M0001  Inputters
				M0003  Reviewers
				M0002  Authorizers			
			*/

			txn.stage = txn.B[txn.B.length -1].stage
			txn.canView = false // By default, the user cant view the transaction
			
			let { roleCode, level, mandateeClass, mandateType, authRules } = linked.Account.details
			let { stage, stageLevel, stagingID                           } = txn

			/**
			 * 	INPUTTERS
			 */
			if ( roleCode === 'M0001' ) {
				/**
				 * Inputters can:
				 * 		1. see the status of transactions that they have initiated 
				 * 		2. edit rejected bulk transactions initiated by any inputter
				 */
				// initiated transactions
				if ( txn.initiatedby === userId  && !txn.isBulk ) {
					txn.canView = true
				} 

				// rejected bulk transactions ( reject reason will be obtained from the audit table )
				if ( txn.isBulk && txn.stage === 'M0001' ) {
					txn.canView  = true
					txn.rejected = true
				}
			}

			/**
			 * 	REVIEWERS
			 */
			if ( stage === 'M0001' && roleCode === 'M0003'  || stage === 'M0003' && roleCode === 'M0003' ) {

				let payload = { 
					txId:stagingID,
					stage: 'M0003',
					level,
					userId,
					account: linked.Account.AccountNo
				}

				let getAuditTrail =  await this.broker.call ( 'core-database.query', {
					'request-name' : 'get.txn.audit.trail',
					payload
				})

				if ( 
					getAuditTrail.resultStatus &&
					getAuditTrail.result instanceof Array &&
					getAuditTrail.result[0] instanceof Array &&
					getAuditTrail.result[0].length === 1
				){

					let res     = getAuditTrail.result[0][0]
					txn.canView = !!res.canView
				}
				else {
					txn.canView = false
				}
				
			}

			//this.logger.info({roleCode, stage})
			/**
			 * 	AUTHORIZERS
			 */			
			if ( stage === 'M0003' && roleCode === 'M0002' || stage === 'M0002' && roleCode === 'M0002' || stage === 'M0001' && roleCode === 'M0002'  ) { // means that its in the review stage and now we want to check if it has passed all review levels

				let isReviewable = false


				let payload = { 
					txId:stagingID,
					stage: 'M0003',
					level,
					userId,
					account: linked.Account.AccountNo
				}

				let getAuditTrail =  await this.broker.call ( 'core-database.query', {
					'request-name' : 'get.txn.audit.trail',
					payload
				})
				//this.logger.info(getAuditTrail)

				if ( 
					getAuditTrail.resultStatus &&
					getAuditTrail.result instanceof Array &&
					getAuditTrail.result[0] instanceof Array &&
					getAuditTrail.result[0].length === 1
				){

					let res     = getAuditTrail.result[0][0]
					isReviewable = !!res.canView
				}

				//this.logger.info(isReviewable)
				if ( !isReviewable ){
					//process the authorization rules
					let amount = txn.amount

					// Mandate By Limit - Shelved for now
					if ( mandateType === 'MT001' ) {

						// // console.log ( `Processing mandates by limit...` )

						//get current rules from the limit
						let rulesApplied           = authRules.find ( e => {

							let minimum = e.minimum
							let maximum = e.maximum
							
							if ( amount >= minimum && amount <= maximum ) {
								return e
							} 
						})

						if ( rulesApplied ) {

							let soleSignatories           = rulesApplied.soleSignatories
							let mandatoryjointSignatories = rulesApplied.jointSignatories.mandatory
							let minJointSignatories       = rulesApplied.jointSignatories.minNumber

							let payload =  { 
								txId:stagingID,
								stage : 'M0002'
							}

							//get the users who have approved the transaction
							let approvedBy =  await this.broker.call ( 'core-database.query', {
								'request-name' : 'get.txn.audit.trail.approvers',
								payload
							})
							
							// Has an initial approver
							if ( 
								approvedBy.resultStatus &&
								approvedBy.result instanceof Array &&
								approvedBy.result[0] instanceof Array &&
								approvedBy.result[0].length > 0
							){

								let res                      = approvedBy.result[0].map ( e => e.mandateeClass )
								let soleSignatoryHasSigned   = false
								let jointSignatorySignCount  = 0
								let mandatorySignatoryCount  = 0

								/**
								 * user can view if:
								 * 	1. no sole signatory has signed
								 *  2. if he is a mandatory joint signatory and noother mandatory joint signatory has signed
								 *  3. if he is a non mandatory joint signatory and there is space for him to sign
								 */

								//check if sole signatory has signed
								res.map ( e => {
									if ( soleSignatories.includes( e ) ){
										soleSignatoryHasSigned = true
									}
									else if ( mandatoryjointSignatories.includes( e ) ) {
										mandatorySignatoryCount ++
									}
									else {
										jointSignatorySignCount ++
									}
								})

								// user is a sole signatory
								if ( 
									!soleSignatoryHasSigned && 
									soleSignatories.includes( mandateeClass ) && // user is a solesignatory 
									minJointSignatories - ( mandatorySignatoryCount + jointSignatorySignCount ) > 0 // alljoint signatories havent signed 
								) {
									// // console.log ( `user is a sole signatory` )
									txn.canView = true
								}

								// user is a mandatory signatory
								if ( 
									!soleSignatoryHasSigned && 
									!soleSignatories.includes( mandateeClass ) &&  // user isnt a sole signatory
									mandatoryjointSignatories.includes( mandateeClass ) && // user is a mandatory signatory
									mandatoryjointSignatories.length - mandatorySignatoryCount  > 0  // not all mandatory signatories have signed
								) {
									// // console.log ( `user is a mandatory signatory` )
									txn.canView =  true
								}

								// user is a none mandatory signatory
								if ( 
									!soleSignatoryHasSigned && 
									!soleSignatories.includes( mandateeClass ) &&  // user isnt a sole signatory
									!mandatoryjointSignatories.includes( mandateeClass ) && // user is a non mandatory signatory
									minJointSignatories - ( mandatorySignatoryCount + jointSignatorySignCount ) > 0 // alljoint signatories havent signed
								) {
									// // console.log ( `user is a non mandatory signatory` )
									txn.canView =  true
								}
														
							}

							if ( 
								approvedBy.resultStatus &&
								approvedBy.result instanceof Array &&
								approvedBy.result[0] instanceof Array &&
								approvedBy.result[0].length === 0
							){
								//check if the user is a sole or joint signatory
								txn.canView = true
							}
						}

					}

					// Mandate By Class
					if ( mandateType === 'MT002' ) {

						// // console.log ( `Processing mandates by Class...` )

						//get initiated by
						let payload =  { 
							txId:stagingID,
							stage : 'M0002'
						}
						let approvedBy =  await this.broker.call ( 'core-database.query', {
							'request-name' : 'get.txn.audit.trail.approvers',
							payload   
						})
						//this.logger.info(approvedBy)

						// Has an initial approver
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length > 0
						){

							//check if from rules of initiated by, the class is allowed
							let authorizedBy           = approvedBy.result[0].map ( e => e.mandateeClass ) //['D','A']
							let initialAuthorizerClass = authorizedBy[0] // D
							let rules                  = authRules.find ( rule => typeof ( rule[ initialAuthorizerClass ] ) !== 'undefined' )
							let rulesApplied           = rules [initialAuthorizerClass]
							let userIsSignatory        = rulesApplied.jointSignatories.signatories.includes ( mandateeClass )
							let authorizedCount        = authorizedBy.length
							let authorizersNeeded      = parseInt (rulesApplied.jointSignatories.minNumber) + 1

							//this.logger.info({authorizedBy,authorizedCount, authorizersNeeded, userIsSignatory, rulesApplied, rules, initialAuthorizerClass})

							if ( 
								( authorizersNeeded - authorizedCount) > 0 && 
								!authorizedBy.includes ( mandateeClass ) && 
								userIsSignatory
							) {
								txn.canView = true
							}	
							else {
								txn.canView = false
							}												
						}

						// Doesnt have an Initial approver 
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length === 0
						){
							txn.canView = true
						}
						
					}

					// Mandate With No Limit
					if ( mandateType === 'MT003' ) {

						// // console.log ( `Processing mandates with no Limits...` )
						let payload =  { 
							txId:stagingID,
							stage : 'M0002'
						}

						
						//get initiated by
						let approvedBy =  await this.broker.call ( 'core-database.query', {
							'request-name' : 'get.txn.audit.trail.approvers',
							payload
						})

						//this.logger.info({approvedBy})
						
						// Has an initial approver
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length > 0
						){

							//check if from rules of initiated by, the class is allowed
							let authorizedBy           = approvedBy.result[0].map ( e => e.mandateeClass )


							/*
								"authorizedBy": [
									"A" //'B'
								],
								"mandateeClass": "A",
								"rules": {
									"mandatorySignatories": [
										"A"
									],
									"minNumber": "2",
									"accountNumber": "0021006001721",
									"customerID": "1000092924",
									"txnLimit": "5000000.00",
									"companyLimit": "5000000.00"
								},
							*/
							//this.logger.info({authorizedBy})

							authRules = authRules.filter ( e => e && e.mandatorySignatories )
							let rules                  = authRules.find ( rule => rule.mandatorySignatories.includes( authorizedBy[0] ) )

							// console.log({authRules, rules})
							// this.logger.info({authRules, rules})

							// stagingID ==='STGKFFA3PXK' && // // console.log (JSON.stringify ({ 
							// 	authorizedBy, 
							// 	mandateeClass, 
							// 	rules, 
							// 	// authRules, 
							// 	// firstAuthorizer: authorizedBy[0]  
							// }, null, 4 ) )

							if( rules instanceof Array ) {
								rules = rules[0]
							}
							if( rules ){
								
								let howManyHaveSigned = authorizedBy.length
								let howManyShouldSign = parseInt ( rules.minNumber, 10 )
								let hasSigned         = authorizedBy.includes( mandateeClass ) 
								let userIsMandatory   = rules.mandatorySignatories.includes ( mandateeClass )
								let remainingSignatories = ( howManyShouldSign - howManyHaveSigned )

								// console.log({remainingSignatories,mandateeClass})
								// this.logger.info({remainingSignatories, mandateeClass, userIsMandatory, howManyShouldSign})

								// mandatory signatory who hasnt signed
								if ( 
									remainingSignatories > 0 && // there is space left to sign
									!hasSigned  &&// user hasnt signed
									userIsMandatory
								) {
									txn.canView = true
								}

								//  non mandatory signatory
								else if (
									remainingSignatories > 0 &&
									!hasSigned  &&
									!userIsMandatory &&
									( howManyShouldSign - rules.mandatorySignatories.length ) > 0
								){
									txn.canView = true
								}
								//default
								else {
									txn.canView = false
								}

								// console.log({CanView: txn.canView})
								// this.logger.info({CanView: txn.canView})
							}

													
						}

						// Doesnt have an Initial approver 
						if ( 
							approvedBy.resultStatus &&
							approvedBy.result instanceof Array &&
							approvedBy.result[0] instanceof Array &&
							approvedBy.result[0].length === 0
						){
							txn.canView = true
						}
					}
				}
				
			}

			return txn
		},
		async formatProfile    ( data ){
			//console.log ( JSON.stringify ( data, null, 4 ) )
			let lastLogin            = data.Previous_Login_Date ?  data.Previous_Login_Date : moment().format()
			let fetchDepositAccounts = await this.broker.call ( 'accounts-mandates.fetchAccounts', { type :'deposit', email : data.Email_Address} )

			let linkedAcc = data.Linked_Accounts.filter( entry => entry && entry.Account.AccountType !== 'W')
			let walletAcc = data.Linked_Accounts.filter( entry => entry && entry.Account.AccountType === 'W')
			
			let formatted = {				
				userid            		: data.User_Name,
				sessionIdTime 			: moment().add(5, 'm').format(),
				personalInfo      		: {
					"name"           : `${data.First_Name} ${data.Second_Name} ${data.Last_Name}`,
					"gender"         : data.GENDER === "M" ? "Male": "Female",
					"nationalID"     : data.Identification_ID,
					"birthday"       : data.DOB,
					"phone"          : data.Customer_No,
					"email"          : data.Email_Address,
					"language"       : data.Language_Setting,	
				},
				investmentsInfo         : {
					depositAccounts : fetchDepositAccounts.success ? fetchDepositAccounts.data : []
				},
				securityInfo      		: {
					//"password"       : data.Password_Hash, 
					"sessionId"	     : data.Profile_Session_Id,
					"login_raw"      : data.Previous_Login_Date,
					"last_login"     : moment ( lastLogin, 'YYYY-MM-DDTHH:mm:ss.SSSZ').subtract(3, 'hours').format('DD MMM, YYYY hh:mm a'),
					//"otp"            : data.OTP,
					//"otpCreated"     : data.OTPTime,
					"trials"         : data.Trials,
					"securityAnswers": data.Security_Question_Answers,
					"answersReset"   : data.Reset_Questions	
				},
				txnThreshold: {
					'KES': '1000000',
					'USD': '10000',
					'EUR': '8400',
					'GBP': '7400'
				},
				activeWalletAccount : walletAcc && walletAcc.length > 0 ? true : false,
				walletAccount : walletAcc.map(entry => {
					let mappedEntry    = {
					  "currency"               : entry.Account.Currency,
					  "accountNumber"          : entry.Account.AccountNo,
					  "accountType"            : "Wallet",
					  "perTransactionLimit"    : entry.Account.PerTransaction_Limit,	
					  "dailyTransactionLimit"  : entry.Account.Daily_txn_limit,	
					  "accountCategory"        : entry.Account.account_category,
					  "customerId"             : entry.Account.Customer_ID,
					  "accountName"            : entry.Account.Account_Name,	
					  "isViewOnly"             : true,
					  "canTransact"            : false
					}
					return mappedEntry
				}),
				accountInfo       		: linkedAcc.map ( entry => {
			
					let accountTypeMap = {
						"I": "Individual",
						"C": "Corporate"
					}
					let mappedEntry    = {
						"currency"               : entry.Account.Currency,
						"accountNumber"          : entry.Account.AccountNo,
						"accountType"            : accountTypeMap [ entry.Account.AccountType ],
						"perTransactionLimit"    : entry.Account.PerTransaction_Limit,	
						"dailyTransactionLimit"  : entry.Account.Daily_txn_limit,	
						"accountCategory"        : entry.Account.account_category,
						"customerId"             : entry.Account.Customer_ID,
						"accountName"            : entry.Account.Account_Name,	
						"isViewOnly"             : entry.Account.View_Only_Rights,
						"canTransact"            : entry.Account.account_status === 1 ? true : false
					}
			
					if ( entry.Account.details ) {
						mappedEntry.details = entry.Account.details
					}
			
					return mappedEntry
				}),
				permissionsinfo   		: {
					"isMpesaAgent"             : false,
					"isActive"                 : true,
					"isSofttokenFirstLogin"    : data.SoftToken_FirstLogin,
					"isFirstLogin"             : data.First_Login,
					"isDormant"                : data.Dormant === "N" ? false : true		
				},
				isFirstSoftTokenLogin	: data.SoftToken_FirstLogin,
			}
			
			return formatted
		}
	}
}