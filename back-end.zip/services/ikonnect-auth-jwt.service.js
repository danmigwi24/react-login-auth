"use strict"

const path        = require ( 'path' )
const cookie     = require ( "cookie" )
const authHelpers = require( path.resolve (`./lib/auth` ) )
const env         = require ( 'dotenv').config() 
const axios = require ( 'axios' )
const moment      = require ( 'moment' )
if ( env.error) { throw env.error}
let googleReptcha = process.env.googleReptchaAuth
let googleSecret = process.env.reptchaSecretKey

module.exports = {
	name		: "auth-jwt",
	settings	: {
		log: true
	},
	dependencies: [],
	actions		: {
		token: {
			rest  : "/soft-token",
			params: {
				username : "string",
				password : "string",
			},
			async handler( ctx, route, req, res ) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};
				
				// Query Params
				let username = ctx.params.username
				let password = ctx.params.password

				// For the given username fetch user from DB (here we mock from env )
				if ( username && password ) {

					let fetchProfile = await ctx.call('soft-token.profile', {email: username});
					if (fetchProfile.success){
						//Verify password
						
						if(! await authHelpers.verifyPassword ( password, fetchProfile.data.pin)){

							ctx.meta.$statusCode = 403
							logData.responseData = 'Incorrect username or password'
							this.settings.log        && ctx.emit ( 'create.log', logData);
							return {
								success : false,
								data: {
									message : 'Incorrect username or password'
								}
							}
						}else{
							let token = authHelpers.signToken ({ username })			
			
							// return the JWT token as a HTTPOnly Cookie and aslo in the JSON response for future API calls
							// ctx.meta.$statusCode       = 200
							// ctx.meta.$responseHeaders  = { 
							// 	'access-control-expose-headers': 'Set-Cookie',
							// 	'Set-Cookie': `jwt-token=${token}; HttpOnly`
							// }				
							
							logData.responseData = 'Authentication successful!'
							this.settings.log        && ctx.emit ( 'create.log', logData);

							return {
								success : true,
								data:{
									message : 'Authentication successful!',
									token
								}
							}
						}
					}			
				}			
				else {
					logData.responseData = 'Authentication failed due to missing parameters'
					this.settings.log        && ctx.emit ( 'create.log', logData);
					return {
						success: false,
						data: {
							message:'Authentication failed due to missing parameters',
							params : {
								username: !!username,
								password: !!password
							}
						}						
					}
				}
			}
		},
		ibToken: {
			rest  : "/get-token",
			params: {
				payload: "string",
				$$strict: true
			},
			async handler (ctx) {
				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					dbParams: '',
					resposeCode: '',
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				const https = require ('https')
				let httpsAgent  = new https.Agent({ rejectUnauthorized: false })
					
				let instance = axios.create ({ httpsAgent })

				let res = {}
				logData['sent']    = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')

				try {
					res = await instance.post (
						`${googleReptcha}`,
						{ googleSecret, recaptchaToken: decrypted.recaptchaToken }
					)
				} catch (error) {
					res = error.res
				}
				logData['received'] = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')
					let sent            = moment ( logData.sent,'YYYY-MM-DD HH:mm:ss:SSSS'  ),
					    received        = moment ( logData.received,'YYYY-MM-DD HH:mm:ss:SSSS' )
					logData.latency     = `${received.diff(sent, 'milliseconds')} ms`

				if(!res && !res.data && !res.data.success){
					let encryptedPayload = await ctx.call('core-security.ibEncrypt', { 
						payload: JSON.stringify({ 
							success: false,
							message: `Please you are not fooling us bot :(`,
							registered: false
						 }) });

					logData.type = 'error-bot'
					logData.responseData = `Login failed. Reason - Bot activity detected`
					logData.googleAuthResponse = res.data
					ctx.emit ( 'create.log', logData)

					return encryptedPayload

				}
				logData.googleAuthResponse = res.data

				//console.log({payload})
				let ibLogin = await ctx.call('auth-login.login', { payload });
				
				//console.log(ibLogin)
				if(ibLogin.success){
					
					let token = authHelpers.signToken ({ username: decrypted.username })			
					
					// return the JWT token as a HTTPOnly Cookie and aslo in the JSON response for future API calls
					// ctx.meta.$statusCode       = 200
					// ctx.meta.$requestHeaders  = {
					// 	'access-control-expose-headers': 'set-cookie',
					// 	'set-cookie': cookie.serialize('jwt_token', String(token), {
					// 		httpOnly: true,
					// 		path: '/',
					// 		secure: false,
					// 		maxAge: 60 * 60 // 24 hours
					// 	  })
					// }	
					//console.log(ctx.meta.$responseHeaders)
					//ibLogin = { ...ibLogin, token}
					let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify({ ...ibLogin, requestId: decrypted.requestId, token}) });
					ibLogin = encryptedPayload

					logData.responseData = `Login successful. Token generation successful`
					ctx.emit ( 'create.log', logData)

					return ibLogin
				}else{
					let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify({ ...ibLogin, requestId: decrypted.requestId}) });
					ibLogin = encryptedPayload

					logData.type = 'debug'
					logData.responseData = `Login failed. ${ibLogin}`
					ctx.emit ( 'create.log', logData)

					return ibLogin
				}
			}
		},
		iKonnectToken: {
			rest: "konnect-token",
			params: {
				username: "string",
				$$strict: true
			},

			async handler (ctx) {
				let internalUser = ["BACK_OFFICE", "ESB_MASTER"];

				let { params } = ctx
				if(internalUser.includes(params.username)){
					let token = authHelpers.signToken ({ username: params.username });
					return token
				}else{
					return ''
				}
			}
		},
		verify: {
			rest: "/verify-token",
			params: {
				token : "string"
			},
			async handler ( ctx ) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: 'token',
					requestParams: '',
					resposeCode: '',
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let user = authHelpers.verifyToken ( ctx.params.token )

				logData.responseData = user
				logData.type = user ? 'info': 'debug'
				ctx.emit ( 'create.log', logData)

				//verify if user is correct in DB
				return user
				
			}
		}
	},
	events		: {},
	methods		: {},
	created		() {},
	started		() {},
	stopped		() {}
}