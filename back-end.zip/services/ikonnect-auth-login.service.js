"use strict"
const path                                                = require ( 'path' )
const { hashPassword, verifyPassword, encrypt, decrypt, signToken  } = require (  path.resolve ( `./lib/auth` ) )
const Whitelist 										  = require('../lib/whitelist')
const moment 											  = require ( 'moment' )
// Environment Config
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw env.error };

let sessionExpiryTime = process.env.SESSION_EXPIRY_MINUTES

module.exports = {
	name   : "auth-login",
	settings	: {
		log: true
	},
	actions: {		
		firstlogin: {
			rest                 : "/first-login",
			params               : {
				username         : "string",
				password         : "string",
				securityAnswers  : "object"
			},
			async handler(ctx) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

					// hash password
					let passwordHash = await hashPassword ( ctx.params.password )

					// update tb_Customer_Validation
					let { resultStatus, result } = await ctx.call ( 'core-database.query', {
						'request-name':'first.login',
						payload       : {
							hash           : passwordHash,
							securityanswers: encrypt ( JSON.stringify ( ctx.params.securityAnswers ) ),
							username       : ctx.params.username
						}
					})

					// UPDATE Successful
					if ( resultStatus ) {
						logData.responseData = `Account activation for ${ctx.params.username} was succesful`
						this.settings.log        && ctx.emit ( 'create.log', logData);
						return {
							success:true,
							message:`Account activation for ${ctx.params.username} was succesful`
						}
					}

					// UPDATE Failed
					else {

						ctx.call ( 'core-database.query', {
							'request-name':'update.failed.login',
							payload       : {
								username     : ctx.params.username,
								failurereason: `Account activation for ${ctx.params.username} failed`,
								ip           : ctx.meta.clientIp,
								code		 : "99"
							}
						})
						logData.type = 'debug'
						logData.responseData = `Account activation for ${ctx.params.username} failed`
						this.settings.log        && ctx.emit ( 'create.log', logData);
						return {
							success: false,
							message:`Account activation for ${ctx.params.username} failed`
						}
					}

			}
		},
		login: {
			rest  : "/login",
			params: {
				payload: "string",
				$$strict: true // No additional properties allowed
			},
			async handler(ctx) {
				

				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: '',
					user: decrypted.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//WHITELIST

				// if(!Whitelist.includes(decrypted.username)){

				// 	logData.responseData = 'Unauthorized Access. Customer not whitelisted'
				// 	logData.type = 'warn'
				// 	ctx.emit ( 'create.log', logData);
				// 	return {
				// 		success: false,
				// 		message: `Account ${decrypted.username} is not whitelisted.`,
				// 		registered: false
				// 	}
				// }

				//verify that the user exists 
				let { resultStatus, result } = await ctx.call ( 'core-database.query', {
					'request-name':'user.exists',
					payload       : { ...decrypted }
				})
				
				// user exists
				if ( resultStatus && result[0] && result[0].length > 0 ) {

					let  { password } = decrypted
					let { Password_Hash, Account_Status }  = result[0][0]

					//verify that the account is not blocked
					let AccountStatus = 'Blocked'
					let query = await ctx.call ( 'core-database.query', {
						'request-name':'get.account.status',
						payload       : { ...decrypted }
					})

					if ( query.resultStatus && query.result[0] && query.result[0].length > 0 ) {
						AccountStatus = query.result[0][0].Description
					}

					// Account is Active
					if ( AccountStatus === 'Active' ) {

						//verify that the password is correct						
						let isCorrectPassword = Password_Hash && await verifyPassword ( password, Password_Hash )

						// Password is Correct
						if ( isCorrectPassword ) {

							//create session ID and save to DB
							let dateGenerated = `${moment().add(60, 'm').format()}`;
							
							
							let userEmail      = decrypted.username
							let sessionId      = await ctx.call (  'core-security.fastEncrypt', {
								payload       : JSON.stringify ({
									userEmail,
									dateGenerated
								})
							})

							let userResetQuestion = await ctx.call('auth-login.getAnswers', {
								'username': decrypted.username
							})

							// if(!userResetQuestion.success){
							// 	logData.type = 'debug'
							// 	logData.responseData = userResetQuestion.error
							// 	this.settings.log        && ctx.emit ( 'create.log', logData);
							// 	return {
							// 		success: false,
							// 		message: userResetQuestion.error,
							// 		registered: false,
							//		resetQuestions: true
							// 	}
							// }

							if(userResetQuestion.data && userResetQuestion.data.answerReset){
								logData.type = 'debug'
								logData.responseData =`Security Questions have not been set for Account ${decrypted.username}`
								this.settings.log        && ctx.emit ( 'create.log', logData);
								return {
									success: false,
									message:`Security Questions have not been set. Reset password to set your security questions`,
									registered: false,
									resetQuestions: true
								}
							}

							await ctx.call('core-database.query', {
								'request-name': 'update-sesion-id',
								payload: {
									email		: decrypted.username,
									sessionId	: sessionId.encoded
								}
							})
							
							ctx.call ( 'core-database.query', {
								'request-name':'reset.trials',
								payload       : { username: decrypted.username }
							})

							ctx.call ( 'core-database.query', {
								'request-name':'update.successful.login',
								payload       : { 
									currentdate : moment().format ( 'YYYY-MM-DD HH:mm:ss' ),
									username    : decrypted.username
								}
							})

							ctx.call ( 'core-database.query', {
								'request-name':'update.failed.login',
								payload       : {
									username     : decrypted.username,
									failurereason: `Successful`,
									ip           : ctx.meta.clientIp,
									code: "00"
								}
							})

							logData.responseData = `succesful`
							this.settings.log        && ctx.emit ( 'create.log', logData);
							return {
								success:isCorrectPassword
							}
						}

						//increment PIN trials and block if a max of 3 is reached
						else {
							let pinTrialsQuery = await ctx.call (  'core-database.query', {
								'request-name':'update.trials',
								payload       : { username: decrypted.username }
							})

							await ctx.call ( 'core-database.query', {
								'request-name':'update.failed.login',
								payload       : {
									username     : decrypted.username,
									failurereason: `Wrong Password provided for Account ${decrypted.username}`,
									ip           : ctx.meta.clientIp,
									code: "99"
								}
							})

							if ( pinTrialsQuery.resultStatus && pinTrialsQuery.result[0] && pinTrialsQuery.result[0].length > 0 ) {
								let { status, trialsRemaining, message } = pinTrialsQuery.result[0][0]
								
								if ( trialsRemaining === 0 ) {
									logData.type = 'debug'
									logData.responseData =`Account ${decrypted.username} is Blocked`
									this.settings.log        && ctx.emit ( 'create.log', logData);
									return {
										success: false,
										message: `Account ${decrypted.username} is Blocked`,
										registered: false
									}
								}
								logData.type = 'debug'
								logData.responseData =`Wrong Password provided for Account ${decrypted.username}`
								this.settings.log        && ctx.emit ( 'create.log', logData);
								return {
									success: false,
									message:`Wrong username or password provided`,
									trialsRemaining,
									registered: true
								}
							}
						}
					}

					// account is not active					
					else {
						
						await ctx.call ( 'core-database.query', {
							'request-name':'update.failed.login',
							payload       : {
								username     : decrypted.username,
								failurereason: `Account ${decrypted.username} is ${AccountStatus}`,
								ip           : ctx.meta.clientIp,
								code: "99"
							}
						})
						logData.type = 'debug'
						logData.responseData = `Account ${decrypted.username} is ${AccountStatus}`
						this.settings.log        && ctx.emit ( 'create.log', logData);
						return {
							success: false,
							message: `Account ${decrypted.username} is ${AccountStatus}`,
							registered: false
						}
					}					
				}

				//user doesnt exist
				else {
					await ctx.call ( 'core-database.query', {
						'request-name':'update.failed.login',
						payload       : {
							username     : decrypted.username,
							failurereason: `user ${ decrypted.username} is not registered for iKonnect`,
							ip           : ctx.meta.clientIp,
							code: "99"
						}
					})
					logData.type = 'debug'
					logData.responseData = `user ${ decrypted.username} is not registered for iKonnect`
					this.settings.log        && ctx.emit ( 'create.log', logData);

					return {
						success:false,
						message:`Wrong username or password provided`,
						registered: false
					}
				}

			}
		},
		//create session id for authenticating user
		generateSessionId: {
			rest: "/user-session",
			params: {
				payload: "string"
			},
			async handler (ctx) {
				//create session ID and save to DB
				let dateGenerated = `${moment().add(40, 'm').format()}`;
				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)
				let userEmail      = decrypted.username

				if(userEmail){
					let token = signToken({username: decrypted.username})
							
					let sessionId      = await ctx.call (  'core-security.fastEncrypt', {
						payload       : JSON.stringify ({
							userEmail,
							dateGenerated
						})
					})
	
					await ctx.call('core-database.query', {
						'request-name': 'update-sesion-id',
						payload: {
							email		: decrypted.username,
							sessionId	: sessionId.encoded
						}
					})
	
					return await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify({ success: true, token }) });
				}else{
					return {}
				}
			}
		},
		// let isCorrectPassword = Password_Hash && await verifyPassword ( password, Password_Hash )
		passwordCanBeUsed: {
			rest  : "/password-can-be-used",
			params: {
				passwordHashes: "string",
				password      : "string",
				username      : "string"
			},
			async handler(ctx) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				try {

					let passwordHashes = JSON.parse ( ctx.params.passwordHashes )
					let canUsePassword = true

					for ( let oldPassword of passwordHashes ) {

						let passwordWasUsed = await verifyPassword ( ctx.params.password, oldPassword )

						if ( passwordWasUsed ) {
							canUsePassword = false
							break
						}
						else {
							canUsePassword = true
						}
					}

					//update password hash
					if ( canUsePassword ) {
						let passwordHash = await hashPassword ( ctx.params.password )
						passwordHashes.push ( passwordHash )

						let fetchPolicy = await ctx.call('core-database.query', {
							'request-name': "password-policy",
							payload: {}
						});
						let reuseCount = 3

						if(fetchPolicy.resultStatus && fetchPolicy.result && fetchPolicy.result[0].length > 0){
		
							let policies = fetchPolicy.result[0]
							policies.map(policy => {
								if(policy.Parameter === 'reuseCount'){
									reuseCount = parseInt(policy.Param_Value, 10)
								}
							})
						}

						if ( passwordHashes.length > reuseCount ) {
							passwordHashes.shift()
						}

						let { resultStatus } = await ctx.call ( 'core-database.query', {
							'request-name':'update.password.history',
							payload       : {
								passwordHashes    : JSON.stringify ( passwordHashes ),
								password          : passwordHash,
								username          : ctx.params.username,
								lastpasswordchange: moment().format ( 'YYYY-MM-DD HH:mm:ss' )
							}
						})
						


					}
					logData.responseData = canUsePassword ? 'Password can be used' : 'Password has already been used'
					this.settings.log        && ctx.emit ( 'create.log', logData);

					return {
						success: canUsePassword,
						message: canUsePassword ? 'Password can be used' : 'Password has already been used'
					}
				}
				catch ( e ) {
					logData.type = 'debug'
					logData.responseData = "Password hashes set to blank"
					this.settings.log        && ctx.emit ( 'create.log', logData);
					return {
						success :true,
						message : "Password hashes set to blank"
					}
				}

			}
		},
		//Verify SessionId
		verifySessionId: {
			rest 	: "/verify-user-session",
			params 	: {
				payload 	: "string",
				$$strict    : true
			},
			async handler(ctx) {
				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)
				let logData = {
					type: 'info',
					action: 'verify-user-session',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				if(!decrypted.sessionid){
					//destroy session id
					await ctx.call('core-database.query', {
						'request-name': 'update-sesion-id',
						payload: {
							email		: decrypted.username,
							sessionId	: ''
						}
					})
					logData.responseData = 'destroyed session id'
					ctx.emit ('create.log', logData)

					return { success: false }
				}

				//Fetch, Decrypt and Verify - 15 minutes App timeout
				let fetchSessionId = await ctx.call('core-database.query', {
					'request-name': "fetch-user-session-token",
					payload: {
						username: decrypted.username
					}
				});

				if(fetchSessionId.resultStatus && fetchSessionId.result && fetchSessionId.result[0] && fetchSessionId.result[0][0] && fetchSessionId.result[0][0].Profile_Session_Id){
					let data = fetchSessionId.result[0][0];
					let encrytedSessionId = data.Profile_Session_Id;
					if(encrytedSessionId.length < 1){
						return { success: false }
					}
					let decrytedSessionId = await ctx.call('core-security.fastDecrypt', {
						payload: decrypted.sessionid
					});
					
					try {
						decrytedSessionId.decrypted = JSON.parse(decrytedSessionId.decrypted)
					} catch (error) {
						
					}
					if(decrytedSessionId.decrypted && decrytedSessionId.decrypted.dateGenerated){

						let dateGenerated = decrytedSessionId.decrypted.dateGenerated
						
						//verify session id
						if(encrytedSessionId === decrypted.sessionid && moment().isBefore(dateGenerated)){
							return { success: true }
						}else{
							return { success: false }
						}
					}else{
						
						return { success: false }
					}
					

				}else{
					return { success: false}
				}
			}
		},

		//password policy
		passwordPolicy: {
			rest 	: "/password-policy",
			async handler (ctx) {

				let fetchPolicy = await ctx.call('core-database.query', {
					'request-name': "password-policy",
					payload: {}
				});
				let passwordBlacklist = await ctx.call('core-database.query', {
					'request-name': "password-blacklist",
					payload: {}
				});

				let passPolicy = {
					weakPasswords: []
				}
				if(fetchPolicy.resultStatus && fetchPolicy.result && fetchPolicy.result[0].length > 0){

					let policies = fetchPolicy.result[0]
					policies.map(policy => {
						passPolicy[policy.Parameter] = policy.Param_Value
					})
				}

				if(passwordBlacklist.resultStatus && passwordBlacklist.result && passwordBlacklist.result[0].length > 0){

					let blackList = passwordBlacklist.result[0]
					blackList.map(policy => {
						passPolicy.weakPasswords.push(policy.Password)
					})
				}


				return passPolicy
			}
		},

		// Security Questions		
		questionReset: {
			rest                 : "/question-reset",
			params               : {
				username         : "string",
				securityAnswers  : "object"
			},
			async handler(ctx) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

					// update tb_Customer_Validation
					let { resultStatus } = await ctx.call ( 'core-database.query', {
						'request-name':'questions.reset',
						payload       : {
							securityanswers: encrypt ( JSON.stringify ( ctx.params.securityAnswers ) ),
							username       : ctx.params.username
						}
					})

					// UPDATE Successful
					if ( resultStatus ) {
						logData.responseData = `Question Reset for ${ctx.params.username} was succesful`
						this.settings.log        && ctx.emit ( 'create.log', logData);
						return {
							success:true,
							message:`Question Reset for ${ctx.params.username} was succesful`
						}
					}

					// UPDATE Failed
					else {
						logData.type = 'debug'
						logData.responseData = `Question Reset for ${ctx.params.username} failed`
						this.settings.log        && ctx.emit ( 'create.log', logData);
						return {
							success:false,
							message:`Question Reset for ${ctx.params.username} failed`
						}
					}

			}
		},
		blockQuestions: {
			rest                 : "/block-questions",
			params               : {
				username         : "string"
			},
			async handler(ctx) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

					// update tb_Customer_Validation
					let { resultStatus } = await ctx.call ( 'core-database.query', {
						'request-name':'block.questions',
						payload       : {
							username : ctx.params.username,
							blockedby: ctx.params.username,
							blockedon: moment().format ( 'YYYY-MM-DD HH:mm:ss' )
						}
					})

					// UPDATE Successful
					if ( resultStatus ) {
						logData.responseData = `Questions Block for ${ctx.params.username} was succesful`
						this.settings.log        && ctx.emit ( 'create.log', logData);
						return {
							success:true,
							message:`Questions Block for ${ctx.params.username} was succesful`
						}
					}

					// UPDATE Failed
					else {
						logData.type = 'debug'
						logData.responseData = `Questions Block for ${ctx.params.username} failed`
						this.settings.log        && ctx.emit ( 'create.log', logData);
						return {
							success:false,
							message:`Questions Block for ${ctx.params.username} failed`
						}
					}

			}
		},
		getQuestions: {
			rest: "/get-questions",
			async handler(ctx) {
				let response = {}
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//get security questions from database
				let { resultStatus, result } = await ctx.call ( 'core-database.query', {
					'request-name':'security.questions',
					payload       : ctx.params
				})

				if ( resultStatus ) {

					let arrResp =  result instanceof Array && result[0] instanceof Array
					
					if ( arrResp ){
						
						let data    = result[0]

						logData.responseData = 'successful'
						this.settings.log        && ctx.emit ( 'create.log', logData);

						response = {
							success: true,
							data								
						}
					}
				}
				else {
					logData.type = 'debug'
					logData.responseData = result
					this.settings.log        && ctx.emit ( 'create.log', logData);
					response =  {
						success: false,
						error  : 'failed'
					}
				}

				return response
			}			
		},
		getAnswers: {
			rest  : "/get-answers",
			params: {
				username : "string",
			},
			async handler(ctx) {
				//try get them from tb_Customer_Validation
				let response = {}
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//get security questions from database
				let { resultStatus, result } = await ctx.call ( 'core-database.query', {
					'request-name':'security.answers',
					payload       : { ...ctx.params }
				})

				if ( resultStatus ) {

					let arrResp =  result instanceof Array && result[0] instanceof Array && result[0].length > 0
					
					if ( arrResp ){
						
						let data    = result[0][0]
						let answers = data.Security_Question_Answers

						if (  answers) {
							let questions = await ctx.call ( 'auth-login.getQuestions')
							response = {
								success: true,
								data: {
									answers         : JSON.parse ( decrypt ( answers ) ),
									questions       : questions.data,
									answerReset     : data.Reset_Questions,
									questionsBlocked: data.Questions_Blocked,
									passwordHistory : data.Password_History
								}						
							}

							logData.responseData = 'successful'
							this.settings.log        && ctx.emit ( 'create.log', logData);
						}
						else {
							if (  data.Reset_Questions ){
								response = {
									success         : true,
									data            : {
										answers         : false,
										answerReset     : data.Reset_Questions,
										questionsBlocked: data.Questions_Blocked,
										passwordHistory : data.Password_History	
									}							
								}
							}
							else {
								response = {
									success: false,
									error: `Couldnt get Security Question Settings for ${ctx.params.username}`								
								}
								logData.type = 'debug'
								logData.responseData = response
								this.settings.log        && ctx.emit ( 'create.log', logData);
							}
						}

						
					}
					else {
						response =  {
							success: false,
							error  : result
						}

						logData.type = 'debug'
						logData.responseData = response.success
						this.settings.log        && ctx.emit ( 'create.log', logData);
					}
				}
				else {
					response =  {
						success: false,
						error  : result
					}

					logData.type = 'debug'
					logData.responseData = response
					this.settings.log        && ctx.emit ( 'create.log', logData);

				}

				return response				
			}
		},
		setAnswers: {
			rest  : "/set-answers",
			params: {
				username         : "string",				
				securityAnswers  : "object",
			},
			async handler(ctx) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				// update tb_Customer_Validation
				let { resultStatus, result } = await ctx.call ( 'core-database.query', {
					'request-name':'set.answers',
					payload       : {
						securityanswers: encrypt ( JSON.stringify ( ctx.params.securityAnswers ) ),
						username       : ctx.params.username
					}
				})

				// UPDATE Successful
				if ( resultStatus ) {
					logData.responseData = `Updated answers for ${ctx.params.username} `
					this.settings.log        && ctx.emit ( 'create.log', logData);

					return {
						success:true,
						message:`Updated answers for ${ctx.params.username} `
					}
				}

				// UPDATE Failed
				else {
					logData.type = 'debug'
					logData.responseData = `Answer update failed for ${ctx.params.username}`
					this.settings.log        && ctx.emit ( 'create.log', logData);
					return {
						success:flase,
						message:`Answer update failed for ${ctx.params.username}`
					}
				}
			}
		},
		verifyAnswer: {
			rest  : "/verify-answer",
			params: {
				username         : "string",
				securityAnswers  : "object"
			},
			async handler(ctx) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let savedAnswers = await ctx.call ( 'auth-login.getAnswers', { ...ctx.params } )
				let answers      = ctx.params.securityAnswers
				let questionID   = Object.keys ( answers )[0]
				let answer       = answers [ questionID ]
				let savedAnswer  = savedAnswers.success ? savedAnswers.data [ questionID ].toLowerCase() : false
				
				if ( savedAnswer.includes ( answer ) ) {
					
					logData.responseData = `Correct answer`
					this.settings.log        && ctx.emit ( 'create.log', logData);

					return {
						success:true,
						data: {
							questionID,
							answer
						}
					}
				}
				else {
					logData.type = 'debug'
					logData.responseData = `Incorrect answer for ${questionID}`
					this.settings.log        && ctx.emit ( 'create.log', logData);

					return {
						success:false,
						message:`Incorrect answer for ${questionID}`,
						data: {
							questionID,
							answer
						}
					}
				}
				
			}
		},

		//  Password Reset
		changePasswordVerifyAccount :  {
			rest  : "/change-password-verify-account",
			params: {
				username         : "string",
				securityAnswers  : "object"
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//verify that the user exists and that the security answer given is correct
				let { resultStatus, result } = await ctx.call ( 'core-database.query', {
					'request-name':'user.exists',
					payload       : { ...ctx.params }
				})
				
				// user exists
				if ( resultStatus && result[0] && result[0].length > 0 ) {
					//if correct send sms ( generate otp )
						
						logData.responseData = 'Successful'
						this.settings.log        && ctx.emit ( 'create.log', logData);
						
					return await ctx.call ( 'auth-login.verifyAnswer', { ...ctx.params } )
				}
				else {
					logData.type = 'debug'
					logData.responseData = `user ${ ctx.params.username} is not registered for iKonnect`
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return {
						success:false,
						error:`user ${ ctx.params.username} is not registered for iKonnect`
					}
				}
			}
		},
		changePassword: {
			rest  : "/change-password",
			params: {
				username         : "string",
				password         : "string",
				otp              : "string"
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//verify that the user exists 
				let { resultStatus, result } = await ctx.call ( 'core-database.query', {
					'request-name':'user.exists',
					payload       : { ...ctx.params }
				})
				
				// user exists
				if ( resultStatus && result[0] && result[0].length > 0 ) {


					let resetMessage = `Dear ${result[0][0].Customer_Name},  password Reset attempt has been made for ${ctx.params.username} on the iKonnect platform at ${moment().format('DD-MMM-YYYY HH:mm:ss a')}. If this wasn't you, kindly contact customer care and change your password immediately.`

					resetMessage = await ctx.call ( "core-security.encryptMessage", {
						payload: resetMessage
					})
					ctx.call ( 'core-sms.cbkonnectSend', {
						phonenumber: result[0][0].Phone_Number,
						username: ctx.params.username,
						message    : resetMessage
					})


					// verify that the otp is correct
					let verifyOtp = await ctx.call ( 'auth-otp.validate', { ...ctx.params } )

					// if otp is correct update password
					if ( verifyOtp.success ) {
						let { resultStatus } = await ctx.call ( 'core-database.query', {
							'request-name':'password.reset',
							payload       : { username: ctx.params.username, hash : await hashPassword ( ctx.params.password)  }
						})
		
						if ( resultStatus ) {
							
							logData.responseData = `Password Reset for ${ctx.params.username} was succesful`
							this.settings.log        && ctx.emit ( 'create.log', logData);
							
							return {
								success: true,
								message : `Password Reset for ${ctx.params.username} was succesful`
							}							
						}
						else{
							logData.type = 'debug'
							logData.responseData = `Password Reset for ${ctx.params.username} failed`
							this.settings.log        && ctx.emit ( 'create.log', logData);
							
							return {
								success: false,
								error: `Password Reset for ${ctx.params.username} failed`
							}
						}
					}

					// if not correct return error
					else {
						logData.type = 'debug'
						logData.responseData = `Invalid OTP for ${ctx.params.username}`
						this.settings.log        && ctx.emit ( 'create.log', logData);
						
						return {
							success: false,
							error: `Invalid OTP for ${ctx.params.username}`
						}
					} 
				}
				else {
					logData.type = 'debug'
					logData.responseData = `user ${ ctx.params.username} is not registered for iKonnect`
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return {
						success:false,
						error:`user ${ ctx.params.username} is not registered for iKonnect`
					}
				}				
			}
		}
	}
}