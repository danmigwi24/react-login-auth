"use strict"

// Variables
const path                                          = require ( 'path' )
const { hashPassword, verifyPassword, generateOtp } = require (  path.resolve ( `./lib/auth` ) )
const moment 										= require ( 'moment')
// Environment Config
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw env.error };

let otpExpiryTime = process.env.OTP_EXPIRY_MINUTES


module.exports = {
	name	: "auth-otp",
	settings	: {
		log: true
	},
	actions	: {
		generate  : {
			rest  : "/generate",
			params: {
				username : "string"
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};
				let username = 'not provided'

				let verfiedUser = await ctx.call ( 'auth-jwt.verify',{ token: ctx.meta.token } )
				logData.userVerify = verfiedUser

				let sessionEmail = ctx.params.username

				if(verfiedUser && verfiedUser.data && sessionEmail.toLowerCase() === verfiedUser.data.username.toLowerCase() ){
					username = verfiedUser.data.username
				

					//get the user with the given username in tb_Customer_validation
					let { resultStatus, result } = await ctx.call ( 'core-database.query', {
						'request-name':'user.exists',
						payload       : { username }
					})

					let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify({username, sessionid: result[0][0].Profile_Session_Id }) });

					let userLoggedIn = await ctx.call ( 'auth-login.verifySessionId', { payload: encryptedPayload } )

					// user exists
					if ( resultStatus && result[0] && result[0].length > 0 && userLoggedIn.success) {

						// generate an otp
						const otp     = generateOtp()
						const hashed  = await hashPassword ( otp )
						let updateOtp = await ctx.call ( 'core-database.query',{
							'request-name':'update.otp',
							payload       : {
								username,
								otp: hashed,
								otptime: moment().format ( 'YYYY-MM-DD HH:mm:ss')
							}
						})

						// return the OTP code via SMS
						if ( updateOtp.resultStatus ) {
							let getProfile = await ctx.call ( 'users-profile.fetch', {
								username
							})
						
							// send SMS
							let fname = "Customer"

							if ( getProfile.success ){ fname = getProfile.data.First_Name }

							let otpMessage = `Dear ${fname}, Your iKonnect Internet banking One Time PIN is ${otp}. If not requested, kindly contact 0709072000`

							//Dear CELINE, Your iKonnect Internet banking One Time PIN is 384959. If not requested, kindly contact 0709072000
							console.log(otpMessage)
							otpMessage = await ctx.call ( "core-security.encryptMessage", {
								payload: otpMessage
							})

							ctx.call ( "core-sms.cbkonnectSend", {
								phonenumber:result[0][0].Phone_Number,
								username   ,
								message    : otpMessage
							})
							
							logData.responseData = `Successfully generated OTP`
							this.settings.log        && ctx.emit ( 'create.log', logData);
						
							return { success:true }
						}
						else {
							logData.type = 'debug'
							logData.responseData = result
							this.settings.log        && ctx.emit ( 'create.log', logData);
							
							return { success: false, error  : 'failed' }
						}	
					}
					// user doesnt exist
					else {
						logData.type = userLoggedIn.success ? 'debug' : 'error'
						logData.responseData = userLoggedIn.success ? `user ${ username} is not registered on ikonnect` : 'Unauthenticated. User not logged in'
						this.settings.log        && ctx.emit ( 'create.log', logData);
						
						return {
							success: false,
							error: `user ${ username} is not registered on ikonnect`
						}
					}	
				}else{
					logData.responseData = "Unauthorized access"
					ctx.emit('create.log', logData)
					return { success: false, error  : 'failed' }
				}
			}
		},
		validate: {
			rest            : "/validate",
			params          : {
				username    : "string",
				otp         : { type : "string", length: 6 }
			},
			async handler(ctx) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let username = 'not provided'

				let verfiedUser = await ctx.call ( 'auth-jwt.verify',{ token: ctx.meta.token } )
				logData.userVerify = verfiedUser
				
				let sessionEmail = ctx.params.username

				if(verfiedUser && verfiedUser.data && verfiedUser.data.username.toLowerCase() && sessionEmail === verfiedUser.data.username.toLowerCase() ){
					username = verfiedUser.data.username

					//get the user with the given username in tb_Customer_validation
					let { resultStatus, result } = await ctx.call ( 'core-database.query', {
						'request-name':'get.otp',
						payload       : { username }
					})

					let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify({ username, sessionid: result[0][0].Profile_Session_Id}) });

					let userLoggedIn = await ctx.call ( 'auth-login.verifySessionId', { payload: encryptedPayload } )

					// user exists
					if ( resultStatus && result.length > 0 && userLoggedIn.success) {

						let resultExists = result instanceof Array && result[0] instanceof Array && result[0].length > 0

						// user data is valid - get the saved otp					
						if ( resultExists ){

							let savedOtp    = result[0][0].OTP
							let otpUsed 	= result[0][0].OTP_Used
							let otp         = ctx.params.otp

							//get the time difference
							let otpTime      =  result[0][0].OTPTime  //2020-09-23T12:10:22.000Z
							let savedTime    = moment ( otpTime, 'YYYY-MM-DD HH:mm:ss' ) // our server adds 3 hours when fetching data due to GMT + 3.00
							
							let isCorrectOtp = await verifyPassword ( otp, savedOtp )

							if ( moment().isBefore(savedTime) && !otpUsed) {
								logData.type = isCorrectOtp ? 'info' : 'debug'
								logData.responseData = isCorrectOtp ? `OTP is valid` : `OTP is invalid`
								this.settings.log        && ctx.emit ( 'create.log', logData);

								isCorrectOtp && ctx.call ( 'core-database.query',{
									'request-name':'expire.otp',
									payload       : {
										username
									}
								})
								
								return {
									success: isCorrectOtp,
									otp,
									message: isCorrectOtp ? `OTP is valid` : `OTP is invalid`
								}
							}
							else {
								logData.type = 'debug'
								logData.responseData = otpUsed ? 'OTP has been used' : 'OTP has expired'
								this.settings.log        && ctx.emit ( 'create.log', logData);
								
								return {
									success: false,
									otp,
									message: 'OTP has expired'
								}
							}
						}
						// user data is invalid
						else {
							logData.type = 'debug'
							logData.responseData = `Cannot get data for ${username} on ikonnect`
							this.settings.log        && ctx.emit ( 'create.log', logData);
							
							return {
								success: false,
								error: `Cannot get data for ${username} on ikonnect`
							}
						}
					}
					// user doesnt exist
					else {
						logData.type = userLoggedIn.success ? 'debug' : 'error'
						logData.responseData = userLoggedIn.success ? `user ${ username} is not registered on ikonnect` : 'Unauthenticated. User not logged in'
						this.settings.log        && ctx.emit ( 'create.log', logData);
						
						return {
							success: false,
							error: `user ${username} is not registered on ikonnect`
						}
					}
				}else{
					ctx.emit('create.log', logData)
				}

			}
		},
		requestOtp  : {
			rest  : "/request-otp",
			params: {
				payload : "string"
			},
			async handler(ctx) {
				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: decrypted.username,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};
				let username = 'not provided'

				let verfiedUser = await ctx.call ( 'auth-jwt.verify',{ token: ctx.meta.token } )
				logData.userVerify = verfiedUser

				let sessionEmail = decrypted.username
				let response = {
					success: false
				}

				if(verfiedUser && verfiedUser.data && sessionEmail === verfiedUser.data.username ){
					username = verfiedUser.data.username
				

					//get the user with the given username in tb_Customer_validation
					let { resultStatus, result } = await ctx.call ( 'core-database.query', {
						'request-name':'user.exists',
						payload       : { username }
					})

					let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify({username, sessionid: decrypted.sessionToken }) });

					let userLoggedIn = await ctx.call ( 'auth-login.verifySessionId', { payload: encryptedPayload } )

					// user exists
					if ( resultStatus && result[0] && result[0].length > 0 && userLoggedIn.success) {

						// generate an otp
						const otp     = generateOtp()
						const hashed  = await hashPassword ( otp )
						let updateOtp = await ctx.call ( 'core-database.query',{
							'request-name':'update.otp',
							payload       : {
								username,
								otp: hashed,
								otptime: moment().format ( 'YYYY-MM-DD HH:mm:ss')
							}
						})

						// return the OTP code via SMS
						if ( updateOtp.resultStatus ) {
							let getProfile = await ctx.call ( 'users-profile.fetch', {
								username
							})
						
							// send SMS
							let fname = "Customer"

							if ( getProfile.success ){ fname = getProfile.data.First_Name }

							let otpMessage = `Dear ${fname}, Your iKonnect Internet banking One Time PIN is ${otp}. If not requested, kindly contact 0709072000`

							//Dear CELINE, Your iKonnect Internet banking One Time PIN is 384959. If not requested, kindly contact 0709072000
							//console.log(otpMessage)
							otpMessage = await ctx.call ( "core-security.encryptMessage", {
								payload: otpMessage
							})

							ctx.call ( "core-sms.cbkonnectSend", {
								phonenumber:result[0][0].Phone_Number,
								username   ,
								message    : otpMessage
							})
							
							logData.responseData = `Successfully generated OTP`
							this.settings.log        && ctx.emit ( 'create.log', logData);
						
							response = { success:true }
						}
						else {
							logData.type = 'debug'
							logData.responseData = result
							this.settings.log        && ctx.emit ( 'create.log', logData);
							
							response = { success: false, error  : 'failed' }
						}	
					}
					// user doesnt exist
					else {
						logData.type = userLoggedIn.success ? 'debug' : 'error'
						logData.responseData = userLoggedIn.success ? `user ${ username} is not registered on ikonnect` : 'Unauthenticated. User not logged in'
						this.settings.log        && ctx.emit ( 'create.log', logData);
						
						response = {
							success: false,
							error: `user ${ username} is not registered on ikonnect`
						}
					}	
				}else{
					ctx.emit('create.log', logData)
				}

				return await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(response) });
			}
		}
	}
}