"use strict"

const moment        = require ( 'moment' )

module.exports = {
	name        : "bulk",
	settings	: {
		log: true
	},
	dependencies: [],
	actions     : {
		post: {
			rest: "/post",
			params: {
				payload: "string",
				$$strict: true
			},
			async handler(ctx) {

				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					action: "post",
					requestParams: decrypted,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//let  { params }       = ctx

				decrypted.total = parseFloat( decrypted.total)

				//create multiple Requests statements
				let requests = this.createTransactions ( decrypted )

				// // console.log ( JSON.stringify ( requests, null, 4 ) )
				
				logData.bulkRequests = requests
				// compile batch requests
				let res = await ctx.call( 'core-database.bulkQuery', { requests } )

				logData.responseData = res
				this.settings.log        && ctx.emit ( 'create.log', logData);
				
				//work on transactions with the sample
				return {
					success: res.resultStatus,
					data   : res.result
				}
			}
		},
		process : {
			rest : '/process',
			params: {
				payload: "string",
				$$strict: true
			},
			async handler ( ctx ) {

				let reqParams = ctx.params.payload
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload: reqParams });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					action: "process",
					esbParams: decrypted,
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//let { params } = ctx

				// // console.log ( 'Processing bulk transactions...' )


				let payload = {
					action    : "bulk-upload",
					payload   : {
						batchNumber          : decrypted.batchNumber,
						perTransactionLimit  : decrypted.perTransactionLimit,
						dailyTransactionLimit: decrypted.dailyTransactionLimit,
						firstname            : decrypted.name,
						tax                  : decrypted.tax ? decrypted.tax.toString(): "0",
						charge               : decrypted.charge ? decrypted.charge.toString(): "0"

					},
					sessionToken: decrypted.sessionToken
				}
				let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(payload) });

				// then afterwards, post the transactions to T24
				let result = await ctx.call ( 'transactions.request', { payload: encryptedPayload })
				result = await ctx.call('core-security.ibDecrypt', { payload: result });
				result = JSON.parse(result)

				//console.log(result)


				logData.responseData = result
				this.settings.log        && ctx.emit ( 'create.log', logData);
				
				return result
			}
		},
		reject : {
			rest : '/reject',
			params: {
				payload: "string",
				$$strict: true
			},
			async handler ( ctx ) {

				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					action: "reject",
					esbParams: decrypted,
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//let { params } = ctx
				//batchNumber
				//comments

				let rejectMandRes = await ctx.call ( 'core-database.query', {
					'request-name':'reject.corporate.staging',
					payload       : {
						transactionId   : decrypted.batchNumber,
						txDate          : moment().format('YYYY-MM-DD HH:mm:ss'),
						comments		: decrypted.comments
					}
				})


				if(rejectMandRes){
					logData.responseData = rejectMandRes
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return { success: true }
				}else{
					logData.type = 'debug'
					logData.responseData = rejectMandRes
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return { success: false }
				}

			}
		},
		staging : {
			rest : '/stage-bulk',
			params: {
				payload: "string",
				$$strict: true
			},
			async handler ( ctx ) {

				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					action: "stage",
					esbParams: decrypted,
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//let { params } = ctx

				let stageBulkUpload = await ctx.call ( 'core-database.query', {
					'request-name':'mandates.bulk.stage',
					payload       : {
						batchNumber     : decrypted.batchNumber,
						email			: decrypted.email,
						roleCode   		: decrypted.role,
						txDate          : moment().format('YYYY-MM-DD HH:mm:ss'),
						comments		: decrypted.comments,
						mandateClass	: decrypted.mandateClass,
						userId			: decrypted.email
					}
				})


				if(stageBulkUpload){
					logData.responseData = 'successful'
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return { success: true }
				}else{
					logData.type = 'debug'
					logData.responseData = stageBulkUpload
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return { success: false }
				}


				
			}
		},
		fetchApproved : {
			rest : '/fetch-approved',
			async handler ( ctx ) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					action: "fetch-approved",
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { params } = ctx
				//Userid

				let fetchMandRes = await ctx.call ( 'core-database.query', {
					'request-name':'get.approved.bulk.uploads',
					payload       : {
						email   : params.userid
					}
				})


				if(fetchMandRes){
					logData.responseData = 'successful'
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return { success: true, fetchMandRes }
				}else{
					logData.type = 'debug'
					logData.responseData = fetchMandRes
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return { success: false }
				}

			}
		},
		fetchBulkUpload : {
			rest : '/fetch-bulk-upload',
			async handler ( ctx ) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					action: "fetch-bulk",
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { params } = ctx
				//Userid

				let fetchBulkUpld = await ctx.call ( 'core-database.query', {
					'request-name':'get.batch.bulk.uploads',
					payload       : {
						batchNumber: params.batchNumber
					}
				})


				if(fetchBulkUpld){
					logData.responseData = 'successful'
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return { success: true, fetchBulkUpld }
				}else{
					logData.type = 'debug'
					logData.responseData = fetchBulkUpld
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return { success: false }
				}

			}
		},
		charges : {
			rest : '/charges',
			async handler ( ctx ) {

				let reqParams = ctx.params.payload
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload: reqParams });
				decrypted = JSON.parse(decrypted)
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: decrypted,
					action: "charges",
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { params } = ctx

				// // console.log ( 'Processing bulk transaction charges...' )
				// // console.log( JSON.stringify ( { params }, null, 4 ) )


				// then afterwards, post the transactions to T24
				let procodesMap = {
					'MPESAB2C_BULK'     : 430000 ,
					'AIRTELB2C_BULK'    : 430000 ,
					'FTCORE2WALLET_BULK': 400000 ,
					'EFT_BULK'          : 402000 ,
					'RTGS_BULK_LCY'     : 403000 ,
					'RTGS_BULK_USD'     : 403000 ,
					'RTGS_BULK_GBP'     : 403000 ,
					'RTGS_BULK_EUR'     : 403000 ,
					'FT_BULK_LCY'       : 400000 ,
					'FT_BULK_USD'       : 400000 ,
					'FT_BULK_GBP'       : 400000 ,
					'FT_BULK_EUR'       : 400000 ,
					'FT_BULK_KES'       : 400000 ,
					'TT_BULK_LCY'       : 407000 ,
					'TT_BULK_USD'       : 407000 ,
					'TT_BULK_GBP'       : 407000 ,
					'TT_BULK_EUR'       : 407000 ,
					'PESALINK_BULK'     : 401000 ,
					'PREPAIDCARD_TOPUP_BULK': 430000 
				}

				// "params": {
				// 	"txType": "TT_LCY",
				// 	"perTransactionLimit": 250000,
				// 	"dailyTransactionLimit": 20000000,
				// 	"name": "EVERLYN  JOHANA",
				// 	"amount": "3000",
				// 	"phone": "254729347882",
				// 	"account": "0161019000320"
				// }

				//console.log ({ txType: params.txType })

				let txType = decrypted.txType === 'FT_BULK_KES' ? 'FT_BULK_LCY' : decrypted.txType

				let payload = {
					action    : "bulk-upload-charges",
					payload   : {
						txType 				 ,
						amount               : decrypted.amount,
						procode              : procodesMap[decrypted.txType].toString(),
						perTransactionLimit  : decrypted.perTransactionLimit,
						dailyTransactionLimit: decrypted.dailyTransactionLimit,
						firstname            : decrypted.name,
						internationalPhone   : decrypted.phone,
						creditAccount        : decrypted.account
					},
					sessionToken		 : decrypted.sessionToken
				}
				let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(payload) });

				let result = await ctx.call ( 'transactions.request', { payload: encryptedPayload })
				result = await ctx.call('core-security.ibDecrypt', { payload: result });
				result = JSON.parse(result)

				

				if(result.success && result.data && result.data.transSuccess === "00"){
					let txCount = decrypted.txnCount
					let txnId = decrypted.txnId
					let totalcharge = parseFloat(result.data.chargeAmount ) * txCount
					let totaltax = parseFloat(result.data.exciseDutyAmount ) * txCount
					
					ctx.call ( 'core-database.query', {
						'request-name':'update-bulk-staging-charges',
						payload       : {
							totalcharge,
							totaltax,
							txnId,
							txType
						}
					})

				}

				logData.responseData = result
				this.settings.log        && ctx.emit ( 'create.log', logData);
				

				return await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(result) });
			}
		}
	},
	methods  : {
		createTransactions ( bulkTx ) {
			
			// create  bulk staging entry
			let staging = {
				batchNumber          : bulkTx.batchNumber,
				txcount              : bulkTx.txcount,
				debitAccount         : bulkTx.debitAccount,
				phoneNumber          : bulkTx.phone ? bulkTx.phone : '',
				type                 : "BULK",
				total                : bulkTx.total,
				Account_To           : "",
				txDate               : bulkTx.txDate,
				Initiated_By         : bulkTx.initiator,   
				Is_Fully_Reviewed    : bulkTx.reviewTxn ? 0: 1,
				Is_Bulk_Transaction  : 1,
				Currency             : bulkTx.accountCurrency,
				CrCurrency          : 'KES',
				NetworkProvider      : '',
				perTransactionLimit  : bulkTx.perTransactionLimit,
				dailyTransactionLimit: bulkTx.dailyTransactionLimit,
				name                 : bulkTx.name
			}

			/**
			 * Procode F100
				430000 MPESAB2C_BULK
				430000 AIRTELB2C_BULK
				400000 FTCORE2WALLET_BULK
				402000 EFT_BULK
				403000 RTGS_BULK_LCY
				403000 RTGS_BULK_USD
				403000 RTGS_BULK_GBP
				403000 RTGS_BULK_EUR
				400000 FT_BULK_LCY
				400000 FT_BULK_USD
				400000 FT_BULK_GBP
				400000 FT_BULK_EUR
				407000 TT_BULK_LCY
				407000 TT_BULK_USD
				407000 TT_BULK_GBP
				407000 TT_BULK_EUR
				401000 PESALINK_BULK
			 */
			
			// create  bulk transaction entiries
			let bulkTxns = []
			
			for ( let index in bulkTx.transactions ){
			
				let template = {
					batchNumber          : bulkTx.batchNumber,        
					debitAccount         : bulkTx.debitAccount,
					debitAccountName     : bulkTx.debitAccountName,
					initiator            : bulkTx.initiator,
					Currency             : bulkTx.accountCurrency,
					perTransactionLimit  : bulkTx.perTransactionLimit,
					dailyTransactionLimit: bulkTx.dailyTransactionLimit,
					name                 : bulkTx.name,
					phone                : bulkTx.phone,
					NetworkProvider      : ''
					// Created_On   : bulkTx.txDate,
				}
			
				let txn      = bulkTx.transactions[index]
				let field100 = ''

				//console.log ( JSON.stringify ( txn, null, 4 ) )

				switch ( bulkTx.accountCurrency ) {
					case 'KES':
						field100 = '_LCY'
						break;
					case 'USD':
						field100 = '_USD'
						break;
					case 'EUR':
						field100 = '_EUR'
						break;
					case 'GBP':
						field100 = '_GBP'
						break;
				}
			
				switch ( txn.type ) {
					case "internal-transfers":
						staging.type       = `FT_BULK${field100}`
						staging.CrCurrency = txn.currency ? txn.currency : 'KES'
						template = {
							...template,
							TransactionId: `${bulkTx.batchNumber}${index+1}`,
							MobileNumber : "",
							AccountNumber: txn.account,
							AccountName  : txn.beneficiary,
							type         : `FT_BULK${field100}`,
							Amount       : txn.amount,
							Narration    : txn.narration,        
							BankCode     : "",
							BankName     : "",
							SortCode     : "",
							Currency     : txn.currency ? txn.currency : 'KES',
							SwiftCode    : "",
							Branch_Code  : "",
							Payload      : "",
							Destination  : ""
						}
						break;
					case "pesalink":
						staging.type = `PESALINK_BULK`
						template = {
							...template,
							TransactionId: `${bulkTx.batchNumber}${index+1}`,
							MobileNumber : "",
							AccountNumber: txn.account,
							AccountName  : txn.beneficiary,
							Destination  : "Account", //Account, Card, Phone
							type         : "PESALINK_BULK",
							Amount       : txn.amount,
							Narration    : txn.narration,        
							BankCode     : txn.pesalinkCode,
							BankName     : txn.bank,
							SortCode     : "",
							SwiftCode    : "",
							Branch_Code  : "",
							Payload      : ""
						}
						break;
					case "eft":
						staging.type = `EFT_BULK`
						template = {
							...template,
							TransactionId: `${bulkTx.batchNumber}${index+1}`,
							MobileNumber : "",
							AccountNumber: txn.account,
							AccountName  : txn.beneficiary,
							type         : "EFT_BULK",
							Amount       : txn.amount,
							Narration    : txn.narration, 
							Destination  : "Account",       
							BankCode     : txn.bankCode,
							Branch_Code  : txn.sortCode ? txn.sortCode.toString().slice (2,5) : "",
							BankName     : txn.bank,
							SortCode     : txn.sortCode,
							SwiftCode    : "",
							Payload      : ""
						}
						break;
					case "mobile-transfers":

						staging.NetworkProvider = txn.provider.replace(/-/g,'')
						staging.type = txn.provider.replace(/-/g,'').includes ( 'MPESA' ) ? 'MPESAB2C_BULK' : 'AIRTELB2C_BULK'


						template = {
							...template,
							TransactionId   : `${bulkTx.batchNumber}${index+1}`,
							MobileNumber    : txn.mobile,
							AccountNumber   : "",
							AccountName     : txn.beneficiary,
							provider        : txn.provider.replace(/-/g,''),
							NetworkProvider : txn.provider.replace(/-/g,''),
							type            : txn.provider.replace(/-/g,'').includes ( 'MPESA' ) ? 'MPESAB2C_BULK' : 'AIRTELB2C_BULK',
							Amount          : txn.amount,
							Narration       : txn.narration,        
							BankCode        : "",
							BankName        : "",
							SortCode        : "",
							SwiftCode       : "",
							Destination     : "Account",
							Branch_Code     : "",
							Payload         : ""
						}
						break;
					case "wallet-transfers":
						staging.type = "FTCORE2WALLET_BULK"
						template = {
							...template,
							TransactionId: `${bulkTx.batchNumber}${index+1}`,
							MobileNumber : "",
							AccountNumber: txn.account,
							AccountName  : txn.beneficiary,
							type         : "FTCORE2WALLET_BULK",
							Amount       : txn.amount,
							Narration    : txn.narration,     
							Destination  : "Account",
							Payload      : ""
						}            
						break;
					case "prepaid-card-funding":
						staging.type = "PREPAIDCARD_TOPUP_BULK"
						staging.CrCurrency = txn.currency
						template = {
							...template,
							TransactionId: `${bulkTx.batchNumber}${index + 1}`,
							MobileNumber : "",
							AccountNumber: txn.account,
							AccountName  : txn.beneficiary,
							type         : "PREPAIDCARD_TOPUP_BULK",
							Amount       : txn.amount,
							Currency     : txn.currency,
							Narration    : txn.narration,     
							Destination  : "Account",
							Payload      : ""
						}            
						break;
					case "international-transfers":
						staging.type       = `TT_BULK${field100}`
						staging.CrCurrency = txn.currency
						template = {
							...template,
							TransactionId: `${bulkTx.batchNumber}${index+1}`,
							MobileNumber : "",
							AccountNumber: txn.account,
							AccountName  : txn.beneficiary,
							type         : `TT_BULK${field100}`,
							Amount       : txn.amount,
							Narration    : txn.narration,        
							BankCode     : "",
							BankName     : txn.bank,
							SortCode     : "",
							Destination  : "Account",
							Currency     : txn.currency,
							SwiftCode    : txn.swiftCode,
							Branch_Code  : "",
							Payload      : ""
						}
						break;
					case "rtgs-kes":
						staging.type = "RTGS_BULK_LCY"
						template = {
							...template,
							TransactionId: `${bulkTx.batchNumber}${index+1}`,
							MobileNumber : "",
							AccountNumber: txn.account,
							AccountName  : txn.beneficiary,
							type         : "RTGS_BULK_LCY",
							Amount       : txn.amount,
							Narration    : txn.narration,     
							Destination  : "Account",   
							BankCode     : txn.bankCode,
							BankName     : txn.bank,
							SortCode     : "",
							SwiftCode    : txn.swiftCode,
							Branch_Code  : "",
							Payload      : ""
						}            
						break;
					case "rtgs-fcy":
						staging.type = `RTGS_BULK${field100}`
						staging.CrCurrency = txn.currency
						template     = {
							...template,
							TransactionId: `${bulkTx.batchNumber}${index+1}`,
							MobileNumber : "",
							AccountNumber: txn.account,
							AccountName  : txn.beneficiary,
							type         : `RTGS_BULK${field100}`,
							Amount       : txn.amount,
							Narration    : txn.narration, 
							Destination  : "Account",       
							BankCode     : txn.bankCode,
							BankName     : txn.bank,
							SortCode     : "",
							Currency     : txn.currency,
							SwiftCode    : txn.swiftCode,
							Branch_Code  : "",
							Payload      : ""
						}
						break;
						
				}
			
				template.Payload = ""
				// template.Payload = JSON.stringify(template)
			
				bulkTxns.push ( template )
			
			}
			
			// create audit trail entry
			let audit_trail = {
				batchNumber: bulkTx.batchNumber,
				Stage      : 'INPUTTER',
				initiator  : bulkTx.initiator,
				txDate     : bulkTx.txDate
			}
			
			let requests = []
			
			// create database requests
			for ( let data of bulkTxns ) {
				requests.push ({
					'request-name': 'insert.bulk.transaction',
					payload:data
				})
			}
			
			// corporate staging request
			requests.push ({
				'request-name': 'insert.corporate.staging',
				payload : staging
			})
			
			// corporate audit trail
			requests.push ({
				'request-name':'insert.corporate.audit.trail' ,
				payload: audit_trail
			})
			
			return requests
		}
	}
}