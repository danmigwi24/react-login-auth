// Environment Config
const path          = require ( 'path' )
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw env.error }
const useTLS       = false


// [ https ]
const express   = require ( 'express' )
const app       = express ().disable ( 'x-powered-by' )
const fs        = require ( 'fs' )
const https     = require ( 'https' )
const port      = 6355

app.use ( ( req, res, next ) => {
	res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
	res.header("Access-Control-Allow-Headers", "*");
	next()
})

app.all(
	'*', (req,res) =>{
		res.send('')
		//throw new Error('Undefined')
	}
)

let server = useTLS ? https.createServer({
	key : fs.readFileSync ( './ssl/private.key'),
	cert: fs.readFileSync ( './ssl/public.pem' )
}, app ) .listen ( port, () => null ) 

: 

app.listen ( port, () => null )

// [ sockets ]
var io = require('socket.io').listen(server);
// const io       = require ( 'socket.io' )()
const low      = require ( 'lowdb')
const FileSync = require ( 'lowdb/adapters/FileSync' )
const uniqid   = require ( 'uniqid' )


module.exports = {
	name     : "messaging",
	actions  : {
		hello: {
			rest  : "/hello",
			params: {
				message: "string"
			},
			async handler ( ctx ) {
				let { params } = ctx
				return { 
					request  : params.message, 
					response : `hello from server`
				}
			}
		}
	},
	settings : {
		wsPort:5000
	},
	methods  : {
		
		startChat  ( payload ){

			/**
			 * {
					username: "mburu.johana", 
					role:"client", 
					chatType :"forex-negotiation",
					"message" :"Hi there.."
				}
				0 This is on client connection/ client messaging
				1. create a chat database for the user if it doesnt exist
				2. if role is client,create entries for forex,fs and customer service
				3. generate a unique chat ticket and start a message trail 
			 */

			// create a connection to the db			
			const dbPath   = path.resolve ( `./public/chat/ikonnect.chats.db` )
			let adapter    =  new FileSync ( dbPath, {
				serialize   : data => JSON.stringify ( data,null,4 ),
				deserialize : data => JSON.parse ( data )
			})
			let db         = low (  adapter)
			db.defaults ({ chats:[] }) .write()



			// generate the ticket id
			let prefix = ''

			if ( payload.chatType === 'forex-negotiation' ){
				prefix = 'FX-IK'
			}
			if ( payload.chatType === 'fixed-deposit-negotiation' ){
				prefix = 'FD-IK'
			}
			if ( payload.chatType === 'customer-service-query' ){
				prefix = 'CS-IK'
			}
			let ticket = prefix + uniqid.process().toUpperCase()
			
			// timestamp
			let time         = payload.timestamp

			let ticketData   = {
				"ticket"      : ticket,
				"username"    : payload.username,
				"role"        : payload.role,
				"type"        : payload.chatType,
				"status"      : "unassaigned",
				"assigned-to" : "",
				"created-date": time,
				"update-date" : "",
				"entries"     : [{
					"type"       : "request",
					"message"    : payload.message,
					"timestamp"  : time,
					"seen"       : false
				}]
			}

			//write entry
			db.get( 'chats' ).push( ticketData ).write()

			db = null
			return ticket

		},
		updateChat ( payload ){

			// // console.log ( `updating chat` )

			const dbPath   = path.resolve ( `./public/chat/ikonnect.chats.db` )
			let adapter    =  new FileSync ( dbPath, {
				serialize   : data => JSON.stringify ( data,null,4  ),
				deserialize : data => JSON.parse ( data )
			})
			let db         = low (  adapter)
			let data       = db.get( 'chats' ).find({ ticket : payload.ticket }).value()

			if ( payload.role === 'client' ) {
				data["update-date"] = payload.timestamp
				data.entries.push({
					"type"        : payload.type || "request",
					"message"     : payload.message,
					"timestamp"   : payload.timestamp,
					"seen"        : false
				})
			}

			if ( payload.role === 'admin' ) {

				if ( data["assigned-to"] === "" ) {
					data["assigned-to"] = payload.username
				}
				data["status"] = 'active'
				data["update-date"] = payload.timestamp
				data.entries.push({
					"type"        :"response",
					"message"     : payload.message,
					"timestamp"   : payload.timestamp,
					"seen"        : false
				})
			}

			db.get( 'chats' ).find({ ticket : payload.ticket }).assign( data).write()
			db = null

		},
		getChats   ( payload ){

			const dbPath   = path.resolve ( `./public/chat/ikonnect.chats.db` )
			let adapter    =  new FileSync ( dbPath, {
				serialize   : data => JSON.stringify ( data,null,4  ),
				deserialize : data => JSON.parse ( data )
			})
			let db         = low (  adapter)
			let data       = []

		
			if ( payload.role === 'client' ) {
				data = db.get( 'chats' ).filter({ username: payload.username }).value()
			}

			if ( payload.role === 'admin' ) {
				let assigned = db.get( 'chats' )   .filter({ [`assigned-to`]: payload.username }).value()
				let unsassigned = db.get( 'chats' ).filter({ [`assigned-to`]: "" }).value() 

				data = [ ...assigned, ...unsassigned  ]
			}

			return data


		},
		closeTicket ( payload ){

			const dbPath   = path.resolve ( `./public/chat/ikonnect.chats.db` )
			let adapter    =  new FileSync ( dbPath, {
				serialize   : data => JSON.stringify ( data,null,4  ),
				deserialize : data => JSON.parse ( data )
			})
			let db         = low (  adapter)
			let data       = db.get( 'chats' ).find({ ticket : payload.ticket }).value()

			

			if ( payload.role === 'admin' ) {
				data["status"] = 'closed'
				data["update-date"] = payload.timestamp
				data.entries.push({
					"type"        :"response",
					"message"     : payload.message,
					"timestamp"   : payload.timestamp,
					"seen"        : false
				})
			}

			db.get( 'chats' ).find({ ticket : payload.ticket }).assign( data).write()
			db = null
		},

		// socket server
		async socketServer(){

			

			let self = this
	
			// Handle data transfer
			// io.on('connection', (client) => {

			// 	client.on( 'getChats', payload => {
			// 		let chats =  self.getChats (payload)
			// 		client.emit ( 'getChats', chats )					
			// 	})
			// 	client.on( 'closeTicket', payload => {
			// 		self.closeTicket (payload)					
			// 	})

				
	
			// 	client.on( 'request', payload => {

			// 		//get clients details from lowdb using the chat id
			// 		client.broadcast.emit ( 'request', payload  )

			// 		// create ticket if none is on tghe payload ( new chat )
			// 		if ( !payload.ticket ){
			// 			let ticket = self.startChat (payload)
			// 			// // console.log ({ ticketResponse :{ ...payload, ticket } })
			// 			let firstname = payload.username.split('@')[0]
			// 			self.updateChat ({ 
			// 				...payload, 
			// 				ticket, 
			// 				type: "response", 
			// 				username: 'chatbot', 
			// 				message:`Dear ${firstname},<br> We are excited to connect with you. We have assigned your ${payload.chatType} the ticket number: <b>${ticket}</b> for easy tracking.How may we help you` })
			// 			client.emit ( 'ticketCreated', { ...payload, ticket } )
			// 			client.emit ( 'response', {...payload, username: 'chatbot', message:`Client: ${payload.username},<br> ${payload.chatType} ticket number: <b>${ticket}</b>` } )
			// 		}
			// 		else {
			// 			self.updateChat( payload )
			// 		}
					
			// 	})
	
			// 	client.on( 'response', payload => {
			// 		// // console.log ({ adminResponse :{ payload } })
			// 		self.updateChat( payload )
			// 		client.broadcast.emit ( 'response', payload )		
			// 	})
				
			// })	


			// Listen on Socket
			//io.listen ( server )
			// // console.log ( 'Socket Server listening on port ', port )

			
		}
	},	

	created         () {
		this.socketServer()
	},
	async started   () {		
	},
	async stopped   () {
		io.close()
		// // console.log(`messaging-chat service stopped..`)
	}
}