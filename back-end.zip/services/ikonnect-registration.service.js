"use strict"

// Environment Config
const path          = require ( 'path' )
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw result.error }
const appName       = process.env.appName
const moment        = require ( 'moment' )

const activateLink  = process.env.activationLink
const playStoreLink = process.env.playStoreLink

module.exports = {
	name   : "registration",
	settings	: {
		log: true
	},
	actions: {
		lookup: {
			rest  : "/core-account-lookup",
			params: {
				payload  : "string",
				$$strict: true
			},
			async handler(ctx) {

				
				let { payload } = ctx.params

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					responseData: 'Success',
					userDevice: ctx.meta.userDevice
				};
				
				
				
				//Contact ESB to return this data
				let result = await ctx.call ( 'transactions.request', {payload})
				// result = await ctx.call('core-security.ibDecrypt', { payload: result });
				// result = JSON.parse(result)

				this.settings.log        && ctx.emit ( 'create.log', logData);

				return result
				
			}
		},
		new: {
			rest  : "/new", //Register a customer with an existing core account
			params: {
				"firstname"         : ["string","number"],
				"secondname"        : ["string","number"],
				"lastname"          : ["string","number"],
				"phonenumber"       : { type: "string",  "min" : 10 },
				"idtype"            : ["string","number"],
				"id"                : ["string","number"],
				"email"             : "email",
				"dob"               : ["string","number"],
				"gender"            : ["string","number"],
				"krapin"            : ["string","number"],
				"branchcode"        : ["string","number"],
				"sector"            : ["string", "number"],
				"industry"          : ["string", "number"],
				"createdby"         : ["string","number"],
				"accountnumber"     : ["string","number"],
				"accounttype"       : ["string","number"],
				"accountdescription": ["string","number"],
				"t24AccountName"    : ["string","number"],
				"t24id"             : ["string", "number"],
				"t24currency"       : ["string","number"],
				"customerlimit"     : ["string","number"],
				"channel"           : ["string","number"],			
				"password"          : ["string","number"],			
				"hasCoreAccount"    : "boolean",
				"kraPinChanged"     : "boolean",
				"dailyLimit"        : ["string","number"],	
				"transactionLimit"  : ["string","number"] 
			},
			async handler ( ctx ) {

				
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					//esbParams: ctx.params,
					resposeCode: 200,
					responseData: 'Success',
					userDevice: ctx.meta.userDevice
				};

				let mpesaCheckoutSucceeded = false
				let accountOpened          = false
				let kraUpdated             = true
				let hasCoreAccount         = ctx.params.hasCoreAccount
				let response  = {
					success : false,
					message : 'Request Failed'
				} 


				// New Account
				if ( !hasCoreAccount ) {

					let phone = ctx.params.phonenumber

					if ( phone.startsWith ( '0' ) && phone.length === 10 ) {
						phone = '254'+phone.slice(1)
					}

					let payload = {
						"phone"      : phone,
						"names"      : `${ctx.params.firstname} ${ctx.params.secondname} ${ctx.params.lastname}`,
						"id"         : ctx.params.id,
						"email"      : ctx.params.email,
						"kraPin"     : ctx.params.krapin,
						"gender"     : ctx.params.gender,
						"productCode": ctx.params.accounttype							
					}

					// Prompt an MPESA checkout
					// Send to T24 ( ESB Account Opening )
					logData.esbParams = payload

					let paramsPayload = {
						"action" : "ikonnect-account-opening" ,
						"payload": payload
					}

					let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(paramsPayload) });

					let openAccount = await ctx.call ( 'transactions.request', { payload: encryptedPayload })
					openAccount = await ctx.call('core-security.ibDecrypt', { payload: openAccount });
					openAccount = JSON.parse(openAccount)

					let openAccountPayload = {
						productCode  : ctx.params.accounttype,
						customerId   : ctx.params.t24id,
						account      : phone,
						currency     : ctx.params.t24currency,
						phone        : ctx.params.phonenumber,
						email        : ctx.params.email,
						gender       : ctx.params.gender,
						statusCode   : '',
						createdBy    : 'ESB',
						created      : moment().format ( 'YYYY-MM-DD HH:mm:ss'),
						branchCode   : ctx.params.branchcode,
						statusMessage: ''
					}

					//open in IB
					if ( openAccount.success ) {
						accountOpened = true,
						openAccountPayload = {
							...openAccountPayload,
							account      : openAccount.data.itaxDetails,
							statusCode   : openAccount.data.transSuccess,
							statusMessage: openAccount.data.transDescription
						}

					}
					else {
						response.error = 'Could not open core account'
						openAccountPayload = {
							...openAccountPayload,
							account      : '',
							statusCode   : openAccount.data.transSuccess,
							statusMessage: openAccount.data.transDescription
						}
					}

					// ctx.call ( 'core-database.query', {
					// 	'request-name' : 'account.opening.attempt',
					// 	payload: openAccountPayload
					// })
					ctx.call ( 'core-database.query', {
						'request-name' : 'all-account-open-attempts',
						payload: {
							account: openAccountPayload.account,
							productCode: openAccountPayload.productCode,
							customerId: openAccountPayload.customerId,
							currency: openAccountPayload.currency,
							phone: openAccountPayload.phone,
							email: openAccountPayload.email,
							gender: openAccountPayload.gender,
							code: openAccount.data.transSuccess,
							branchCode: openAccountPayload.branchCode,
							message: openAccount.data.transDescription
						}
					})

					

										
				}

				// update KRA PIN in T24 if changed	
				if ( hasCoreAccount ) {

					let payload = {
						action: "ikonnect-update-kra",
						payload: {
							"phone"      : ctx.params.phonenumber,
							"customerId" : `${ctx.params.t24id}`,
							"kraPin"     : ctx.params.krapin
						}						
					}

					let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(payload) });
					// update KRA
					ctx.call ( 'transactions.request', { payload: encryptedPayload })
				}
				
				//update in our database ( IB )
				let kraPinValid       = kraUpdated
				let existingUserCheck = hasCoreAccount && kraPinValid
				let newUserCheck      = !hasCoreAccount && accountOpened

				// client has been updated successfuly ( kra pin, account opened)
				if ( existingUserCheck || newUserCheck ){
					
					let { resultStatus, result } = await ctx.call ( 'core-database.query', {
						'request-name' : 'register',
						payload        : ctx.params
					})

					if ( resultStatus ) {

						let arrResp =  result instanceof Array && result[0] instanceof Array
						
						if ( arrResp ){
							
							let code    = result[0][0].Resp_code
							let message = result[0][0].Narration

							response = {
								success: code === '00' ? true : false,
								message,
								code						
							}
						}
						
						
						logData.responseData = response
						this.settings.log        && ctx.emit ( 'create.log', logData);
					
					}
					else {
						response =  {
							success: false,
							error  : result,
							message: `Couldnt query the database`
						};
						
						logData.type = 'debug'
						logData.responseData = response
						this.settings.log        && ctx.emit ( 'create.log', logData);
					
					}
				}
				else {
					response  = {
						success : false,
						error   : response.error ? response.error : 'Registration Failed',
						message : response.error ? response.error : 'Registration Failed'								
					}

					
					logData.type = 'debug'
					logData.responseData = response
					this.settings.log        && ctx.emit ( 'create.log', logData);
				
				}


				// JSON.stringify ({
				// 	userEmail,
				// 	dateGenerated: moment().format ( 'YYYY-MM-DD HH:mm:ss' )
				// })

				//send email
				if ( response.success ){
					//24 hour expiry
					var uniqid = require('uniqid');
					let token = `${uniqid.process().toUpperCase()}_${moment().format ( 'YYYY-MM-DD HH:mm:ss' )}`;

					let userEmail      = ctx.params.email
					let userName       = `${ctx.params.firstname}`
					let tokenData      = await ctx.call (  'core-security.fastEncrypt', {
						payload       : JSON.stringify ({
							userEmail,
							token
						})
					})
					let activationLink = `${activateLink}/auth/activation.html?token=${tokenData.encoded}`				
					let appLink        = `${playStoreLink}`;

					await ctx.call('core-database.query', {
						'request-name': 'update-user-token',
						payload: {
							token	: tokenData.encoded,
							email 	: userEmail
						}
					})
					
					ctx.call (  'core-email.send', {
						recipients       : userEmail,
						subject         : 'iKonnect Account Activation',
						message         : '',
						template        : {
							name        : `account-confirmation`,
							data        : { userName, activationLink, appLink },
							attachments : [
								{
									"filename": "qrcode.png",
									"path"    : path.resolve ( `./config/${appName}/email/images/qrcode.png`),
									"cid"     : "ikonnect.qrcode"
								}
							]
						}
					})

					logData.requestParams = {}
				}
				else {
					// insert into failed registration   
					let payload = {
						phone    : ctx.params.phonenumber,
						fname    : ctx.params.firstname,
						othername: ctx.params.secondname,
						surname  : ctx.params.lastname,
						email    : ctx.params.email,
						idType   : ctx.params.idtype,
						idNumber : ctx.params.id,
						createdOn: moment().format('YYYY-MM-DD HH:mm:ss'),
						type     : `${hasCoreAccount ? 'Existing' : 'New'}  Customer Registration`,
						reason   : response.message
					}

					ctx.call ( 'core-database.query', {
						'request-name' : 'failed.registration' ,
						payload
					})
				}

				logData.responseData = response
				this.settings.log        && ctx.emit ( 'create.log', logData);
			
				return response
			}
		},
		nonCitizen: {
			rest  : "/non-citizen", //Register a customer with an existing core account
			params: {
				"firstname"  : "string",
				"secondname" : "string",
				"lastname"   : "string",
				"phonenumber": "string",
				"id"         : "string",
				"email"      : "email",
				"dob"        : "string",
				"gender"     : "string",
				"productCode": ["string", "number"]
			},
			async handler ( ctx ) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

			
				let payload = {
					firstname: ctx.params.firstname,
					othername: ctx.params.secondname,
					surname  : ctx.params.lastname,
					phone    : ctx.params.phonenumber,
					email    : ctx.params.email,
					dob      : ctx.params.dob,
					gender   : ctx.params.gender,
					idType   : 'Passport',
					idNumber : ctx.params.id,
					product  : ctx.params.productCode,
					created  :moment().format('YYYY-MM-DD HH:mm:ss')
				}

				let  { resultStatus: success } = await ctx.call ( 'core-database.query', {
					'request-name' : 'add.foreign.citizen' ,
					payload
				})
				 
				logData.responseData = `Your registration request ${ success ? 'has been recieved' : 'failed' } `
				this.settings.log        && ctx.emit ( 'create.log', logData);

				return {
					success,
					message : `Your registration request ${ success ? 'has been recieved' : 'failed' } `
				}
			}
		},
		sendActivationEmail : {
			rest          : "/send-activation-email",
			params        : {
				email     : "email",
				firstname : "string"
			},
			async handler ( ctx ) {
				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				//24 hour expiry
				var uniqid = require('uniqid');
				let token = `${uniqid.process().toUpperCase()}_${moment().format ( 'YYYY-MM-DD HH:mm:ss' )}`;
				
				let userEmail      = ctx.params.email
				let userName       = `${ctx.params.firstname}`
				let tokenData      = await ctx.call (  'core-security.fastEncrypt', {
					payload       : JSON.stringify ({
						userEmail,
						token
					})
				})
				let activationLink = `${activateLink}/auth/activation.html?token=${tokenData.encoded}`				
				let appLink        = `${playStoreLink}`;

				await ctx.call('core-database.query', {
					'request-name': 'update-user-token',
					payload: {
						token	: tokenData.encoded,
						email	: userEmail
					}
				});

				
				let response = await ctx.call (  'core-email.send', {
					recipients       : userEmail,
					subject         : 'iKonnect Account Activation',
					message         : '',
					template        : {
						name        : `account-confirmation`,
						data        : { userName, activationLink, appLink },
						attachments : [
							{
								"filename": "qrcode.png",
								"path"    : path.resolve ( `./config/${appName}/email/images/qrcode.png`),
								"cid"     : "ikonnect.qrcode"
							}
						]
					}
				})

				if ( response.sent ){
					response.sent = 1
				}
				else {
					response.sent = 0
				}

				logData.responseData = response
				this.settings.log        && ctx.emit ( 'create.log', logData);


				return response
			}

		}
	}
}