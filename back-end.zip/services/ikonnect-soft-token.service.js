"use strict"

const path = require ( 'path' )
const { 
	hashPassword, 
	verifyPassword, 
	generateOtp  
} = require (  path.resolve ( `./lib/auth` ) )

const moment = require ( 'moment' )
/**
 * actions:
 * 	 - get-profile: ( username, imei ) returns first login and user details, login trials if ime doesnt exist, update it
 *  - login : ( username, password ) returns true or false + message
 *  - set-pin
 *  - update-trials ( username )
 *  - get-token
 */

module.exports = {
	name   : "soft-token",
	settings	: {
		log: true
	},
	actions: {		
		request		     : {
			rest          : "/request",
			params        : {
				type    : "string"
			},
			async handler(ctx) {

				let { type } = ctx.params
				let response = {
					success: false,
					message: `The ${type} request failed`
				}

				switch ( type ) {
					case "profile":
						response = await ctx.call ('soft-token.profile',     { ...ctx.params } ) 
						break;
					case "activate":
						response = await ctx.call ('soft-token.activate',     { ...ctx.params } ) 
						break;
					case "update-pin":
						response = await ctx.call ('soft-token.updatePin',      { ...ctx.params } ) 
						break;
					case "login":
						response = await ctx.call ('soft-token.login',          { ...ctx.params } ) 
						break;
					case "change-pin":
						response = await ctx.call ('soft-token.changePin',       { ...ctx.params } ) 
						break;
					case "update-pin-trials":
						response = await ctx.call ('soft-token.updatePinTrials', { ...ctx.params } ) 
						break;
					case "get-token":
						response = await ctx.call ('soft-token.getToken',        { ...ctx.params } ) 
						break;
				}

				return response
			}
		},
		profile          : {
			rest         : "/profile",
			params       : {
				email    : "email"
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: {},
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { email } = ctx.params				
				let message   = `Profile fetched for user ${email}`

				let { resultStatus : success, result: data } = await ctx.call ('core-database.query', {
					'request-name' : 'soft.token.profile',
					'payload' : {
						...ctx.params
					}
				})

				let hasData = data instanceof Array && data[0]  instanceof Array && data[0].length > 0 && Object.keys(data[0][0]).length > 0

				hasData  && (data = data[0][0])
				!hasData && ( data = {}) && (message = `The user ${email} is not registered for the soft token app`) && ( success = !success )

				logData.responseData = {  message }
				this.settings.log        && ctx.emit ( 'create.log', logData);

				return { success, data, message }
			}
		},
		activate         : {
			rest         : "/activate",
			params       : {
				email    : "email",
				imei     : ["string","number"],
				pin      : [{ type:"string", max: 4 } ]
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: {},
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let  { email, imei, pin } = ctx.params

				let fetchProfile = await ctx.call ('soft-token.profile', { ...ctx.params })

				if ( fetchProfile.success ) {

					// update the imei and first login and hash pin
					let hashed = await hashPassword ( pin )

					let { result:success } = await ctx.call ( 'core-database.query',{
						'request-name': 'soft.token.activate',
						payload: { email, imei, hashed }
					})

					if ( success ) {
						fetchProfile.message = `The Soft token profile for ${email} was activated successfully`
						fetchProfile.data = {}
					}
					
					

				}
				
				logData.responseData = fetchProfile.message
				this.settings.log        && ctx.emit ( 'create.log', logData);



				return fetchProfile
			}
		},
		login			 : {
			rest         : "/login",
			params: {
				email    : "email",
				imei     : ["string","number"],
				pin      : [{ type:"string", max: 4 } ]
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: {},
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let  { email, imei, pin } = ctx.params

				let fetchProfile = await ctx.call ('soft-token.profile', { ...ctx.params })

				if ( fetchProfile.success ) {					

					if ( fetchProfile.data.isFirstLogin ){
						fetchProfile.success = false
						fetchProfile.message = `User ${email} has not activated their soft token profile app`
						
						logData.type = 'debug'
						logData.responseData = fetchProfile.message
						this.settings.log        && ctx.emit ( 'create.log', logData);
						
						return fetchProfile
					}
					else {
						// check IMEI
						// if ( fetchProfile.data.imei !== imei ) {
						// 	fetchProfile.success = false
						// 	fetchProfile.message = `IMEI provided for user ${email} is incorrect`
						// 	fetchProfile.data    = {}

						// 	// update imei 2
						// 	await ctx.call ( 'core-database.query', {
						// 		'request-name' : 'soft.token.update.imei2',
						// 		payload        : { email, imei }
						// 	})
							
						// 	logData.type = 'debug'
						// 	logData.responseData = fetchProfile.message
						// 	this.settings.log        && ctx.emit ( 'create.log', logData);
							
						// 	return fetchProfile
						// }
						if ( ! await verifyPassword ( pin, fetchProfile.data.pin ) ) {

							fetchProfile.success = false
							fetchProfile.message = `PIN provided for user ${email} is incorrect`
							fetchProfile.data    = {}

							// update pin trials if pin trials = 3, change account status and block user, return account status as blocked
							let {result: data } = await ctx.call ( 'core-database.query', {
								'request-name' : 'soft.token.update.trials',
								payload        : { email }
							})

							let hasData = data instanceof Array && data[0]  instanceof Array && data[0].length > 0 && Object.keys(data[0][0]).length > 0

							hasData  && (data = data[0][0])
							
							fetchProfile.data = { ...fetchProfile.data, ...data }
							
							logData.type = 'debug'
							logData.responseData = fetchProfile.message
							this.settings.log        && ctx.emit ( 'create.log', logData);
						

							return fetchProfile
						}

						// reset trials if successful
						let {result: data } = await ctx.call ( 'core-database.query', {
							'request-name' : 'soft.token.reset.trials',
							payload        : { email }
						})


						let hasData = data instanceof Array && data[0]  instanceof Array && data[0].length > 0 && Object.keys(data[0][0]).length > 0

						hasData  && (data = data[0][0])
						
						fetchProfile.data    = { ...fetchProfile.data, ...data }
						fetchProfile.message = `Login was successful`
						
						logData.type = 'debug'
						logData.responseData = fetchProfile.message
						this.settings.log        && ctx.emit ( 'create.log', logData);
						
						return fetchProfile
					}
					
				}
				fetchProfile.data    = {}
				
				logData.responseData = fetchProfile
				this.settings.log        && ctx.emit ( 'create.log', logData);
				
				return fetchProfile
			}
		},
		changePin        : {
			rest  : "/change-pin",
			params: {
				email : "email",
				imei  : ["string","number"],
				oldPin: [{ type: "string", max: 4 } ],
				newPin   : [{ type: "string", max: 4 } ]
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: {},
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { email, imei, oldPin, newPin } = ctx.params
				let fetchProfile         = await ctx.call ('soft-token.profile', { ...ctx.params })

				if ( fetchProfile.success ) {	

					if ( fetchProfile.data.isFirstLogin ){
						fetchProfile.success = false
						fetchProfile.message = `User ${email} has not activated their soft token profile app`
						
						logData.type = 'debug'
						logData.responseData = fetchProfile.message
						this.settings.log        && ctx.emit ( 'create.log', logData);
						
						return fetchProfile
					}
					else {

						let isCorrectPin = await verifyPassword ( oldPin, fetchProfile.data.pin )

						// is wrong imei
						if ( fetchProfile.data.imei !== imei ) {
							fetchProfile.success = false
							fetchProfile.message = `IMEI provided for user ${email} is incorrect`
							fetchProfile.data    = {}

							logData.type = 'debug'
							logData.responseData = fetchProfile.message
							this.settings.log        && ctx.emit ( 'create.log', logData);
							
							return fetchProfile
						}

						// is wrong pin
						if ( !isCorrectPin ) {
							fetchProfile.success = false
							fetchProfile.message = `PIN provided for user ${email} is incorrect`
							fetchProfile.data    = {}
							
							logData.type = 'debug'
							logData.responseData = fetchProfile.message
							this.settings.log        && ctx.emit ( 'create.log', logData);
						
							return fetchProfile
						}
						
						// is correct pin: update the users PIN
						if ( isCorrectPin ) {

							let { resultStatus:success} = await ctx.call ( 'core-database.query', {
								'request-name' :'soft.token.change.pin',
								payload : {
									email,
									newPin: await hashPassword ( newPin )
								}
							})

							fetchProfile.success = success

							if ( success ) {
								
								fetchProfile.data    = {}
								fetchProfile.message = `PIN Change for user ${email} was successful`
							}
							else {								
								fetchProfile.data    = {}
								fetchProfile.message = `PIN Change for user ${email} failed`

								logData.type = 'debug'
								logData.responseData = fetchProfile.message
								this.settings.log        && ctx.emit ( 'create.log', logData);
								
							}
							
							logData.responseData = fetchProfile.message
							this.settings.log        && ctx.emit ( 'create.log', logData);
							
							return fetchProfile

						}
					}
					
				}
				fetchProfile.data    = {}

				logData.responseData = fetchProfile.message
				this.settings.log        && ctx.emit ( 'create.log', logData);
				
				return fetchProfile
			}
		},
		getToken		 : {
			rest  : "/get-token",
			params: {
				email    : "email"
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				const { email }        = ctx.params
				const otp              = generateOtp()
				const hashed           = await hashPassword ( otp )

				let { resultStatus:success } = await ctx.call ( 'core-database.query',{
					'request-name':'soft.token.update.otp',
					payload       : { 
						email, 
						hashed,
						otptime: moment().format ( 'YYYY-MM-DD HH:mm:ss') }
				})

				if ( success ) {
					logData.responseData = `Token generated successfuly`
					this.settings.log        && ctx.emit ( 'create.log', logData);
					
					return {
						success,
						data: { softToken: otp, hashed },
						message :`Token generated successfuly`
					}
				}
				logData.type = 'debug'
				logData.responseData = `Token generation failed`
				this.settings.log        && ctx.emit ( 'create.log', logData);
				
				return {
					success,
					data: {},
					message :`Token generation failed`
				}
			}
		}
	}
}