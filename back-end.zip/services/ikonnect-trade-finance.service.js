"use strict"

const moment 	= require('moment');
const fs       = require ( 'fs' );
const fse               = require ( 'fs-extra' )
const path              = require ( 'path'     )
const axios               = require('axios');
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw result.error }

const apiID         = process.env.apiID
const defaultSource = process.env.defaultLink
const appName       = process.env.appName
const apiConfig   = require ( path.resolve ( `./config/${appName}/api/api` ))
const defaultIp  = apiConfig[ apiID ]['data-sources'][defaultSource]

module.exports = {
    name: "trade-finance",
    settings: {
        guaranteeEndpoint: `${defaultIp.protocol}://${defaultIp.host}:${defaultIp.port}/CreditBank_TradeFinance/GuaranteeApplication`,
        creditEndpoint: `${defaultIp.protocol}://${defaultIp.host}:${defaultIp.port}/CreditBank_TradeFinance/CreditApplication`,
        bidBondEndpoint: `${defaultIp.protocol}://${defaultIp.host}:${defaultIp.port}/CreditBank_TradeFinance/BidBondApplication`
    },
    actions: {
        bidBondApplication: {
            rest: "/bid-bond-application",
			async handler (ctx) {
				const { $multipart, fieldname, filename, mimetype } = ctx.meta
				let { payload } = $multipart

				console.log({ META: ctx.meta, Params: ctx.params, MultiPart: $multipart })

				const allowedTypes = [
					'application/pdf',
					'application/msword',
					'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
					'application/vnd.ms-excel',
					'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
				]
				
				return new Promise ( ( resolve, reject ) => {		
					// Throw error if a disallowed mimeType is present
					if ( !allowedTypes.includes ( mimetype )){
						reject (`${mimetype} is Not allowed for ${fieldname} - ${filename}`)
					}					
					
					// make sure the filepath exists
					const fileDir  = path.resolve ( `./public/tradefinancedocs/`)
					const filePath = path.resolve ( fileDir, filename)
					fse.ensureDirSync( fileDir )

					// write to the filepath
					const f = fs.createWriteStream ( filePath )
					let attachments = []
					
					
					f.on("finish", async () => {
						attachments.push({
							"filename"   : filename,
							"path"       : path.resolve(`./public/tradefinancedocs/${filename}`),
							"contentType": mimetype
						})
						
					})
					f.on ( "close", async () => {
						//console.log('top',{attachments})
						// Run decryption
						payload = await ctx.call('core-security.ibDecrypt', { payload });
                        payload = JSON.parse(payload)
						console.log({payload})

		
						let logData        = {
							type 		: 'info',
							action 		: payload.action,
							service 	: ctx.service.fullName,
							sent    	: '',
							//clientRequest: ctx.params,
							requestParams: { ...payload.payload },
							received 	: '',
							latency 	: '',
							request 	: {},
							response	: {},
							userDevice 	: ctx.meta.userDevice
						}
		
		

						var FormData = require('form-data');
						var form_data = new FormData();
						console.log({attachments})

						form_data.append(`message`, JSON.stringify(payload.payload))
						for (var i = 0; i < attachments.length; i++) {
							form_data.append(fieldname, fs.createReadStream(attachments[i].path));
						}
						

						const request_config = {
							"Authorization": `Bearer ${ctx.meta.token}`,
							"content-type": "multipart/form-data"
						};

						const https = require ('https')
						let httpsAgent  = new https.Agent({ rejectUnauthorized: false })
							
						let instance = this.settings.bidBondEndpoint.startsWith('https') ? axios.create ({ httpsAgent }) : axios.create()

						let res = {}
                        logData['sent']    = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')

						try {
							res = await instance.post (
								`${this.settings.bidBondEndpoint}`,
								form_data,
								{headers: {
									...request_config,
									...form_data.getHeaders()
								}}
							)
						} catch (error) {
							console.log(error.message)
                            res = error.response
						}
                        let feedback = res.data
						console.log({feedback})

						//log types
                        logData['received'] = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')
					    let sent            = moment ( logData.sent,'YYYY-MM-DD HH:mm:ss:SSSS'  ),
					        received        = moment ( logData.received,'YYYY-MM-DD HH:mm:ss:SSSS' )
					    logData.latency     = `${received.diff(sent, 'milliseconds')} ms`
						logData.type = feedback ? 'info' : 'debug'
						logData.clientResponse = feedback;
						ctx.emit('create.log', logData);

                        resolve(ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(feedback) }))
					})

					ctx.params.on ( "error", err => {
						reject({
							message: 'File error received',
							success: false,
							filename:path.basename ( filePath ),
							location:`File error received -  ERROR: ${err.message}`
						})
						f.destroy(err)
					})

					f.on( "error", ( err ) => {
						console.log(`File error received -  ERROR: ${err.message}` )
						// Remove the errored file.
						fs.unlinkSync ( filePath )
					});

					ctx.params.pipe ( f )
								
				})
			}
		},
        guaranteeApplication: {
            rest: "/guarantee-application",
			async handler (ctx) {
				const { $multipart, fieldname, filename, mimetype } = ctx.meta
				let { payload } = $multipart

				console.log({ META: ctx.meta, Params: ctx.params, MultiPart: $multipart })

				const allowedTypes = [
					'application/pdf',
					'application/msword',
					'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
					'application/vnd.ms-excel',
					'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
				]
				
				return new Promise ( ( resolve, reject ) => {		
					// Throw error if a disallowed mimeType is present
					if ( !allowedTypes.includes ( mimetype )){
						reject (`${mimetype} is Not allowed for ${fieldname} - ${filename}`)
					}					
					
					// make sure the filepath exists
					const fileDir  = path.resolve ( `./public/tradefinancedocs/`)
					const filePath = path.resolve ( fileDir, filename)
					fse.ensureDirSync( fileDir )

					// write to the filepath
					const f = fs.createWriteStream ( filePath )
					let attachments = []
					
					
					f.on("finish", async () => {
						attachments.push({
							"filename"   : filename,
							"path"       : path.resolve(`./public/tradefinancedocs/${filename}`),
							"contentType": mimetype
						})
						
					})
					f.on ( "close", async () => {
						//console.log('top',{attachments})
						// Run decryption
						payload = await ctx.call('core-security.ibDecrypt', { payload });
                        payload = JSON.parse(payload)
						console.log({payload})

		
						let logData        = {
							type 		: 'info',
							action 		: payload.action,
							service 	: ctx.service.fullName,
							sent    	: '',
							//clientRequest: ctx.params,
							requestParams: { ...payload.payload },
							received 	: '',
							latency 	: '',
							request 	: {},
							response	: {},
							userDevice 	: ctx.meta.userDevice
						}
		
		

						var FormData = require('form-data');
						var form_data = new FormData();
						console.log({attachments})

						form_data.append(`message`, JSON.stringify(payload.payload))
						for (var i = 0; i < attachments.length; i++) {
							form_data.append(fieldname, fs.createReadStream(attachments[i].path));
						}
						

						const request_config = {
							"Authorization": `Bearer ${ctx.meta.token}`,
							"content-type": "multipart/form-data"
						};

						const https = require ('https')
						let httpsAgent  = new https.Agent({ rejectUnauthorized: false })
							
						let instance = this.settings.guaranteeEndpoint.startsWith('https') ? axios.create ({ httpsAgent }) : axios.create()

						let res = {}
                        logData['sent']    = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')

						try {
							res = await instance.post (
								`${this.settings.guaranteeEndpoint}`,
								form_data,
								{headers: {
									...request_config,
									...form_data.getHeaders()
								}}
							)
						} catch (error) {
							console.log(error.message)
                            res = error.response
						}
                        let feedback = res.data
						console.log({feedback})

						//log types
                        logData['received'] = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')
					    let sent            = moment ( logData.sent,'YYYY-MM-DD HH:mm:ss:SSSS'  ),
					        received        = moment ( logData.received,'YYYY-MM-DD HH:mm:ss:SSSS' )
					    logData.latency     = `${received.diff(sent, 'milliseconds')} ms`
						logData.type = feedback ? 'info' : 'debug'
						logData.clientResponse = feedback;
						ctx.emit('create.log', logData);


							
						resolve(ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(feedback) }))
					})

					ctx.params.on ( "error", err => {
						reject({
							message: 'File error received',
							success: false,
							filename:path.basename ( filePath ),
							location:`File error received -  ERROR: ${err.message}`
						})
						f.destroy(err)
					})

					f.on( "error", ( err ) => {
						console.log(`File error received -  ERROR: ${err.message}` )
						// Remove the errored file.
						fs.unlinkSync ( filePath )
					});

					ctx.params.pipe ( f )
								
				})
			}
		},
        letterofCreditApplication: {
            rest: "/letter-of-credit-application",
			async handler (ctx) {
				const { $multipart, fieldname, filename, mimetype } = ctx.meta
				let { payload } = $multipart

				console.log({ META: ctx.meta, Params: ctx.params, MultiPart: $multipart })

				const allowedTypes = [
					'application/pdf',
					'application/msword',
					'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
					'application/vnd.ms-excel',
					'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
				]
				
				return new Promise ( ( resolve, reject ) => {		
					// Throw error if a disallowed mimeType is present
					if ( !allowedTypes.includes ( mimetype )){
						reject (`${mimetype} is Not allowed for ${fieldname} - ${filename}`)
					}					
					
					// make sure the filepath exists
					const fileDir  = path.resolve ( `./public/tradefinancedocs/`)
					const filePath = path.resolve ( fileDir, filename)
					fse.ensureDirSync( fileDir )

					// write to the filepath
					const f = fs.createWriteStream ( filePath )
					let attachments = []
					
					
					f.on("finish", async () => {
						attachments.push({
							"filename"   : filename,
							"path"       : path.resolve(`./public/tradefinancedocs/${filename}`),
							"contentType": mimetype
						})
						
					})
					f.on ( "close", async () => {
						//console.log('top',{attachments})
						// Run decryption
						payload = await ctx.call('core-security.ibDecrypt', { payload });
                        payload = JSON.parse(payload)
						console.log({payload})

		
						let logData        = {
							type 		: 'info',
							action 		: payload.action,
							service 	: ctx.service.fullName,
							sent    	: '',
							//clientRequest: ctx.params,
							requestParams: { ...payload.payload },
							received 	: '',
							latency 	: '',
							request 	: {},
							response	: {},
							userDevice 	: ctx.meta.userDevice
						}
		
		

						var FormData = require('form-data');
						var form_data = new FormData();
						console.log({attachments})

						form_data.append(`message`, JSON.stringify(payload.payload))
						for (var i = 0; i < attachments.length; i++) {
							form_data.append(fieldname, fs.createReadStream(attachments[i].path));
						}
						

						const request_config = {
							"Authorization": `Bearer ${ctx.meta.token}`,
							"content-type": "multipart/form-data"
						};

						const https = require ('https')
						let httpsAgent  = new https.Agent({ rejectUnauthorized: false })
							
						let instance = this.settings.creditEndpoint.startsWith('https') ? axios.create ({ httpsAgent }) : axios.create()

						let res = {}
                        logData['sent']    = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')

						try {
							res = await instance.post (
								`${this.settings.creditEndpoint}`,
								form_data,
								{headers: {
									...request_config,
									...form_data.getHeaders()
								}}
							)
						} catch (error) {
							console.log(error.message)
                            res = error.response
						}
                        let feedback = res.data
						console.log({feedback})

						//log types
                        logData['received'] = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')
					    let sent            = moment ( logData.sent,'YYYY-MM-DD HH:mm:ss:SSSS'  ),
					        received        = moment ( logData.received,'YYYY-MM-DD HH:mm:ss:SSSS' )
					    logData.latency     = `${received.diff(sent, 'milliseconds')} ms`
						logData.type = feedback ? 'info' : 'debug'
						logData.clientResponse = feedback;
						ctx.emit('create.log', logData);

                        resolve(ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(feedback) }))
					})

					ctx.params.on ( "error", err => {
						reject({
							message: 'File error received',
							success: false,
							filename:path.basename ( filePath ),
							location:`File error received -  ERROR: ${err.message}`
						})
						f.destroy(err)
					})

					f.on( "error", ( err ) => {
						console.log(`File error received -  ERROR: ${err.message}` )
						// Remove the errored file.
						fs.unlinkSync ( filePath )
					});

					ctx.params.pipe ( f )
								
				})
			}
		},
		forexTicket: {
			rest: '/get-negotiated-rate',
			params: {
				username: 'email',
				ticket: 'string|min:2'
			},
			async handler (ctx) {
				let { username, ticket } = ctx.params

				// let { resultStatus, result } = await ctx.call('core-database', { 
				// 	'request-name': 'fetch-new-forex-rate',
                //     'payload'     : { username, ticket }
				// })

				// if(resultStatus && result && result[0].length > 0){

				// }else{

				// }

				return {
					success: true,
					rate: 5
				}
			}
		}
    },
    methods: {

    }
}