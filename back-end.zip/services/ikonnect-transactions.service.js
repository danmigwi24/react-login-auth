"use strict"

/**
 	Libraries and Configurations
 */

// core libraries
const path        = require ( 'path'   ) 
const axios       = require ( 'axios'  )
const moment      = require ( 'moment' )
const Validator   = require ( 'fastest-validator' )

// Environment Config
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw result.error }
const apiID         = process.env.apiID
const defaultSource = process.env.defaultLink
const appName       = process.env.appName
const authUrl       = process.env.ESB_TOKEN

// File Configs and Helpers
const apiConfig   = require ( path.resolve ( `./config/${appName}/api/api` ))
const apiTypes    = require ( path.resolve ( `./config/${appName}/api/api-types` ))
const Helpers     = require ( path.resolve ( `./lib/api` ))
const utility     = new Helpers ()

module.exports = {

	name    : "transactions",
	settings: {
		timeout          : 60000,
		externalLinks    : apiConfig[ apiID ]['data-sources'],
		defaultLink      : apiConfig[ apiID ]['data-sources'][defaultSource],
		metaData         : apiConfig[ apiID ]['meta-data'],
		requestSettings  : apiConfig[ apiID ]['request-settings'],
		validationSchemas: apiTypes [ apiID ],		
		log              : true,
		analytics        : true	
	},
	actions : {
		request   : {
			rest  : "/request",
			params: {
				//action    : "string",
				payload   : "string",
				$$strict  : true
			},
			async handler ( ctx ) {

				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)
				let logData        = {
					type 		: 'info',
					service 	: ctx.service.fullName,
					sent    	: '',
					clientRequest: { ...decrypted },
					//requestParams: ctx.params,
					received 	: '',
					latency 	: '',
					request 	: {},
					response	: {},
					userDevice 	: ctx.meta.userDevice
				}
				try {
					delete logData.clientRequest.sessionToken
					delete logData.clientRequest.firstname
					delete logData.clientRequest.phoneNumber
				} catch (error) {
					
				}

				console.log ( `Transactions Service: `,decrypted, JSON.stringify ( ctx.params, null, 4))

				if(decrypted.action !== 'ikonnect-account-lookup' && decrypted.action !== "ikonnect-update-kra" && decrypted.action !== "ikonnect-account-opening" ){
					let verfiedUser = await ctx.call ( 'auth-jwt.verify',{ token: ctx.meta.token } )
					if( verfiedUser && verfiedUser.data && verfiedUser.data.username && decrypted.sessionToken ){

						let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify({username: verfiedUser.data.username, sessionid: decrypted.sessionToken  }) });

						let userLoggedIn = await ctx.call ( 'auth-login.verifySessionId', { payload: encryptedPayload } )

						if(!userLoggedIn.success){
							logData.type = 'error'
							logData.response = 'Failed user validation session'
							ctx.emit('create.log', logData)
							return false
						}
						logData.sessionAuth = 'Passed user validation session'
					}else {
						logData.type = 'error'
						logData.response = 'Failed user validation token'
						ctx.emit('create.log', logData)
						return false
					}
				}

				// Validate Payload
				const schema = this.settings.validationSchemas [ decrypted.action ]

				if ( schema ) {
					const v      = new Validator()
					let validate = v.validate ( decrypted.payload, schema )

					if ( validate instanceof Array ) {
						logData.type = 'error'
						logData.errors = validate
						ctx.emit ( 'create.log', logData)
						return {
							success: false,
							error  : validate
						}
					}
				}
				else {
					logData.type = 'error'
					logData.errors = `SCHEMA ERROR - The Validation Schema for the ${ decrypted.action } request does not Exist`
					ctx.emit ( 'create.log', logData)
					return {
						success: false,
						error  : `SCHEMA ERROR - The Validation Schema for the ${ decrypted.action } request does not Exist`
					}	
				}

				// Default Variables
				let	fetch          = false 
				let requestSuccess = false
				let feedback       = false
				

				// Generate Request
				let generateRequest  = await this.generateRequest( decrypted )
				
				// Run Fetch
				if ( generateRequest.success  ) {

					// Log the request
					logData['sent']    = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')
					logData['request'] = { 
						...logData['request'], 
						... { 
							method : generateRequest.method,
							url    : generateRequest.url,
							headers: generateRequest.headers,
							data   : generateRequest.data 
						}
					}
					
					// Run the Fetch Operation
					fetch =  await this.fetch (
						generateRequest.method,
						generateRequest.url,
						generateRequest.data,
						generateRequest.headers
					)

					console.log ({ fetch, generateRequest })

					// Log the the response ( including the latency )
					logData['received'] = moment().format ( 'YYYY-MM-DD HH:mm:ss:SSSS')
					let sent            = moment ( logData.sent,'YYYY-MM-DD HH:mm:ss:SSSS'  ),
					    received        = moment ( logData.received,'YYYY-MM-DD HH:mm:ss:SSSS' )
					logData.latency     = `${received.diff(sent, 'milliseconds')} ms`
					logData.response    = {...fetch}

					if ( fetch.success ) {
						requestSuccess = true
					}

				}
				else {
					return generateRequest
				}

				// Parse response
				if ( requestSuccess ) {
					feedback =  this.parseResponse ( decrypted, fetch.responseData )
					console.log ({ feedback })
					
					if(feedback.data && feedback.data.field39){
						//Clean Response
						let fieldKeys = Object.keys(feedback.data)
						let appResponse = {
							"transSuccess": feedback.data.field39,
							"transDescription": feedback.data.field48,
							"presentmentAmt": feedback.data.field4,
							"account102": feedback.data.field102,
							"presentmentAccName": feedback.data.field49,
							"accountBalance": feedback.data.field54 || '',
							"itaxDetails": feedback.data.field127 || '',
							"forexDetails": feedback.data.field27 || ''
						}
						
						for ( let key of fieldKeys){
							if(!key.startsWith('field')){
								appResponse[key] = feedback.data[key]
							}
						}
						feedback.data = appResponse
					}
					
					let clientResponse = feedback.data ? feedback.data : feedback

					if(clientResponse && clientResponse.transSuccess !== '00'){
						logData.type = 'debug'
					}
					logData.clientResponse = { ...clientResponse}
				}				
				else {
					feedback =  fetch
					logData.type = 'error'
				}

				//Log && Analytics
				let tracing = { service : ctx.service.fullName, log: logData }
				if(['ikonnect-account-lookup', 'get-cards', 'fetch-dcvv'].includes(decrypted.action) && logData.type === 'info'){
					logData.response = {}
					logData.clientResponse = {}
				}

				this.settings.log        && ctx.emit ( 'create.log', logData)
				this.settings.analytics  && ctx.emit ( 'get.analytics', { tracing })

				console.log (JSON.stringify({ feedback }, null, 4))
				let encryptedPayload = await ctx.call('core-security.ibEncrypt', { payload: JSON.stringify(feedback) });
				feedback = encryptedPayload
				//console.log ({ feedback })

				return feedback
			}
		},		
		staging   : {
			rest  : "/staging",
			params: {
				payload: "string",
				$$strict: true
			},
			async handler ( ctx ) {

				let { payload } = ctx.params
				let decrypted = await ctx.call('core-security.ibDecrypt', { payload });
				decrypted = JSON.parse(decrypted)

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					clientRequest: decrypted,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let { resultStatus : success } = await ctx.call ( 'core-database.query', {
					'request-name':'stage.corporate.transaction',
					payload       : decrypted
				})

				logData.responseData = success
				this.settings.log        && ctx.emit ( 'create.log', logData);

				return {  success }
			}
		}
	},
	methods : {

		/**
		 * GENERATE REQUEST METHODS
		 */
		async generateRequest ( params ){

			// configurations			
			let endpoint    = this.settings.requestSettings.endpoints [ params.action ] //configuration for the action


			//Request Template
			let templateName = this.settings.defaultLink.template || 'default'
			let template     = this.settings.requestSettings.templates[templateName]  //default request template

			//override template if its declared in source
			let overrideSource = endpoint["override-source"] || false

			if ( overrideSource ) {

				templateName = this.settings.externalLinks[overrideSource].template || 'default'
				template     = this.settings.requestSettings.templates[templateName]
			}	

			// variables
			let requestSettings = false, groupTo = false, groupFields = false

			// ENDPOINT has the request key
			if ( endpoint.request ) {
				requestSettings = endpoint.request
			}	

			
			let 
				paramsAdded       = false, 
				templateAdded     = false,
				preHooksAdded     = false, // custom functions to modify the request
				formattingApplied = false,
				encodingApplied   = false,
				headersApplied    = false,
				postHooksApplied  = false, // custom functions to modify  the headers or request
				urlCreated        = false,
				addTemplate       = false, 
				applyPreHooks     = false,
				applyFormating    = false,
				applyEncoding     = false,
				applyHeaders      = false,
				applyPostHooks    = false,
				createUrl         = false
			

			// 1. Validate the request Settings fields are matched with the params provided
			let addParameters = this.addParameters ( params.payload, requestSettings )

			if ( addParameters.success ) {
				paramsAdded = true				
			}
			else {
				return this.generateError ( `addParameters Failed` )
			}

			// 2.Add the template and replace the template unique values as wellas the dependent placeholder values
			if ( paramsAdded ) {
				addTemplate = this.addTemplate ( addParameters.data, template )
				
				if ( addTemplate.success ) {
					templateAdded = true
				}
				else {
					return this.generateError ( addTemplate.error )
				}
			}

			// 3. Apply any custom plugins/preHooks - only affects the content of the request
			if ( templateAdded ) {
				applyPreHooks = this.applyPreHooks ( addTemplate.data, params )

				if ( applyPreHooks.success ) {
					preHooksAdded = true
				}
				else {
					return this.generateError ( applyPreHooks.error )
				}
			}

			// 4. Apply Formatting
			if ( preHooksAdded ) {
				applyFormating = this.applyFormating ( applyPreHooks.data,endpoint )

				if ( applyFormating.success ) {
					formattingApplied = true
				}
				else {
					return this.generateError ( applyFormating.error )
				}
			}

			// 5. Apply Encoding
			if ( formattingApplied ) {
				applyEncoding = this.applyEncoding ( applyFormating.data, endpoint )

				if ( applyEncoding.success ) {
					encodingApplied = true
				}
				else {
					return this.generateError ( applyEncoding.error )
				}
			}

			// 6. Apply Headers - returns the request object and custom headers
			if ( encodingApplied ) {
				applyHeaders = await this.applyHeaders ( applyEncoding.data, endpoint )

				if ( applyHeaders.success ) {
					headersApplied = true
				}
				else {
					this.generateError ( applyHeaders.error )
				}
			}

			// 7. Apply Post Hooks
			if ( headersApplied ) {
				applyPostHooks = this.applyPostHooks ( applyHeaders.data, applyHeaders.headers )

				if ( applyPostHooks.success ) {
					postHooksApplied = true
				}
				else {
					this.generateError ( applyPostHooks.error )
				}
			}

			// 8. Create URL
			if ( postHooksApplied ) {
				createUrl = this.createUrl ( applyPostHooks.data, applyPostHooks.headers, endpoint )

				if ( createUrl.success ) {
					urlCreated = true
				}
				else {
					this.generateError ( createUrl.error )
				}
			}
			
			return createUrl

		},
		addParameters   ( params, requestSettings ) {

			let flatten 		= require('flat')
			let unflatten 		= flatten.unflatten
			let isValid               = false, 
				failed                = [], 
				values                = Object.values ( requestSettings ),
				requestSettingsString = JSON.stringify ( requestSettings ),
				placeholders          = [],
				paramKeys             = Object.keys ( params )


			//LOOP through the required values and get the placeholders
			
			let queryValues = Object.values(flatten(requestSettings))
			for ( let entry of queryValues ) {
				//value includes a variable and starts with __
				if ( entry.startsWith ( '__' ) ) {
					placeholders.push ( entry )
				}
			}

			//VALIDATE BY LOOPING through the placeholders and ensure they are contained in the paramKeys
			for ( let placeholder of placeholders ) {

				placeholder = placeholder.replace ( /__/g,'')

				if ( !paramKeys.includes ( placeholder ) ) {
					failed.push ( placeholder )
				}
			}

			//REPLACE the default values
			if ( failed.length  === 0 ) {

				//loop through the placeholders and requestSettings and replace
				for ( let placeholder of placeholders ) {

					let cleanPlaceholder  = placeholder.replace ( /__/g,'')
					let value             = params[ cleanPlaceholder ].toString().trim()
					var regEx             = new RegExp( placeholder, 'g')
					requestSettingsString = requestSettingsString.replace ( regEx, value )
				}

				return {
					success: true,
					data: JSON.parse ( requestSettingsString )
				}
				
			}
			//VALIDATION FAIL
			else {
				return {
					success: false,
					failed
				}
			}
			
		},
		addTemplate     ( request, template ){

			try {
			
				request          = { ...template, ...request }
				let flatten 		= require('flat')
				let 
					keys         = Object.keys( flatten(request) ), 
					replacements = {},
					metaData     = this.settings.metaData
				/**
				 *   	field0: '0200',
						field7: 'create:timeStamp=MMDDHHmmss',
						field11: 'create:stan',
						field12: 'create:timeStamp=HHmmss',
						field13: 'create:timeStamp=MMDD',
						field15: 'create:timeStamp=MMDD',
						field32: 'USSD',
						field33: 'IUBRUXExOTA1',
						field37: 'create:transactionId',
						field40: '000',
						field41: 'FID00001',
						field42: '606465ATM000001',
						field43: 'get:appName',
						field49: 'get:currency',
						field56: 'bcac5bdc-32fb-42df-8ddb-ce8f705ba8c5',
						field60: 'get:country-code',
						field123: 'get:channel',
						field2: '254729347882',
						field3: '110000',
						field4: '0',
						field24: 'MM',
						field64: '',
						field100: 'LOGIN_REQUEST',
						field68: 'USSD - Login Request for account %@field2  - Ref %@field37',
						field74: '8254238129120',
						field77: '',
						field102: '%@field2'
				*/
				//LOOP through each key and replace the create and get values
				

				for ( let key of keys ) {

					let value = request [ key ], newValue = ''

					if ( value && value.startsWith ( 'create' ) ) {

						let parts      = value.split ( ':' )[1]
						let methodName = parts.split ( '=' )[0]
						let args       = value.split ( '=' )[1]

						if ( args ) {
							newValue = utility[`${methodName}`](args)
						}
						else {
							newValue = utility[`${methodName}`]()
						}

					}

					if ( value && value.startsWith ( 'get' ) ) {
						let methodName = value.split ( ':' )[1]
						newValue = metaData[`${methodName}`]
					}

					request [ key ] = newValue ? newValue : value
				}

				
				//LOOP through each key and determine the dependent placeholder values
				for ( let key of keys ) {

					let value = request [ key ]

					if ( value && value.includes ( '%' ) ) {
						let parts = value.split ( '%')

						for ( let entry of parts ) {
							if ( entry.startsWith ( '@' ) ) {
								let placeholder = entry.split ( ' ' )[0]
								replacements [ `%${placeholder}` ] = request [ placeholder.replace(/@/g,'') ]
							}
						}
					}
				}

				//LOOP through the dependent placeholder values and replace them in the request
				let requestString   = JSON.stringify ( request )
				let replacementKeys = Object.keys ( replacements )

				for ( let key of replacementKeys ) {
					
					let regex = new RegExp ( key, 'g' ) 
					let value = replacements [ key ]

					requestString = requestString.replace ( regex, replacements [ key ] )

				}

				return {
					success: true,
					data : JSON.parse ( requestString )
				}
			}

			catch ( e ) {
				console.log ( e )
				return {
					success: false,
					error : `addTemplate Error - ${e.message}`
				}
			}
		},
		applyPreHooks   ( request, params ){

			// "firstname": "Johana",
			// "debitAccountCurrency": "KES"
			// { preHookRequest:
			// 	{ field0: '0200',
			// 	  field7: '0817154136',
			// 	  field11: '477096',
			// 	  field12: '154136',
			// 	  field13: '0817',
			// 	  field15: '0817',
			// 	  field32: 'IB',
			// 	  field33: 'IUBRUXExOTA1',
			// 	  field37: '8S6KDYIC15E',
			// 	  field40: '000',
			// 	  field41: 'FID00001',
			// 	  field42: '606465ATM000001',
			// 	  field43: 'iKonnect',
			// 	  field49: 'KES',
			// 	  field56: 'bcac5bdc-32fb-42df-8ddb-ce8f705ba8c5',
			// 	  field60: 'KE',
			// 	  PerTxnLimit: '5000.00',
			// 	  DailyTxnLimit: '50000.00',
			// 	  name102: 'Customer',
			// 	  field2: '254729347882',
			// 	  field3: '400000',
			// 	  field4: '120',
			// 	  field24: 'BB',
			// 	  field68:
			// 	   'IB - Funds Transfer From account 0161019000320 to account 0166001000128  - Ref 8S6KDYIC15E',
			// 	  field98: 'IB',
			// 	  field100: 'FTCORE2CORE',
			// 	  field102: '0161019000320',
			// 	  field103: '0166001000128',
			// 	  field104: 'Funds Transfer',
			// 	  field123: 'IB',
			// 	  field126: 'Funds Transfer' },
			//    params:
			// 	{ action: 'funds-transfer',
			// 	  payload:
			// 	   { internationalPhone: '254729347882',
			// 		 amount: '120',
			// 		 debitAccount: '0161019000320',
			// 		 creditAccount: '0166001000128' },
			// 	  firstname: 'Johana',
			// 	  debitAccountCurrency: 'KES' } }

			// username
			if ( params.firstname ) {
				request.name102 = params.firstname
			}

			//currency
			let fts = ['961000', '407000', '400000', '403000', '402000']
			if ( params.debitAccountCurrency && !fts.includes(request.field3) ) {
				request.field49 = params.debitAccountCurrency
			}
			if ( params.debitAccountCurrency && fts.includes(request.field3) ) {
				request.field47 = params.debitAccountCurrency
			}

			if(request.requestType === 'setLimits'){
				request = { ...request, ...params.payload }
			}

			//limits
			if ( params.perTransactionLimit ) {
				request.PerTxnLimit = params.perTransactionLimit.toString()
			}
			if ( params.dailyTransactionLimit ) {
				request.DailyTxnLimit = params.dailyTransactionLimit.toString()
			}

			// call deposits
			if ( request.field3 === "956000" && request.field65 === "N/A"  ) {
				request.field65 = "12"
			}
			if( request.field3 === "420000" && request.field100 === "TELKOM" ){
				request.field100 = 'ORANGE';
				request.field71 = 'ORANGE'
			}

			if(request.field3 === '956000'){
				request.field68 = request.field68.replace('CD', 'Call Deposits')
				request.field68 = request.field68.replace('FD', 'Fixed Deposits')
				request.field68 = request.field68.replace('| Term - N/A', '')
			}
			//forex rtgs
			if ( request.field3 === '222000' && request.request.field100 === 'RTGS') {
				request.request.field13 = request.field13
				request.request.field15 = request.field13
				request.request.field65 = `${params.payload.bank}${params.payload.branch}`
			}
			//loan application
			if ( request.field3 === '660000' && params.creditDestination === 'WALLET') {
				request.request.field24 = "MM"
			}
			if ( request.field3 === '660000' && params.creditDestination === 'CORE') {
				request.request.field24 = "BB"
				request.request.field103 = params.loanLinkedAccount
			}

			console.log ( JSON.stringify ( request, null, 4 ) )


			return {
				success: true,
				data   : request
			}
		},
		applyFormating  ( request, endpoint ){
			try {

				//get the format from the external links
				let format = this.settings.defaultLink ["payload-format"]
				let overrideSource = endpoint["override-source"] || false

				if (  overrideSource ) {
					format = this.settings.externalLinks[overrideSource]["payload-format"]
				}


				if ( format !== 'JSON' ){
					request = utility [ format ] ( request )
				}

				return {
					success: true,
					data   : request
				}
			}
			catch  ( e ){
				return {
					success: false,
					error  : `applyFormatting Error - ${e.message}`
				}
			}
		},
		applyEncoding   ( request, endpoint ){
			try {

				//get the encoding from the external links
				let encoding       = this.settings.defaultLink ["encoding"]
				let overrideSource = endpoint["override-source"] || false

				if (  overrideSource ) {
					encoding = this.settings.externalLinks[overrideSource]["encoding"]
				}

				if ( encoding === 'base64' ){

					if ( typeof request === 'object' ) {
						request = JSON.stringify ( request )
					}
					request = utility.base64 ( request )
				}

				return {
					success:true,
					data: request
				}

			}
			catch ( e ) {
				return {
					success:false,
					error: `applyEncoding Error - ${e.message}`
				}
			}
		},
		async applyHeaders    ( request, endpoint ){
			try {

				//get the globalHeaders from the external links
				let globalHeaders  = this.settings.requestSettings.headers[defaultSource]
				let overrideSource = endpoint["override-source"] || false

				if (  overrideSource ) {
					globalHeaders = this.settings.requestSettings.headers[overrideSource] || this.settings.requestSettings.headers.default
				}

				let customHeaders = endpoint['headers'] || {}

				let fetchToken = await this.fetch('get', authUrl, {
					username: 'IB'
				})

				//merge headers
				let headers =  { ...globalHeaders, ...customHeaders, "Authorization": `Bearer ${fetchToken.responseData}` }
				
				// Find a way to add access tokens
				return {
					success: true,
					data   : request,
					headers
				}
			}
			catch  ( e ) {
				return {
					success:false,
					error : `applyHeaders Error - ${e.message}`
				}
			}
		},		
		applyPostHooks  ( request, headers ){
			return {
				success: true,
				data   : request,
				headers
			}
		},
		createUrl       ( request, headers, endpoint ){

			try {

				let cfg            = {}
				let overrideSource = endpoint["override-source"] || false
				let requestPath    = endpoint["request-path"]    || false

				//custom url
				if ( overrideSource ) {

					cfg = this.settings.externalLinks[overrideSource]	
					if ( requestPath ) {
						cfg.path = requestPath
					}				
				}
				//default url
				else {
					cfg = this.settings.defaultLink

					//default url with custom path
					if ( requestPath ) {
						cfg.path = requestPath
					}
				}

				let url = `${cfg.protocol}://${cfg.host}:${cfg.port}/${cfg.path}`.trim()

				return {
					success: true,
					data   : request,
					headers,
					url,
					method: cfg.method
				}
			}
			catch ( e ) {
				return {
					success:false,
					error : `createUrl Error - ${e.message}`
				}
			}
		},


		/**
		 * SEND REQUEST
		 */
		async fetch ( method, url, data, headers ) {

			// Defaults
			let response     = false
			let responseData = false
			let success      = false
			let statusCode   = 408  //timeout http code
			
			// Axios Instance
			let httpsAgent = false

			if ( url.startsWith ( 'https' ) ){
				const https = require ( 'https' )
				httpsAgent  = new https.Agent({ rejectUnauthorized: false })
			}
				
			let instance = httpsAgent ? axios.create ({ httpsAgent }) : axios.create()
			
			// Timeout when connected to tgeh internet
			instance.defaults.timeout = this.settings.timeout			

			// Timeout when not connected to the internet
			const source = axios.CancelToken.source()

			setTimeout( () => {
			  if ( response === false ) {
				source.cancel()
			  }
			}, this.settings.timeout ) // connection timeout here in ms
	
	
			// Headers
			let headerConfig = headers ? { ...headers, cancelToken: source.token } : { cancelToken: source.token }

			// Attempt Request
			try {

				switch ( method ) {
					case "get":
						try {
							response = await instance.get( url, data, {headers: headerConfig} )
						} catch (error) {
							response = error.response
						}
						break

					case "post":
						try {
                            response = await instance.post(url, data, {headers: headerConfig})
                        } catch (error) {
                            response = error.response
                        }
						break
				}

				if ( response ) {
					
					statusCode   = response.status
					responseData = response.data
					success      = true
				}

				return { success, statusCode, responseData }
			}
			catch (e) {
				console.log ( e )
				return { success:false, statusCode, error:`API Fetch Error - ${e.message}` }
			}
		},


		/**
		 * PARSE RESPONSE METHODS
		 */
		parseResponse           ( params, response ){

			let isDecoded               = false,
				isFormatted             = false,
				runResponseHooks        = false,
				applyDecoding           = false,
				applyResponseformatting = false,
				applyResponseHooks      = false

			// configurations			
			let endpoint    = this.settings.requestSettings.endpoints [ params.action ] //configuration for the action

			// 1. Decode the response
			applyDecoding = this.applyDecoding ( response, endpoint )

			if ( applyDecoding.success ){
				isDecoded = true
			}
			else {
				return this.generateError ( applyDecoding.error )
			}

			// 2. Apply response formatting
			if ( isDecoded ) {
				applyResponseformatting = this.applyResponseformatting ( applyDecoding.data, endpoint )

				if ( applyResponseformatting.success ){
					isFormatted = true
				}
				else {
					return this.generateError ( applyResponseformatting.error )
				}
			}

			// 3. Apply Response Hooks ( format the decoded response for use by the client )
			if ( isFormatted ) {

				applyResponseHooks = this.applyResponseHooks (  params, applyResponseformatting.data )
				
				if ( applyResponseHooks.success ) {
					return applyResponseHooks
				}
				else {
					return this.generateError ( applyResponseHooks.error )
				}
			}		
			
		},
		applyDecoding           ( response, endpoint ){

			try {

				//get the encoding from the external links
				let encoding       = this.settings.defaultLink ["encoding"]
				let overrideSource = endpoint["override-source"] || false

				if (  overrideSource ) {
					encoding = this.settings.externalLinks[overrideSource]["encoding"]
				}				

				if ( encoding === 'base64' ){
					response = utility.base64Decode ( response )
				}

				return {
					success:true,
					data:response
				}
			}
			catch ( e ) {
				return {
					success:false,
					error:`applyDecoding Error - ${e.message}`
				}
			}
		},
		applyResponseformatting ( response, endpoint ){
			
			try {

				//get the format from the external links
				let format = this.settings.defaultLink ["payload-format"]
				let overrideSource = endpoint["override-source"] || false

				if (  overrideSource ) {
					format = this.settings.externalLinks[overrideSource]["payload-format"]
				}
				

				if ( format === 'JSON' ){
					response = utility.fromJSON ( response )
				}

				//console.log ( JSON.stringify ({ response }, null, 4 ) )

				return {
					success : true,
					data    : response
				}
			}
			catch ( e ) {
				return {
					success : false,
					error   : `applyResponseformatting Error - ${e.message}`
				}
			}

		},
		applyResponseHooks      ( params, response ){

			try {

				let endpoint    = this.settings.requestSettings.endpoints [ params.action ] //configuration for the action
				let responseCfg = endpoint ['response']
				let formatted   = response

				/**
				 * Check Status field
				 */
				let fieldToCheck = responseCfg.status.field
				let successValue = responseCfg.status.matches[0].code
				let errorField   = responseCfg.status.error.message

				// Successful Response
				if ( response [ fieldToCheck ] === successValue ) {

					/**
					 * Check formatter if exists
					 */
					if ( responseCfg [ 'formatter' ] ) {
						let methodName = responseCfg [ 'formatter']
						let formatter  = require ( path.resolve ( `./config/${appName}/transactions/formatters/${methodName}` ) )
							formatted  = formatter ( response )	
							
						return {
							success: true,
							data   : formatted
						}
					}
					/**
					 * Formatter Doesnt Exist - Default handling
					 */
					else {
						return {
							success: true,
							data   : response
						}
					}
					
				}

				// Error Response
				else {

					var errorMsg
					if(errorField.includes(".")){
  						errorMsg = response[errorField.split(".")[0]]
						errorMsg =  errorMsg[errorField.split(".")[1]]
					}else{
						errorMsg = response [ errorField ]
					}
					return {
						success: false,
						error   : errorMsg
					}
				}
				
				
			}
			catch  ( e ){
				return {
					success: false,
					error  : `applyResponseHooks Error - ${e.message}`
				}
			} 

			
		},


		/**
		 * ERROR HANDLING
		 */
		generateError ( message ) {
			return {
				success:false,
				message
			}
		}

	},

	/**
	 * Lifecycle Event Handlers
	 */
	created       () {
	},
	async started () {
	},
	async stopped () {
	}
}