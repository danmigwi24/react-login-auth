"use strict"

const moment = require ( 'moment' )
// Environment Config
const path          = require ( 'path' )
const env           = require ( 'dotenv').config()				
if ( env.error ) { throw env.error };

let emailActivationExpiry = process.env.EMAIL_ACTIVATION_EXPIRY_HOURS

module.exports = {
	name   : "users-profile",
	settings: {
		log: true
	},
	actions: {
		fetch: {
			rest  : "/fetch",
			params: {
				username : "email"
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let{ username }  = ctx.params
				
				let { resultStatus, result } = await ctx.call ( 'core-database.query', {
					'request-name':'profile',
					payload       : { username }
				})
				
				// user exists
				if ( resultStatus && result[0] && result[0].length > 0 ) {
					let data = result[0][0]

					logData.responseData = 'successful'
					this.settings.log        && ctx.emit ( 'create.log', logData);
	
					return {
						success:true,
						data
					}
				}
				else {
					logData.type = 'debug'
					logData.responseData = `Error loading Profile for ${ ctx.params.username}`
					this.settings.log        && ctx.emit ( 'create.log', logData);
	
					return {
						success:false,
						error:`Error loading Profile for ${ ctx.params.username}`
					}
				}
				
			}
		},
		verifyToken: {
			rest  : "/verify-token",
			params: {
				username : "email",
				token 	 : "string",
				timeGenerated: "string"
			},
			async handler(ctx) {

				let logData = {
					type: 'info',
					service : ctx.service.fullName,
					requestParams: ctx.params,
					esbParams: '',
					resposeCode: 200,
					responseData: '',
					userDevice: ctx.meta.userDevice
				};

				let{ username, token, timeGenerated }  = ctx.params
				
				let { resultStatus, result } = await ctx.call ( 'core-database.query', {
					'request-name':'fetch-activation-token',
					payload       : { 
						username
					}
				});

				//console.log({ resultStatus, result })

				//let savedTime    = moment ( otpTime, 'YYYY-MM-DD HH:mm:ss' ).subtract ( 3, 'hours') // our server adds 3 hours when fetching data due to GMT + 3.00
				let currentTime  = moment() //todays date
				let duration     = moment.duration(currentTime.diff(timeGenerated))
				let hours      	 = duration.asHours()
				
				// user exists Validation and 24 Hour check
				if ( resultStatus && result[0] && result[0].length > 0 && hours < parseInt(emailActivationExpiry)) {
					let data = result[0][0];

					if(data.Profile_Activation_Token === token){
						
						logData.responseData = `Successfuly verified token`
						this.settings.log        && ctx.emit ( 'create.log', logData);
		
						return {
							success: true
						}
					}else{
						logData.type = 'debug'
						logData.dbData = data
						logData.responseData = {success: false}
						this.settings.log        && ctx.emit ( 'create.log', logData);
		
						return {
							success: false
						}
					}
				}
				else {
					logData.type = 'debug'
					logData.dbData = result
					logData.responseData = `Error loading Profile for ${ ctx.params.username}`
					this.settings.log        && ctx.emit ( 'create.log', logData);
	
					return {
						success:false,
						error:`Error loading Profile for ${ ctx.params.username}`
					}
				}
				
			}
		}
	}
}